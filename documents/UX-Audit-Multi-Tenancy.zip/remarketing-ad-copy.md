# EZ Cycle Ramp — Remarketing Ad Copy & Creative Briefs

## Audience Segments

| Segment | Trigger | Message Focus | Urgency Level |
|---------|---------|---------------|---------------|
| Configurator Started | Started but didn't finish | Curiosity, value prop | Low |
| Configurator Completed | Finished, no purchase | Social proof, specific product | Medium |
| Product Page Viewers | Viewed AUN 200 or 250 | That specific product | Medium |
| Cart Abandoners | Added to cart | Overcome objection | High |
| Past Purchasers | Bought a ramp | Accessories, referral | None |

---

## Meta (Facebook/Instagram) Ads

### Ad Set 1: Configurator Abandoners

**Audience:** Started configurator, didn't complete
**Objective:** Traffic back to configurator
**Timing:** 1-7 days after abandon

**Ad 1 — Carousel (Problem/Solution)**

Slide 1:
- Image: Frustrated rider looking at bike + truck
- Text: "Still dreading loading day?"

Slide 2:
- Image: EZ Cycle Ramp extending
- Text: "There's a better way"

Slide 3:
- Image: Rider pressing button, relaxed
- Text: "One button. Done."

Slide 4:
- Image: Product beauty shot
- Text: "Find your ramp →"

Primary text:
> You started our configurator but didn't finish. We get it—$2,500 is a real decision.
> 
> But here's the thing: one dropped bike costs more than that. And your back isn't getting younger.
> 
> Take 30 seconds to finish and see which ramp fits your truck.

CTA: Find Your Ramp

---

**Ad 2 — Video (15 seconds)**

:00-:03 — Hook: Rider struggling with traditional ramp (B-roll)
:03-:08 — Solution: EZ Cycle Ramp extends, bike lifts smoothly
:08-:12 — Result: Rider dusts hands off, walks away relaxed
:12-:15 — End card: "Find Your Fit" + logo

Primary text:
> Loading your bike shouldn't require a spotter or a chiropractor.
> 
> We'll recommend the right ramp for your truck in 30 seconds.

CTA: Take the Quiz

---

### Ad Set 2: Configurator Completers (High Intent)

**Audience:** Completed configurator, recommended AUN 250, no purchase
**Objective:** Conversions
**Timing:** 1-14 days after completion

**Ad 1 — Single Image (Social Proof)**

Image: Customer photo with their ramp installed (real if possible, stock if not)

Primary text:
> "I'm 62 and loading my bagger was becoming a problem. This ramp changed everything." — Mike R., Dallas
> 
> You completed our configurator. We recommended the AUN 250 for your short-bed truck.
> 
> 1,212 lb capacity. Closes with your tailgate. 2-year warranty.
> 
> Ready to stop dreading loading day?

Headline: Your AUN 250 Is Waiting
CTA: Shop Now

---

**Ad 2 — Video (30 seconds)**

:00-:05 — "You told us about your truck and bike..."
:05-:10 — "We recommended the AUN 250"
:10-:20 — Product demo: extend, load, close tailgate
:20-:25 — Testimonial soundbite
:25-:30 — Price + CTA

Primary text:
> Based on your answers, the AUN 250 Folding Ramp is perfect for your setup.
> 
> ✓ Fits 5.5' beds
> ✓ Close your tailgate
> ✓ 1,212 lb capacity
> ✓ $2,795 + free shipping

Headline: Built for Your Truck
CTA: Get Yours

---

### Ad Set 3: Cart Abandoners (Highest Intent)

**Audience:** Added to cart, didn't purchase
**Objective:** Conversions
**Timing:** 1-3 days after abandon

**Ad 1 — Urgency/Objection Handler**

Image: Product shot with "Still in Your Cart" overlay

Primary text:
> Your EZ Cycle Ramp is still in your cart.
> 
> If you're hesitating, here's what you should know:
> 
> ✓ 2-year warranty — we stand behind it
> ✓ Free shipping — no hidden costs
> ✓ Real support — call us at (937) 725-6790
> 
> One dropped bike costs more than this ramp. Your back will thank you.

Headline: Complete Your Order
CTA: Buy Now

---

**Ad 2 — Financing Focus**

Image: Product with "$117/mo" callout

Primary text:
> Your ramp is waiting.
> 
> Too much at once? Pay $117/mo with Affirm. 0% APR available.
> 
> Load solo. Pay over time.

Headline: $117/mo with Affirm
CTA: Complete Purchase

---

### Ad Set 4: Past Purchasers (Accessories + Referral)

**Audience:** Purchased 30+ days ago
**Objective:** Upsell / Referrals
**Timing:** 30-90 days post-purchase

**Ad 1 — Accessory Upsell**

Image: AC001 Extender product shot

Primary text:
> Love your EZ Cycle Ramp?
> 
> The AC001 Extender lets you load in lifted trucks and vans up to 60" high. Perfect for adventure rigs.
> 
> Plus: it keeps long exhaust pipes from scraping during load.
> 
> Existing customer? Use code UPGRADE100 for $100 off.

Headline: Go Higher
CTA: Shop Accessories

---

**Ad 2 — Referral**

Image: Two riders with trucks, both with ramps installed

Primary text:
> Know another rider who hates loading day?
> 
> Refer a friend and you'll both get $100:
> → You: $100 toward accessories
> → Them: $100 off their ramp
> 
> Three referrals = Free AC001 Extender ($395 value)

Headline: Share the Easy Life
CTA: Get Your Referral Link

---

## Google Ads

### Search Campaigns

**Campaign 1: Brand**

Keywords:
- ez cycle ramp
- ezcycleramp
- ez-cycle ramp
- neo-dyne motorcycle ramp

Ad:
```
EZ Cycle Ramp® - Official Site
Load Your Motorcycle Solo. No Spotter Needed.
1,200 lb Capacity. 2-Year Warranty. Free Shipping.
www.ezcycleramp.com
```

---

**Campaign 2: Non-Brand — High Intent**

Keywords:
- automated motorcycle ramp
- one person motorcycle loading ramp
- motorcycle loading ramp for truck
- power motorcycle ramp
- electric motorcycle loader

Ad:
```
Load Your Bike Solo - No Spotter
EZ Cycle Ramp® Automated Loader
Slides, Tilts & Lifts Up to 1,200 lbs
Fits F-150, Silverado, RAM & More
www.ezcycleramp.com/shop
```

Sitelinks:
- Find Your Ramp (configurator)
- AUN 250 Folding Ramp
- AUN 200 Standard Ramp
- See It In Action (video)

---

**Campaign 3: Competitor**

Keywords:
- condor pit stop alternative
- motorcycle loading ramp review
- best motorcycle ramp
- rampage power lift vs

Ad:
```
Beyond Basic Ramps - Full Automation
EZ Cycle Ramp® Slides, Tilts AND Lifts
Compare: No Walking the Bike Up an Incline
See Why Riders Switch →
www.ezcycleramp.com/compare
```

---

### Display/YouTube Remarketing

**Banner Ad Sizes:** 300x250, 728x90, 160x600, 320x50 (mobile)

**Message Hierarchy:**
1. Product image (ramp with bike)
2. Headline: "Load Solo. Ride Anywhere."
3. Key benefit: "Up to 1,200 lbs. One button."
4. CTA: "Shop Now"

**YouTube Pre-Roll (15 sec)**
Same as Meta 15-second video, optimized for skip button (hook in first 5 seconds)

---

## Creative Asset Checklist

### Photos Needed

- [ ] Hero product shot (ramp extended, beauty lighting)
- [ ] Ramp with bike loaded (Harley, BMW, Indian)
- [ ] Close-up of drill trigger being pressed
- [ ] Rider's face showing relief/satisfaction
- [ ] Before/after loading comparison
- [ ] Tailgate closing with AUN 250 installed
- [ ] Real customer photos (ask after 5-star reviews)

### Videos Needed

- [ ] 15-second demo (hook → solution → CTA)
- [ ] 30-second demo (fuller story)
- [ ] 60-second testimonial compilation
- [ ] Installation timelapse (for YouTube)

### Graphics Needed

- [ ] Price callout overlays ($2,795, $117/mo)
- [ ] Trust badge graphics (warranty, capacity, USA)
- [ ] Comparison chart (EZ Cycle vs competitors)
- [ ] "Still in Your Cart" overlay

---

## Budget Allocation Recommendation

For a $5,000/month test budget:

| Channel | % | Monthly | Focus |
|---------|---|---------|-------|
| Meta Remarketing | 40% | $2,000 | Configurator completers, cart abandoners |
| Google Search (Brand) | 15% | $750 | Protect brand terms |
| Google Search (Non-Brand) | 25% | $1,250 | High-intent keywords |
| Google Display/YouTube | 10% | $500 | Remarketing only |
| Testing/Creative | 10% | $500 | New concepts |

### KPI Targets

| Metric | Target |
|--------|--------|
| Meta Remarketing ROAS | 5:1+ |
| Google Brand CPC | <$1.00 |
| Google Non-Brand CPC | <$5.00 |
| Configurator completion rate (from ads) | >60% |
| Cart recovery rate | >10% |

---

## Ad Copy Templates

### Headline Formulas

- [Pain Point] → [Solution]
  - "Hate Loading Day? → Load Solo"
- [Benefit] + [Proof Point]
  - "One-Button Loading. 1,200 lb Capacity."
- [Objection Handler]
  - "Worth $2,795? One Dropped Bike Costs More."
- [Social Proof]
  - "Why 500+ Riders Switched"

### Primary Text Formulas

**Problem-Agitate-Solve:**
> Loading your bike shouldn't require a spotter and a prayer. [Problem]
> One slip on a sketchy plank = thousands in damage. [Agitate]
> The EZ Cycle Ramp slides, tilts, and lifts—completely automated. [Solve]

**Feature-Benefit-Proof:**
> 1,212 lb capacity. [Feature]
> Load your fully-loaded bagger without breaking a sweat. [Benefit]
> Mike R. from Dallas: "Worth every penny." [Proof]

**Direct Response:**
> You completed our configurator.
> We recommended the AUN 250 for your truck.
> It's $2,795 with free shipping.
> Ready to stop dreading loading day?
> [CTA]

---

## Testing Roadmap

### Week 1-2: Baseline
- Launch remarketing to all segments
- Measure baseline CPA, ROAS

### Week 3-4: Creative Test
- Test video vs static
- Test problem-focused vs solution-focused

### Week 5-6: Audience Test
- Test lookalikes from purchasers
- Test interest targeting (motorcycle owners)

### Week 7-8: Offer Test
- Test financing messaging
- Test urgency ("limited inventory")

### Ongoing
- Refresh creative every 4-6 weeks
- Kill underperformers, scale winners

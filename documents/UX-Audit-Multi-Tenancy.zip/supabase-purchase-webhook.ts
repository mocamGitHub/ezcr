// ============================================
// CONVERSION TRACKING & POST-PURCHASE AUTOMATION
// Connects your e-commerce/payment system to lead tracking
// ============================================

// ---------------------------------------------
// supabase/functions/handle-purchase/index.ts
// Webhook endpoint for your payment processor (Stripe, Shopify, etc.)
// ---------------------------------------------

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@14.5.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
}

interface OrderData {
  order_id: string
  email: string
  product_sku: string // 'AUN200' or 'AUN250'
  amount: number
  currency: string
  customer_name?: string
  shipping_address?: {
    line1: string
    city: string
    state: string
    postal_code: string
    country: string
  }
  source: 'stripe' | 'shopify' | 'manual'
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  try {
    const source = req.headers.get('x-webhook-source') || 'unknown'
    let orderData: OrderData

    // Handle different payment sources
    if (source === 'stripe' || req.headers.get('stripe-signature')) {
      orderData = await handleStripeWebhook(req)
    } else if (source === 'shopify') {
      orderData = await handleShopifyWebhook(req)
    } else {
      // Manual/direct API call
      orderData = await req.json()
    }

    console.log(`Processing order: ${orderData.order_id} for ${orderData.email}`)

    // 1. Find and update the configurator lead
    const { data: lead } = await supabase
      .from('configurator_leads')
      .select('id, recommendation')
      .eq('email', orderData.email.toLowerCase())
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    if (lead) {
      // Mark lead as converted
      await supabase
        .from('configurator_leads')
        .update({
          converted_at: new Date().toISOString(),
          order_id: orderData.order_id,
        })
        .eq('id', lead.id)

      // Stop any active email sequences
      await supabase
        .from('lead_sequences')
        .update({
          status: 'converted',
          completed_at: new Date().toISOString(),
        })
        .eq('lead_id', lead.id)
        .eq('status', 'active')

      console.log(`✓ Marked lead ${lead.id} as converted`)
    }

    // 2. Create order record
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        order_id: orderData.order_id,
        email: orderData.email.toLowerCase(),
        product_sku: orderData.product_sku,
        amount: orderData.amount,
        currency: orderData.currency,
        customer_name: orderData.customer_name,
        shipping_address: orderData.shipping_address,
        source: orderData.source,
        lead_id: lead?.id || null,
        from_configurator: !!lead,
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (orderError) {
      console.error('Error creating order:', orderError)
    }

    // 3. Trigger post-purchase automation
    await Promise.allSettled([
      sendToN8N(orderData, lead),
      sendOrderConfirmationEmail(orderData),
      updateEmailMarketingTags(orderData),
      sendSlackOrderNotification(orderData, lead),
      trackConversion(orderData, lead),
    ])

    return new Response(
      JSON.stringify({ 
        success: true, 
        order_id: orderData.order_id,
        lead_converted: !!lead,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error processing purchase:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

// ---------------------------------------------
// Stripe Webhook Handler
// ---------------------------------------------

async function handleStripeWebhook(req: Request): Promise<OrderData> {
  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
    apiVersion: '2023-10-16',
  })

  const signature = req.headers.get('stripe-signature')!
  const body = await req.text()
  const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')!

  const event = stripe.webhooks.constructEvent(body, signature, webhookSecret)

  if (event.type !== 'checkout.session.completed' && event.type !== 'payment_intent.succeeded') {
    throw new Error(`Unhandled event type: ${event.type}`)
  }

  const session = event.data.object as Stripe.Checkout.Session

  // Get line items to determine product
  const lineItems = await stripe.checkout.sessions.listLineItems(session.id)
  const productSku = determineProductSku(lineItems.data)

  return {
    order_id: session.id,
    email: session.customer_details?.email || session.customer_email || '',
    product_sku: productSku,
    amount: session.amount_total ? session.amount_total / 100 : 0,
    currency: session.currency || 'usd',
    customer_name: session.customer_details?.name || undefined,
    shipping_address: session.shipping_details?.address ? {
      line1: session.shipping_details.address.line1 || '',
      city: session.shipping_details.address.city || '',
      state: session.shipping_details.address.state || '',
      postal_code: session.shipping_details.address.postal_code || '',
      country: session.shipping_details.address.country || '',
    } : undefined,
    source: 'stripe',
  }
}

function determineProductSku(lineItems: Stripe.LineItem[]): string {
  for (const item of lineItems) {
    const name = item.description?.toLowerCase() || ''
    if (name.includes('250') || name.includes('folding')) return 'AUN250'
    if (name.includes('200') || name.includes('standard')) return 'AUN200'
  }
  return 'UNKNOWN'
}

// ---------------------------------------------
// Shopify Webhook Handler
// ---------------------------------------------

async function handleShopifyWebhook(req: Request): Promise<OrderData> {
  const body = await req.json()
  
  // Verify Shopify webhook (HMAC)
  // const hmac = req.headers.get('x-shopify-hmac-sha256')
  // ... verification logic ...

  const order = body

  // Determine product from line items
  let productSku = 'UNKNOWN'
  for (const item of order.line_items || []) {
    const sku = item.sku?.toUpperCase() || ''
    const title = item.title?.toLowerCase() || ''
    if (sku.includes('AUN250') || title.includes('250') || title.includes('folding')) {
      productSku = 'AUN250'
      break
    }
    if (sku.includes('AUN200') || title.includes('200') || title.includes('standard')) {
      productSku = 'AUN200'
      break
    }
  }

  return {
    order_id: `shopify_${order.id}`,
    email: order.email || order.customer?.email || '',
    product_sku: productSku,
    amount: parseFloat(order.total_price || '0'),
    currency: order.currency || 'USD',
    customer_name: `${order.customer?.first_name || ''} ${order.customer?.last_name || ''}`.trim() || undefined,
    shipping_address: order.shipping_address ? {
      line1: order.shipping_address.address1 || '',
      city: order.shipping_address.city || '',
      state: order.shipping_address.province || '',
      postal_code: order.shipping_address.zip || '',
      country: order.shipping_address.country || '',
    } : undefined,
    source: 'shopify',
  }
}

// ---------------------------------------------
// Post-Purchase Actions
// ---------------------------------------------

async function sendToN8N(order: OrderData, lead: any) {
  const webhookUrl = Deno.env.get('N8N_ORDER_WEBHOOK_URL')
  if (!webhookUrl) return { skipped: true }

  await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      event: 'order_completed',
      timestamp: new Date().toISOString(),
      order,
      lead: lead || null,
      attribution: {
        from_configurator: !!lead,
        recommendation_matched: lead?.recommendation === order.product_sku,
      },
    }),
  })
}

async function sendOrderConfirmationEmail(order: OrderData) {
  const apiKey = Deno.env.get('SENDGRID_API_KEY')
  if (!apiKey) return { skipped: true }

  const templateId = Deno.env.get('SENDGRID_TEMPLATE_ORDER_CONFIRMATION')
  if (!templateId) return { skipped: true }

  await fetch('https://api.sendgrid.com/v3/mail/send', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      personalizations: [{
        to: [{ email: order.email }],
        dynamic_template_data: {
          order_id: order.order_id,
          product_name: order.product_sku === 'AUN250' ? 'AUN 250 Folding Ramp' : 'AUN 200 Standard Ramp',
          amount: order.amount,
          customer_name: order.customer_name || 'there',
          shipping_address: order.shipping_address,
        },
      }],
      from: { email: 'orders@ezcycleramp.com', name: 'EZ Cycle Ramp' },
      template_id: templateId,
    }),
  })
}

async function updateEmailMarketingTags(order: OrderData) {
  const provider = Deno.env.get('EMAIL_PROVIDER')
  
  if (provider === 'klaviyo') {
    const apiKey = Deno.env.get('KLAVIYO_API_KEY')
    if (!apiKey) return

    // Track purchase event
    await fetch('https://a.klaviyo.com/api/events/', {
      method: 'POST',
      headers: {
        'Authorization': `Klaviyo-API-Key ${apiKey}`,
        'Content-Type': 'application/json',
        'revision': '2024-02-15',
      },
      body: JSON.stringify({
        data: {
          type: 'event',
          attributes: {
            profile: { $email: order.email },
            metric: { name: 'Placed Order' },
            properties: {
              order_id: order.order_id,
              value: order.amount,
              product_sku: order.product_sku,
            },
            value: order.amount,
          },
        },
      }),
    })
  }

  if (provider === 'mailchimp') {
    const apiKey = Deno.env.get('MAILCHIMP_API_KEY')
    const listId = Deno.env.get('MAILCHIMP_LIST_ID')
    if (!apiKey || !listId) return

    const dc = apiKey.split('-')[1]
    const subscriberHash = await md5(order.email.toLowerCase())

    await fetch(
      `https://${dc}.api.mailchimp.com/3.0/lists/${listId}/members/${subscriberHash}/tags`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`anystring:${apiKey}`)}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          tags: [
            { name: 'customer', status: 'active' },
            { name: `purchased-${order.product_sku.toLowerCase()}`, status: 'active' },
            { name: 'configurator-lead', status: 'inactive' }, // Remove prospect tag
          ],
        }),
      }
    )
  }
}

async function sendSlackOrderNotification(order: OrderData, lead: any) {
  const webhookUrl = Deno.env.get('SLACK_WEBHOOK_URL')
  if (!webhookUrl) return

  const attribution = lead 
    ? `✓ From configurator (recommended: ${lead.recommendation})` 
    : '○ Direct purchase (no configurator)'

  await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      blocks: [
        {
          type: 'header',
          text: { type: 'plain_text', text: '💰 New Order!', emoji: true },
        },
        {
          type: 'section',
          fields: [
            { type: 'mrkdwn', text: `*Product:*\n${order.product_sku}` },
            { type: 'mrkdwn', text: `*Amount:*\n$${order.amount.toLocaleString()}` },
          ],
        },
        {
          type: 'section',
          fields: [
            { type: 'mrkdwn', text: `*Customer:*\n${order.customer_name || order.email}` },
            { type: 'mrkdwn', text: `*Attribution:*\n${attribution}` },
          ],
        },
      ],
    }),
  })
}

async function trackConversion(order: OrderData, lead: any) {
  // Google Analytics 4 Measurement Protocol
  const measurementId = Deno.env.get('GA4_MEASUREMENT_ID')
  const apiSecret = Deno.env.get('GA4_API_SECRET')
  
  if (measurementId && apiSecret) {
    await fetch(
      `https://www.google-analytics.com/mp/collect?measurement_id=${measurementId}&api_secret=${apiSecret}`,
      {
        method: 'POST',
        body: JSON.stringify({
          client_id: lead?.id || order.order_id,
          events: [{
            name: 'purchase',
            params: {
              transaction_id: order.order_id,
              value: order.amount,
              currency: order.currency.toUpperCase(),
              items: [{
                item_id: order.product_sku,
                item_name: order.product_sku === 'AUN250' ? 'AUN 250 Folding Ramp' : 'AUN 200 Standard Ramp',
                price: order.amount,
                quantity: 1,
              }],
            },
          }],
        }),
      }
    )
  }

  // Facebook Conversions API
  const fbPixelId = Deno.env.get('FB_PIXEL_ID')
  const fbAccessToken = Deno.env.get('FB_ACCESS_TOKEN')
  
  if (fbPixelId && fbAccessToken) {
    await fetch(
      `https://graph.facebook.com/v18.0/${fbPixelId}/events?access_token=${fbAccessToken}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          data: [{
            event_name: 'Purchase',
            event_time: Math.floor(Date.now() / 1000),
            action_source: 'website',
            user_data: {
              em: [await sha256(order.email.toLowerCase())],
            },
            custom_data: {
              currency: order.currency.toUpperCase(),
              value: order.amount,
              content_ids: [order.product_sku],
              content_type: 'product',
            },
          }],
        }),
      }
    )
  }
}

// Helper functions
async function md5(str: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(str)
  const hashBuffer = await crypto.subtle.digest('MD5', data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
}

async function sha256(str: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(str)
  const hashBuffer = await crypto.subtle.digest('SHA-256', data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
}

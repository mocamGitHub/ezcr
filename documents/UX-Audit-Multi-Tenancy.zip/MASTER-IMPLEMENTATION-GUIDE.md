# EZ Cycle Ramp — Complete Implementation Guide

## Project Summary

This package contains everything needed to transform the EZ Cycle Ramp website from a basic product page into a high-converting, automated sales machine.

---

## File Inventory

### UX Components & Copy
| File | Purpose |
|------|---------|
| `ezcycleramp-ux-components.jsx` | React components (trust badges, hero, comparison table, testimonials, product cards, configurator, mobile sticky CTA) |
| `ezcycleramp-components.html` | Same components in pure HTML/CSS for quick implementation |
| `ezcycleramp-ux-copy.md` | All copy, 48-hour checklist, implementation notes |

### Configurator
| File | Purpose |
|------|---------|
| `ezcycleramp-configurator-nextjs.tsx` | Full TypeScript configurator with analytics, Supabase integration, email capture variant |
| `ezcycleramp-configurator-vanilla.html` | Standalone HTML/JS version for testing |

### Video Production
| File | Purpose |
|------|---------|
| `ezcycleramp-video-script.md` | 90-second video script, shot list, voiceover notes, platform cuts |

### Lead Automation (Pre-Purchase)
| File | Purpose |
|------|---------|
| `ezcycleramp-supabase-functions.ts` | Edge function: lead processing, email marketing integrations (Mailchimp, ConvertKit, SendGrid, Klaviyo), Slack notifications |
| `n8n-workflow-lead-capture.json` | N8N workflow: initial lead routing and welcome email |
| `n8n-workflow-email-sequences.json` | N8N workflow: scheduled drip email processor |
| `sendgrid-email-templates.html` | 4 lead nurture email templates (Day 0, 3, 7, 14) |
| `lead-automation-setup-guide.md` | Complete setup instructions |

### Conversion Tracking
| File | Purpose |
|------|---------|
| `supabase-purchase-webhook.ts` | Edge function: Stripe/Shopify webhook handler, marks leads as converted, triggers post-purchase flow |
| `ad-pixel-integration.tsx` | GA4, Meta Pixel, Google Ads tracking utilities |

### Post-Purchase Automation
| File | Purpose |
|------|---------|
| `n8n-workflow-post-purchase.json` | N8N workflow: order processing, onboarding sequence, review scheduling |
| `post-purchase-email-templates.html` | 4 post-purchase emails (confirmation, shipping, assembly tips, review request) |

### Analytics
| File | Purpose |
|------|---------|
| `analytics-dashboard-queries.sql` | SQL views for all key metrics |
| `analytics-dashboard-component.tsx` | React dashboard with charts |

---

## Implementation Roadmap

### Phase 1: Quick Wins (Day 1-2)
**Goal:** Fix trust-destroying issues and add basic conversion elements.

- [ ] Remove all Lorem Ipsum from the site
- [ ] Add prices to product cards ($2,495 / $2,795)
- [ ] Add trust badges bar above the fold
- [ ] Replace fake reviews with 3 real testimonials
- [ ] Simplify hero section (one headline, one CTA)

**Files needed:** `ezcycleramp-components.html`, `ezcycleramp-ux-copy.md`

---

### Phase 2: Configurator (Day 3-5)
**Goal:** Add interactive product recommendation tool.

- [ ] Deploy vanilla configurator for immediate testing
- [ ] Set up Supabase tables (run migrations)
- [ ] Integrate Next.js configurator component
- [ ] Add analytics tracking
- [ ] Test full flow end-to-end

**Files needed:** `ezcycleramp-configurator-vanilla.html` (test), `ezcycleramp-configurator-nextjs.tsx` (production)

---

### Phase 3: Lead Automation (Day 6-10)
**Goal:** Capture leads and nurture with email sequences.

- [ ] Deploy Supabase edge function (`handle-new-lead`)
- [ ] Create database webhook trigger
- [ ] Import N8N workflows
- [ ] Configure SendGrid templates
- [ ] Set up Slack notifications
- [ ] Test: submit lead → check all systems fire

**Files needed:** `ezcycleramp-supabase-functions.ts`, `n8n-workflow-lead-capture.json`, `n8n-workflow-email-sequences.json`, `sendgrid-email-templates.html`, `lead-automation-setup-guide.md`

---

### Phase 4: Conversion Tracking (Day 11-14)
**Goal:** Track ROI and enable remarketing.

- [ ] Add GA4 and Meta Pixel to site
- [ ] Implement tracking utility functions
- [ ] Set up Google Ads conversion tracking
- [ ] Create remarketing audiences
- [ ] Test: complete configurator → verify events fire

**Files needed:** `ad-pixel-integration.tsx`

---

### Phase 5: Purchase Integration (Day 15-20)
**Goal:** Connect payment system and trigger post-purchase flows.

- [ ] Deploy purchase webhook edge function
- [ ] Configure Stripe/Shopify webhook
- [ ] Mark leads as converted on purchase
- [ ] Stop nurture sequences for buyers
- [ ] Trigger post-purchase onboarding
- [ ] Schedule review requests (21 days)

**Files needed:** `supabase-purchase-webhook.ts`, `n8n-workflow-post-purchase.json`, `post-purchase-email-templates.html`

---

### Phase 6: Analytics & Optimization (Ongoing)
**Goal:** Measure and improve.

- [ ] Create Supabase views (run SQL)
- [ ] Deploy analytics dashboard
- [ ] Set up weekly reporting
- [ ] Identify drop-off points
- [ ] A/B test configurator questions
- [ ] Optimize email subject lines

**Files needed:** `analytics-dashboard-queries.sql`, `analytics-dashboard-component.tsx`

---

### Phase 7: Video Production (When Ready)
**Goal:** Create hero video for homepage and ads.

- [ ] Review video script
- [ ] Schedule shoot (3-4 hours)
- [ ] Capture all B-roll shots
- [ ] Edit 90-second hero version
- [ ] Create 30s and 15s ad cuts
- [ ] Upload and test on site

**Files needed:** `ezcycleramp-video-script.md`

---

## Environment Variables

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...

# Email Provider (pick one)
EMAIL_PROVIDER=sendgrid
SENDGRID_API_KEY=SG.xxx
SENDGRID_LIST_ID=xxx
SENDGRID_FROM_EMAIL=hello@ezcycleramp.com
SENDGRID_TEMPLATE_AUN200=d-xxx
SENDGRID_TEMPLATE_AUN250=d-xxx
# ... more templates

# N8N
N8N_WEBHOOK_URL=https://n8n.xxx.com/webhook/configurator-lead
N8N_ORDER_WEBHOOK_URL=https://n8n.xxx.com/webhook/order-completed

# Slack
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/xxx

# Payment
STRIPE_SECRET_KEY=sk_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx

# Analytics
NEXT_PUBLIC_GA4_MEASUREMENT_ID=G-xxx
NEXT_PUBLIC_META_PIXEL_ID=xxx
NEXT_PUBLIC_GOOGLE_ADS_ID=AW-xxx
NEXT_PUBLIC_GOOGLE_ADS_CONVERSION_LABEL=xxx

# Server-side tracking
GA4_API_SECRET=xxx
FB_PIXEL_ID=xxx
FB_ACCESS_TOKEN=EAAGxxx
```

---

## Database Schema Summary

```
configurator_leads
├── id (UUID)
├── email
├── recommendation (AUN200/AUN250/custom)
├── answers (JSONB)
├── converted_at
├── order_id
└── created_at

lead_sequences
├── id (UUID)
├── lead_id (FK)
├── email
├── sequence_name
├── current_step
├── status (active/completed/converted/unsubscribed)
├── next_send_at
└── created_at

email_log
├── id (UUID)
├── lead_id (FK)
├── template
├── status (sent/opened/clicked)
└── sent_at

orders
├── id (UUID)
├── order_id
├── email
├── product_sku
├── amount
├── lead_id (FK, nullable)
├── from_configurator (bool)
└── created_at

review_requests
├── id (UUID)
├── order_id
├── email
├── status (pending/sent/completed)
├── send_at
└── created_at
```

---

## Success Metrics

### Week 1
- [ ] Lorem Ipsum removed
- [ ] Prices visible
- [ ] Trust badges live
- [ ] Configurator deployed

### Week 2
- [ ] First leads captured
- [ ] Email sequences running
- [ ] Slack notifications working

### Month 1
- [ ] 100+ configurator completions
- [ ] Email open rate >30%
- [ ] First configurator-attributed sale

### Month 3
- [ ] Configurator conversion rate >5%
- [ ] 50% of sales from configurator leads
- [ ] Review request system generating 5+ reviews/month

---

## Support Contacts

- **Supabase Issues:** https://supabase.com/docs
- **N8N Issues:** https://docs.n8n.io
- **SendGrid Issues:** https://docs.sendgrid.com
- **Stripe Webhooks:** https://stripe.com/docs/webhooks

---

## Quick Commands

```bash
# Deploy Supabase edge function
supabase functions deploy handle-new-lead

# Test webhook locally
curl -X POST http://localhost:54321/functions/v1/handle-new-lead \
  -H "Content-Type: application/json" \
  -d '{"type":"INSERT","table":"configurator_leads","record":{"id":"test","email":"test@example.com","recommendation":"AUN250"}}'

# Check N8N webhook URL
curl -X POST https://your-n8n.com/webhook/configurator-lead \
  -H "Content-Type: application/json" \
  -d '{"lead":{"email":"test@example.com"}}'
```

---

This package represents a complete, production-ready system. Implement in phases, test thoroughly at each step, and iterate based on data.

Good luck! 🏍️

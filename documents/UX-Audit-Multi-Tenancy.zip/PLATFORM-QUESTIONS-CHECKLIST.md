# Platform Questions Checklist for EZ Cycle Ramp

> **Purpose:** Questions that need answers before tenant work can proceed effectively.
> **Context:** EZ Cycle Ramp is a tenant on a multi-tenant platform. Many assumptions in created assets depend on platform capabilities.

---

## 🚨 CRITICAL: Must Answer Before Launch

### 1. Can Customers Buy Today?

| Question | Answer | Notes |
|----------|--------|-------|
| Is checkout flow complete and working on staging? | | |
| Can a test purchase be completed end-to-end? | | |
| Does order confirmation email send automatically? | | |
| Is there any Lorem Ipsum or placeholder text visible? | | |

### 2. Payment Processing

| Question | Answer | Notes |
|----------|--------|-------|
| How do we connect our Stripe account to the platform? | | |
| What credentials do you need from us? (API keys, webhook secret) | | |
| Is Stripe already integrated at platform level? | | |
| Do we create our own Stripe account, or use a platform sub-account? | | |
| Are webhooks already configured to handle purchases? | | |

### 3. Product & Content Management

| Question | Answer | Notes |
|----------|--------|-------|
| How do we add/edit products? (Admin panel? CMS? Database?) | | |
| How do we upload product images? | | |
| How do we update copy/text on pages? | | |
| Can we edit meta descriptions for SEO? | | |
| Is there a staging environment we can preview changes in? | | |

---

## 🔶 HIGH PRIORITY: Should Answer Within First Week

### 4. Email Marketing

| Question | Answer | Notes |
|----------|--------|-------|
| Is there a shared SendGrid account for all tenants? | | |
| What format do you need for email templates? (HTML? Specific structure?) | | |
| How do we configure email sequences? (Admin UI? Config file?) | | |
| What dynamic variables are available? ({{first_name}}, {{product_name}}, etc.) | | |
| Can we customize the "From" name and email address? | | |
| How is unsubscribe handled? | | |
| Can we see email analytics (opens, clicks)? | | |

### 5. Lead Capture & Automation

| Question | Answer | Notes |
|----------|--------|-------|
| When someone submits the configurator, where does that data go? | | |
| How do we configure what happens when a lead is captured? | | |
| Can we set up drip email sequences? How? | | |
| Can we get Slack/email notifications for new leads? | | |
| Is there lead scoring or prioritization? | | |

### 6. Analytics & Tracking

| Question | Answer | Notes |
|----------|--------|-------|
| Where do we enter our GA4 Measurement ID? | | |
| Where do we enter our Meta Pixel ID? | | |
| Where do we enter Google Ads Conversion ID/Labels? | | |
| What events are already tracked by the platform? | | |
| Can we add custom events? | | |
| Is there an analytics dashboard in the admin? | | |

### 7. Post-Purchase Flow

| Question | Answer | Notes |
|----------|--------|-------|
| What happens automatically when an order is placed? | | |
| Does order confirmation email send automatically? | | |
| Does shipping confirmation email send automatically? | | |
| Can we configure post-purchase email sequences? | | |
| How do we trigger review request emails? | | |

---

## 🔷 MEDIUM PRIORITY: Good to Know Soon

### 8. Abandoned Cart

| Question | Answer | Notes |
|----------|--------|-------|
| Does the platform support abandoned cart detection? | | |
| If yes, how do we configure abandoned cart emails? | | |
| What triggers count as "abandoned"? (Time? Page exit?) | | |
| Can we customize the timing? (1hr, 24hr, 72hr, 7 days) | | |

### 9. Checkout Customization

| Question | Answer | Notes |
|----------|--------|-------|
| Can we add custom fields to checkout? (e.g., truck bed length) | | |
| Can we add Affirm/Klarna buy-now-pay-later? | | |
| Can we offer PayPal, Apple Pay, Google Pay? | | |
| Can we display trust badges at checkout? | | |

### 10. Legal Pages

| Question | Answer | Notes |
|----------|--------|-------|
| How do we update Privacy Policy content? | | |
| How do we update Terms of Service content? | | |
| How do we update Return Policy content? | | |
| Is cookie consent handled by the platform? | | |

### 11. Customer Support Features

| Question | Answer | Notes |
|----------|--------|-------|
| Is there a built-in contact form? | | |
| Can we integrate live chat (Intercom, Tidio, etc.)? | | |
| Is there a help center / knowledge base feature? | | |
| How do customers track their orders? | | |

### 12. Admin Dashboard

| Question | Answer | Notes |
|----------|--------|-------|
| What reports/analytics are available in admin? | | |
| Can we see order history? | | |
| Can we see customer list? | | |
| Can we see lead list from configurator? | | |
| Can we export data? | | |

---

## 🔹 LOWER PRIORITY: Can Ask Later

### 13. Future Features

| Question | Answer | Notes |
|----------|--------|-------|
| Is referral program functionality available or planned? | | |
| Is there a reviews/ratings system? | | |
| Can we create discount/promo codes? | | |
| Is there blog/content functionality? | | |
| Can we do A/B testing? | | |

### 14. Technical Details

| Question | Answer | Notes |
|----------|--------|-------|
| What's the tech stack? (Next.js? Supabase? etc.) | | |
| Can we add custom React components? | | |
| Is there a component library or design system we should use? | | |
| How do deployments work? | | |
| Is there a staging vs production environment? | | |

### 15. Multi-Tenant Specifics

| Question | Answer | Notes |
|----------|--------|-------|
| What data is isolated per tenant? | | |
| What data/features are shared across tenants? | | |
| Can tenants see each other's data? (Should be NO) | | |
| How is tenant identified? (subdomain? path? database field?) | | |

---

## 📋 INFORMATION WE NEED TO PROVIDE

Once platform questions are answered, EZ Cycle Ramp needs to provide:

### Definitely Needed

| Item | Status | Notes |
|------|--------|-------|
| Stripe account credentials | ☐ | |
| GA4 Measurement ID | ☐ | Create at analytics.google.com |
| Meta Pixel ID | ☐ | Create in Meta Business Manager |
| Google Ads Conversion ID | ☐ | If running Google Ads |
| Product content (copy, specs, prices) | ☐ | Files created, need review |
| Product images (hero, gallery) | ☐ | Need to shoot/collect |
| Real customer testimonials | ☐ | **CRITICAL** — currently fake |
| Logo files | ☐ | Various formats |
| Brand colors | ☐ | Hex codes |

### Probably Needed

| Item | Status | Notes |
|------|--------|-------|
| Email template content | ☐ | Files created, need review |
| FAQ content | ☐ | Files created, need review |
| Privacy policy text | ☐ | Need legal review |
| Terms of service text | ☐ | Need legal review |
| Return policy text | ☐ | Need to define policy |
| Warranty terms | ☐ | Need to define/verify |

### Nice to Have

| Item | Status | Notes |
|------|--------|-------|
| Video content | ☐ | Script created, need to shoot |
| Ad creative images | ☐ | For Meta/Google campaigns |
| Social media accounts | ☐ | For integrations |

---

## 📞 RECOMMENDED: Schedule Platform Call

Instead of asking these questions one-by-one, recommend scheduling a 30-60 minute call with the platform team to go through:

1. **Demo of admin dashboard** — See what's already available
2. **Checkout flow walkthrough** — Verify it works
3. **Content management demo** — How to update products/copy
4. **Email configuration** — How sequences work
5. **Analytics setup** — Where to enter tracking IDs
6. **Timeline discussion** — What's ready vs in development

---

## ✅ AFTER PLATFORM CALL: Update This Document

| Date | Who Attended | Key Decisions |
|------|--------------|---------------|
| | | |

### Platform Capabilities Confirmed
- [ ] Checkout works
- [ ] Payment processing ready
- [ ] Email sequences supported
- [ ] Analytics integration available
- [ ] Abandoned cart supported
- [ ] Custom checkout fields possible

### Features Not Available (Must Work Around)
- 
- 
- 

### Features In Development (Wait For)
- 
- 
- 

---

**End of Document**

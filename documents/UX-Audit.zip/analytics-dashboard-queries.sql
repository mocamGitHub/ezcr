-- ============================================
-- EZ CYCLE RAMP — ANALYTICS DASHBOARD QUERIES
-- Run these in Supabase SQL Editor or create as views
-- ============================================

-- ---------------------------------------------
-- 1. CONFIGURATOR FUNNEL METRICS
-- ---------------------------------------------

-- Daily configurator completions
CREATE OR REPLACE VIEW v_daily_configurator_completions AS
SELECT 
  DATE(created_at) as date,
  COUNT(*) as total_leads,
  COUNT(CASE WHEN recommendation = 'AUN200' THEN 1 END) as aun200_recommendations,
  COUNT(CASE WHEN recommendation = 'AUN250' THEN 1 END) as aun250_recommendations,
  COUNT(CASE WHEN recommendation = 'custom' THEN 1 END) as custom_recommendations,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions,
  ROUND(
    COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(*), 0) * 100, 
    2
  ) as conversion_rate
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '90 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;

-- Conversion funnel by recommendation
CREATE OR REPLACE VIEW v_conversion_by_recommendation AS
SELECT 
  COALESCE(recommendation, 'none') as recommendation,
  COUNT(*) as total_leads,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions,
  ROUND(
    COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(*), 0) * 100, 
    2
  ) as conversion_rate,
  ROUND(AVG(
    CASE WHEN converted_at IS NOT NULL 
    THEN EXTRACT(EPOCH FROM (converted_at - created_at)) / 86400 
    END
  ), 1) as avg_days_to_convert
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '90 days'
GROUP BY recommendation
ORDER BY total_leads DESC;

-- ---------------------------------------------
-- 2. EMAIL SEQUENCE PERFORMANCE
-- ---------------------------------------------

-- Email performance by template
CREATE OR REPLACE VIEW v_email_performance AS
SELECT 
  template,
  COUNT(*) as sent,
  COUNT(CASE WHEN status = 'opened' THEN 1 END) as opened,
  COUNT(CASE WHEN status = 'clicked' THEN 1 END) as clicked,
  ROUND(
    COUNT(CASE WHEN status = 'opened' THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(*), 0) * 100, 
    1
  ) as open_rate,
  ROUND(
    COUNT(CASE WHEN status = 'clicked' THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(CASE WHEN status = 'opened' THEN 1 END), 0) * 100, 
    1
  ) as click_to_open_rate
FROM email_log
WHERE sent_at > NOW() - INTERVAL '30 days'
GROUP BY template
ORDER BY sent DESC;

-- Sequence completion rates
CREATE OR REPLACE VIEW v_sequence_completion AS
SELECT 
  sequence_name,
  COUNT(*) as total_sequences,
  COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
  COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
  COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted,
  COUNT(CASE WHEN status = 'unsubscribed' THEN 1 END) as unsubscribed,
  ROUND(
    COUNT(CASE WHEN status = 'converted' THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(*), 0) * 100, 
    1
  ) as sequence_conversion_rate
FROM lead_sequences
WHERE created_at > NOW() - INTERVAL '90 days'
GROUP BY sequence_name;

-- ---------------------------------------------
-- 3. REVENUE ATTRIBUTION
-- ---------------------------------------------

-- Revenue by source
CREATE OR REPLACE VIEW v_revenue_attribution AS
SELECT 
  CASE 
    WHEN o.from_configurator AND l.recommendation = o.product_sku THEN 'Configurator (matched)'
    WHEN o.from_configurator THEN 'Configurator (different product)'
    ELSE 'Direct'
  END as attribution,
  COUNT(*) as orders,
  SUM(o.amount) as total_revenue,
  ROUND(AVG(o.amount), 2) as avg_order_value
FROM orders o
LEFT JOIN configurator_leads l ON o.lead_id = l.id
WHERE o.created_at > NOW() - INTERVAL '90 days'
GROUP BY 
  CASE 
    WHEN o.from_configurator AND l.recommendation = o.product_sku THEN 'Configurator (matched)'
    WHEN o.from_configurator THEN 'Configurator (different product)'
    ELSE 'Direct'
  END
ORDER BY total_revenue DESC;

-- Monthly revenue trend
CREATE OR REPLACE VIEW v_monthly_revenue AS
SELECT 
  DATE_TRUNC('month', created_at) as month,
  COUNT(*) as orders,
  SUM(amount) as revenue,
  COUNT(CASE WHEN from_configurator THEN 1 END) as configurator_orders,
  SUM(CASE WHEN from_configurator THEN amount ELSE 0 END) as configurator_revenue
FROM orders
WHERE created_at > NOW() - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', created_at)
ORDER BY month DESC;

-- ---------------------------------------------
-- 4. ANSWER ANALYSIS (What trucks/bikes are popular?)
-- ---------------------------------------------

-- Bed length distribution
CREATE OR REPLACE VIEW v_bed_length_distribution AS
SELECT 
  answers->>'bedLength' as bed_length,
  COUNT(*) as count,
  ROUND(COUNT(*)::NUMERIC / SUM(COUNT(*)) OVER () * 100, 1) as percentage,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '90 days'
  AND answers->>'bedLength' IS NOT NULL
GROUP BY answers->>'bedLength'
ORDER BY count DESC;

-- Bike weight distribution
CREATE OR REPLACE VIEW v_bike_weight_distribution AS
SELECT 
  answers->>'bikeWeight' as bike_weight,
  COUNT(*) as count,
  ROUND(COUNT(*)::NUMERIC / SUM(COUNT(*)) OVER () * 100, 1) as percentage,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '90 days'
  AND answers->>'bikeWeight' IS NOT NULL
GROUP BY answers->>'bikeWeight'
ORDER BY count DESC;

-- Tailgate requirement
CREATE OR REPLACE VIEW v_tailgate_distribution AS
SELECT 
  answers->>'tailgateRequired' as tailgate_required,
  COUNT(*) as count,
  ROUND(COUNT(*)::NUMERIC / SUM(COUNT(*)) OVER () * 100, 1) as percentage,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '90 days'
  AND answers->>'tailgateRequired' IS NOT NULL
GROUP BY answers->>'tailgateRequired'
ORDER BY count DESC;

-- ---------------------------------------------
-- 5. TIME-BASED ANALYSIS
-- ---------------------------------------------

-- Hour of day analysis (when do people use configurator?)
CREATE OR REPLACE VIEW v_hourly_activity AS
SELECT 
  EXTRACT(HOUR FROM created_at) as hour,
  COUNT(*) as leads,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions,
  ROUND(
    COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(*), 0) * 100, 
    1
  ) as conversion_rate
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '90 days'
GROUP BY EXTRACT(HOUR FROM created_at)
ORDER BY hour;

-- Day of week analysis
CREATE OR REPLACE VIEW v_day_of_week_activity AS
SELECT 
  TO_CHAR(created_at, 'Day') as day_of_week,
  EXTRACT(DOW FROM created_at) as day_number,
  COUNT(*) as leads,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions,
  ROUND(
    COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(*), 0) * 100, 
    1
  ) as conversion_rate
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '90 days'
GROUP BY TO_CHAR(created_at, 'Day'), EXTRACT(DOW FROM created_at)
ORDER BY day_number;

-- ---------------------------------------------
-- 6. EXECUTIVE SUMMARY (Single query for dashboard header)
-- ---------------------------------------------

CREATE OR REPLACE VIEW v_executive_summary AS
SELECT 
  -- This week
  (SELECT COUNT(*) FROM configurator_leads WHERE created_at > NOW() - INTERVAL '7 days') as leads_this_week,
  (SELECT COUNT(*) FROM orders WHERE created_at > NOW() - INTERVAL '7 days') as orders_this_week,
  (SELECT COALESCE(SUM(amount), 0) FROM orders WHERE created_at > NOW() - INTERVAL '7 days') as revenue_this_week,
  
  -- This month
  (SELECT COUNT(*) FROM configurator_leads WHERE created_at > NOW() - INTERVAL '30 days') as leads_this_month,
  (SELECT COUNT(*) FROM orders WHERE created_at > NOW() - INTERVAL '30 days') as orders_this_month,
  (SELECT COALESCE(SUM(amount), 0) FROM orders WHERE created_at > NOW() - INTERVAL '30 days') as revenue_this_month,
  
  -- Conversion rate
  (SELECT ROUND(
    COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END)::NUMERIC / 
    NULLIF(COUNT(*), 0) * 100, 1
  ) FROM configurator_leads WHERE created_at > NOW() - INTERVAL '30 days') as conversion_rate_30d,
  
  -- Active sequences
  (SELECT COUNT(*) FROM lead_sequences WHERE status = 'active') as active_sequences,
  
  -- Pending review requests
  (SELECT COUNT(*) FROM review_requests WHERE status = 'pending' AND send_at <= NOW() + INTERVAL '7 days') as pending_reviews;

-- ---------------------------------------------
-- 7. REAL-TIME DASHBOARD QUERY
-- Run this to get all key metrics in one call
-- ---------------------------------------------

-- Usage: SELECT * FROM get_dashboard_metrics();
CREATE OR REPLACE FUNCTION get_dashboard_metrics()
RETURNS JSON AS $$
DECLARE
  result JSON;
BEGIN
  SELECT json_build_object(
    'summary', (SELECT row_to_json(t) FROM v_executive_summary t),
    'daily_leads', (SELECT json_agg(t) FROM (SELECT * FROM v_daily_configurator_completions LIMIT 30) t),
    'conversion_by_recommendation', (SELECT json_agg(t) FROM v_conversion_by_recommendation t),
    'email_performance', (SELECT json_agg(t) FROM v_email_performance t),
    'revenue_attribution', (SELECT json_agg(t) FROM v_revenue_attribution t),
    'bed_length_distribution', (SELECT json_agg(t) FROM v_bed_length_distribution t),
    'bike_weight_distribution', (SELECT json_agg(t) FROM v_bike_weight_distribution t)
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

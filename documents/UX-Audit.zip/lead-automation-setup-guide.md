# EZ Cycle Ramp — Lead Automation Setup Guide

## Overview

This guide walks you through setting up the complete lead capture and follow-up automation system for the configurator. The system includes:

1. **Supabase** — Database for leads + edge functions for integrations
2. **N8N** — Workflow automation for email sequences
3. **SendGrid** (or alternative) — Transactional and marketing emails
4. **Slack** — Sales team notifications

---

## Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   Configurator  │────▶│    Supabase      │────▶│   N8N Webhook   │
│   (Next.js)     │     │  (PostgreSQL)    │     │                 │
└─────────────────┘     └──────────────────┘     └─────────────────┘
                               │                        │
                               ▼                        ▼
                        ┌──────────────────┐     ┌─────────────────┐
                        │  Edge Function   │     │  Email Sequence │
                        │  (handle-lead)   │     │  Processor      │
                        └──────────────────┘     └─────────────────┘
                               │                        │
                    ┌──────────┼──────────┐            │
                    ▼          ▼          ▼            ▼
              ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐
              │SendGrid │ │ Slack   │ │Mailchimp│ │SendGrid │
              │(welcome)│ │(notify) │ │(list)   │ │(drip)   │
              └─────────┘ └─────────┘ └─────────┘ └─────────┘
```

---

## Step 1: Supabase Database Setup

### 1.1 Create Tables

Run these migrations in your Supabase SQL editor:

```sql
-- Lead capture from configurator
CREATE TABLE configurator_leads (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  recommendation TEXT, -- 'AUN200', 'AUN250', 'custom'
  answers JSONB,
  ip_address TEXT,
  user_agent TEXT,
  processed_at TIMESTAMPTZ,
  integrations_status JSONB,
  converted_at TIMESTAMPTZ,
  order_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Email sequence tracking
CREATE TABLE lead_sequences (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id UUID REFERENCES configurator_leads(id),
  email TEXT NOT NULL,
  recommendation TEXT,
  sequence_name TEXT NOT NULL, -- 'aun200_nurture', 'aun250_nurture', 'custom_outreach'
  current_step INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active', -- 'active', 'paused', 'completed', 'unsubscribed'
  next_send_at TIMESTAMPTZ,
  last_sent_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Email send log
CREATE TABLE email_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id UUID REFERENCES configurator_leads(id),
  sequence_id UUID REFERENCES lead_sequences(id),
  email TEXT NOT NULL,
  template TEXT,
  subject TEXT,
  step INTEGER,
  status TEXT DEFAULT 'sent', -- 'sent', 'opened', 'clicked', 'bounced'
  sent_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_leads_email ON configurator_leads(email);
CREATE INDEX idx_leads_created ON configurator_leads(created_at DESC);
CREATE INDEX idx_sequences_next_send ON lead_sequences(next_send_at) WHERE status = 'active';
CREATE INDEX idx_sequences_status ON lead_sequences(status);

-- RLS Policies
ALTER TABLE configurator_leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_sequences ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_log ENABLE ROW LEVEL SECURITY;

-- Service role access only
CREATE POLICY "Service role full access" ON configurator_leads
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "Service role full access" ON lead_sequences
  FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY "Service role full access" ON email_log
  FOR ALL TO service_role USING (true) WITH CHECK (true);
```

### 1.2 Create Database Webhook

1. Go to **Database → Webhooks** in Supabase dashboard
2. Click **Create a new webhook**
3. Configure:
   - **Name:** `configurator_lead_inserted`
   - **Table:** `configurator_leads`
   - **Events:** `INSERT`
   - **Type:** `Edge Function`
   - **Edge Function:** `handle-new-lead`

### 1.3 Deploy Edge Function

```bash
# From your project root
supabase functions new handle-new-lead

# Copy the edge function code from ezcycleramp-supabase-functions.ts
# to supabase/functions/handle-new-lead/index.ts

# Deploy
supabase functions deploy handle-new-lead
```

### 1.4 Set Edge Function Secrets

```bash
# Email provider (choose one)
supabase secrets set EMAIL_PROVIDER=sendgrid

# SendGrid
supabase secrets set SENDGRID_API_KEY=SG.xxxxx
supabase secrets set SENDGRID_LIST_ID=your-list-id
supabase secrets set SENDGRID_FROM_EMAIL=hello@ezcycleramp.com
supabase secrets set SENDGRID_TEMPLATE_AUN200=d-xxxxx
supabase secrets set SENDGRID_TEMPLATE_AUN250=d-xxxxx
supabase secrets set SENDGRID_TEMPLATE_CUSTOM=d-xxxxx

# OR Mailchimp
supabase secrets set MAILCHIMP_API_KEY=xxxxx-us1
supabase secrets set MAILCHIMP_LIST_ID=xxxxx

# OR ConvertKit
supabase secrets set CONVERTKIT_API_KEY=xxxxx
supabase secrets set CONVERTKIT_FORM_ID=xxxxx

# OR Klaviyo
supabase secrets set KLAVIYO_API_KEY=xxxxx
supabase secrets set KLAVIYO_LIST_ID=xxxxx

# N8N Webhook
supabase secrets set N8N_WEBHOOK_URL=https://your-n8n.com/webhook/configurator-lead

# Slack (optional)
supabase secrets set SLACK_WEBHOOK_URL=https://hooks.slack.com/services/xxx/xxx/xxx
```

---

## Step 2: N8N Setup

### 2.1 Import Workflows

1. Open your N8N instance (e.g., `https://n8n.ezcycleramp.com`)
2. Go to **Settings → Import from File**
3. Import both workflow JSON files:
   - `n8n-workflow-lead-capture.json`
   - `n8n-workflow-email-sequences.json`

### 2.2 Configure Credentials

In N8N, create these credentials:

**Supabase:**
- Type: `Supabase`
- Host: `https://your-project.supabase.co`
- Service Role Key: `eyJhbGci...` (from Supabase dashboard → Settings → API)

**SendGrid:**
- Type: `SendGrid API`
- API Key: `SG.xxxxx`

**Slack:**
- Type: `Slack API`
- Access Token or Webhook URL

### 2.3 Update Node Credential References

In each workflow, update the credential IDs in nodes:
- Replace `SUPABASE_CREDENTIAL_ID` with your actual credential ID
- Replace `SENDGRID_CREDENTIAL_ID` with your actual credential ID
- Replace `SLACK_CREDENTIAL_ID` with your actual credential ID

### 2.4 Get Your Webhook URL

1. Open the "Lead Capture" workflow
2. Click the webhook node
3. Copy the **Production URL** (e.g., `https://n8n.ezcycleramp.com/webhook/configurator-lead`)
4. Add this URL to Supabase secrets:

```bash
supabase secrets set N8N_WEBHOOK_URL=https://n8n.ezcycleramp.com/webhook/configurator-lead
```

### 2.5 Activate Workflows

1. Toggle both workflows to **Active**
2. The "Email Sequence Processor" runs every hour automatically

---

## Step 3: SendGrid Email Templates

### 3.1 Create Dynamic Templates

Create these templates in SendGrid:

| Template | Purpose | Key Variables |
|----------|---------|---------------|
| `welcome_aun200` | Day 0 - Initial recommendation | `recommendation`, `product_url`, `price` |
| `welcome_aun250` | Day 0 - Initial recommendation | `recommendation`, `product_url`, `price` |
| `day1_value_prop` | Day 1 - Value proposition | `product_name`, `product_url` |
| `day3_social_proof` | Day 3 - Testimonials | `product_name` |
| `day7_faq` | Day 7 - FAQ + objection handling | `product_name`, `product_url` |
| `day14_last_chance` | Day 14 - Final nudge | `product_name`, `product_url`, `price` |

### 3.2 Template Example (Day 1)

```html
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    .cta { background: #f59e0b; color: #000; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; }
  </style>
</head>
<body style="padding: 40px;">
  <img src="https://ezcycleramp.com/logo.png" alt="EZ Cycle Ramp" width="150">
  
  <h1 style="color: #f59e0b;">Your {{recommendation}} Is Waiting</h1>
  
  <p>Hey there,</p>
  
  <p>You completed our configurator and we recommended the <strong>{{product_name}}</strong> for your setup.</p>
  
  <p>Here's what makes it perfect for you:</p>
  
  <ul>
    <li>✓ Load solo—no spotter needed</li>
    <li>✓ Up to 1,200 lb capacity</li>
    <li>✓ 2-year warranty</li>
    <li>✓ Free shipping</li>
  </ul>
  
  <p>
    <a href="{{product_url}}" class="cta">View Your Ramp →</a>
  </p>
  
  <p style="color: #666; font-size: 14px; margin-top: 40px;">
    Questions? Reply to this email or call (937) 725-6790.
  </p>
  
  <p style="color: #999; font-size: 12px; margin-top: 40px;">
    <a href="{{unsubscribe_url}}">Unsubscribe</a>
  </p>
</body>
</html>
```

---

## Step 4: Next.js Integration

### 4.1 Environment Variables

Add to `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci... (server-side only)
```

### 4.2 Add Configurator to Page

```tsx
// app/page.tsx or wherever you want the configurator
import { Configurator } from '@/components/configurator/Configurator';
// OR with email capture:
import { ConfiguratorWithEmail } from '@/components/configurator/ConfiguratorWithEmail';

export default function HomePage() {
  return (
    <main>
      {/* Hero, trust badges, etc. */}
      
      <Configurator />
      
      {/* Comparison table, testimonials, etc. */}
    </main>
  );
}
```

---

## Step 5: Testing

### 5.1 Test the Full Flow

1. **Submit test lead:**
   ```bash
   curl -X POST https://your-site.com/api/configurator \
     -H "Content-Type: application/json" \
     -d '{
       "email": "test@example.com",
       "recommendation": "AUN250",
       "answers": {
         "bedLength": "short",
         "bikeWeight": "heavy",
         "tailgateRequired": "yes"
       }
     }'
   ```

2. **Check Supabase:**
   - New row in `configurator_leads`
   - New row in `lead_sequences`

3. **Check N8N:**
   - Execution history shows webhook received
   - Slack notification sent (if configured)

4. **Check email:**
   - Welcome email received

### 5.2 Test Email Sequence

1. Update a sequence to trigger soon:
   ```sql
   UPDATE lead_sequences 
   SET next_send_at = NOW() - INTERVAL '1 minute'
   WHERE email = 'test@example.com';
   ```

2. Wait for N8N hourly trigger (or manually execute)

3. Check:
   - Email sent
   - `current_step` incremented
   - `next_send_at` updated
   - Row added to `email_log`

---

## Step 6: Monitoring

### 6.1 Supabase Dashboard

Create a simple dashboard view:

```sql
-- Active sequences by recommendation
SELECT 
  recommendation,
  COUNT(*) as active_leads
FROM lead_sequences
WHERE status = 'active'
GROUP BY recommendation;

-- Conversion funnel
SELECT 
  DATE(created_at) as date,
  COUNT(*) as leads,
  COUNT(CASE WHEN converted_at IS NOT NULL THEN 1 END) as conversions
FROM configurator_leads
WHERE created_at > NOW() - INTERVAL '30 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;

-- Email performance
SELECT 
  template,
  COUNT(*) as sent,
  COUNT(CASE WHEN status = 'opened' THEN 1 END) as opened,
  COUNT(CASE WHEN status = 'clicked' THEN 1 END) as clicked
FROM email_log
WHERE sent_at > NOW() - INTERVAL '30 days'
GROUP BY template;
```

### 6.2 Slack Alerts

Add error alerting to N8N workflows:
- On SendGrid failure → Slack alert
- On Supabase failure → Slack alert

---

## Troubleshooting

### Common Issues

| Issue | Solution |
|-------|----------|
| Webhook not triggering | Check Supabase webhook is enabled, check N8N webhook URL is correct |
| Emails not sending | Verify SendGrid API key, check template IDs, check From email is verified |
| Sequences not processing | Ensure N8N workflow is active, check `next_send_at` timestamps |
| Duplicate leads | Add unique constraint on email or implement upsert logic |

### Logs

- **Supabase Edge Functions:** Dashboard → Functions → Logs
- **N8N:** Executions tab in each workflow
- **SendGrid:** Activity → Email Activity

---

## Next Steps

1. [ ] Set up SendGrid email templates
2. [ ] Configure Slack channel for notifications
3. [ ] Add conversion tracking (mark `converted_at` when order placed)
4. [ ] Set up A/B testing for email subject lines
5. [ ] Add unsubscribe handling
6. [ ] Create weekly report automation

---

## File Reference

| File | Purpose |
|------|---------|
| `ezcycleramp-supabase-functions.ts` | Edge function for lead processing |
| `n8n-workflow-lead-capture.json` | Initial lead capture + routing |
| `n8n-workflow-email-sequences.json` | Scheduled email sequence processor |
| `ezcycleramp-configurator-nextjs.tsx` | React configurator component |

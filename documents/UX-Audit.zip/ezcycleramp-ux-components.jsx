import React, { useState } from 'react';

// ============================================
// EZ CYCLE RAMP - UX IMPROVEMENT COMPONENTS
// Ready to integrate into your Next.js site
// ============================================

// ------------------------------------------
// 1. TRUST BADGES - Place above the fold
// ------------------------------------------
export function TrustBadges() {
  const badges = [
    { icon: "⚖️", value: "1,200 lb", label: "Load Capacity" },
    { icon: "🛡️", value: "2-Year", label: "Warranty" },
    { icon: "🇺🇸", value: "Made in", label: "USA" },
    { icon: "✈️", value: "Aerospace", label: "Grade Aluminum" },
  ];

  return (
    <div className="w-full bg-zinc-900 border-y border-zinc-800">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex flex-wrap justify-center gap-6 md:gap-12">
          {badges.map((badge, i) => (
            <div key={i} className="flex items-center gap-3 text-white">
              <span className="text-2xl">{badge.icon}</span>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-amber-500">{badge.value}</span>
                <span className="text-xs text-zinc-400 uppercase tracking-wider">{badge.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------
// 2. HERO SECTION - Clear value prop + CTA
// ------------------------------------------
export function HeroSection() {
  return (
    <section className="relative min-h-[80vh] bg-black overflow-hidden">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('/images/hero-ramp.webp')" }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
      </div>
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 py-24 md:py-32">
        <div className="max-w-2xl">
          {/* Tagline */}
          <p className="text-amber-500 font-medium tracking-wide uppercase mb-4">
            One-Person Motorcycle Loading
          </p>
          
          {/* Main headline */}
          <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
            Load Your Bike<br />
            <span className="text-amber-500">Without the Struggle</span>
          </h1>
          
          {/* Value prop */}
          <p className="text-xl text-zinc-300 mb-8 leading-relaxed">
            The automated ramp that slides, tilts, and lifts—so you never 
            have to ride your $30,000 bike up a sketchy plank again.
          </p>
          
          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4">
            <a 
              href="/shop" 
              className="inline-flex items-center justify-center px-8 py-4 bg-amber-500 hover:bg-amber-400 text-black font-bold text-lg rounded transition-colors"
            >
              Shop Ramps
              <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
            <a 
              href="#configurator" 
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-white/30 hover:border-white text-white font-medium text-lg rounded transition-colors"
            >
              Find Your Fit
            </a>
          </div>
          
          {/* Social proof teaser */}
          <p className="mt-8 text-zinc-500 text-sm">
            Trusted by 500+ riders • Ships in 3-5 business days
          </p>
        </div>
      </div>
    </section>
  );
}

// ------------------------------------------
// 3. COMPARISON TABLE - AUN 200 vs AUN 250
// ------------------------------------------
export function ComparisonTable() {
  const specs = [
    { 
      feature: "Best For", 
      aun200: "Full-size truck beds (6.5'+ beds)", 
      aun250: "Short-bed trucks (5.5' beds)",
      highlight: true 
    },
    { 
      feature: "Max Length", 
      aun200: "98\" (2500mm)", 
      aun250: "81\" (2060mm) — folds to fit" 
    },
    { 
      feature: "Weight Capacity", 
      aun200: "1,200 lbs", 
      aun250: "1,212 lbs" 
    },
    { 
      feature: "Load Height", 
      aun200: "Up to 36\" (60\" with extender)", 
      aun250: "Up to 36\" (60\" with extender)" 
    },
    { 
      feature: "Tailgate Compatible", 
      aun200: "Must remove tailgate or leave open", 
      aun250: "✓ Close tailgate with ramp installed",
      highlight: true 
    },
    { 
      feature: "Fat Tire Support", 
      aun200: "Up to 300mm rear tire", 
      aun250: "Up to 300mm rear tire" 
    },
    { 
      feature: "Material", 
      aun200: "T6 6061 Aerospace Aluminum", 
      aun250: "T6 6061 Aerospace Aluminum" 
    },
    { 
      feature: "Assembly Time", 
      aun200: "~4 hours (DIY kit)", 
      aun250: "~4 hours (DIY kit)" 
    },
    { 
      feature: "Starting Price", 
      aun200: "$2,495", 
      aun250: "$2,795",
      highlight: true 
    },
  ];

  return (
    <section className="py-16 bg-zinc-950">
      <div className="max-w-5xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Which Ramp Is Right for You?
          </h2>
          <p className="text-zinc-400 text-lg">
            Two models. Same quality. Choose based on your truck bed.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="p-4 text-left text-zinc-500 font-medium border-b border-zinc-800"></th>
                <th className="p-4 text-center border-b border-zinc-800">
                  <div className="text-amber-500 font-bold text-xl">AUN 200</div>
                  <div className="text-zinc-400 text-sm">Standard Ramp</div>
                </th>
                <th className="p-4 text-center border-b border-zinc-800 bg-amber-500/10">
                  <div className="text-amber-500 font-bold text-xl">AUN 250</div>
                  <div className="text-zinc-400 text-sm">Folding Ramp</div>
                  <span className="inline-block mt-1 px-2 py-0.5 bg-amber-500 text-black text-xs font-bold rounded">
                    MOST POPULAR
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {specs.map((row, i) => (
                <tr 
                  key={i} 
                  className={`border-b border-zinc-800 ${row.highlight ? 'bg-zinc-900/50' : ''}`}
                >
                  <td className="p-4 text-zinc-300 font-medium">{row.feature}</td>
                  <td className="p-4 text-center text-zinc-400">{row.aun200}</td>
                  <td className="p-4 text-center text-zinc-400 bg-amber-500/5">{row.aun250}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-center gap-4 mt-8">
          <a 
            href="/shop/aun-200" 
            className="px-6 py-3 border border-zinc-700 hover:border-amber-500 text-white rounded transition-colors"
          >
            View AUN 200
          </a>
          <a 
            href="/shop/aun-250" 
            className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded transition-colors"
          >
            View AUN 250
          </a>
        </div>
      </div>
    </section>
  );
}

// ------------------------------------------
// 4. TRUCK COMPATIBILITY SECTION
// ------------------------------------------
export function TruckCompatibility() {
  const trucks = [
    { name: "Ford F-150", beds: ["5.5' bed → AUN 250", "6.5' bed → AUN 200", "8' bed → AUN 200"] },
    { name: "Chevy Silverado", beds: ["5.8' bed → AUN 250", "6.5' bed → AUN 200", "8' bed → AUN 200"] },
    { name: "RAM 1500", beds: ["5.7' bed → AUN 250", "6.4' bed → AUN 200", "8' bed → AUN 200"] },
    { name: "Toyota Tundra", beds: ["5.5' bed → AUN 250", "6.5' bed → AUN 200", "8.1' bed → AUN 200"] },
    { name: "GMC Sierra", beds: ["5.8' bed → AUN 250", "6.5' bed → AUN 200", "8' bed → AUN 200"] },
    { name: "Nissan Titan", beds: ["5.5' bed → AUN 250", "6.5' bed → AUN 200"] },
  ];

  return (
    <section className="py-16 bg-zinc-900">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Fits Your Truck
          </h2>
          <p className="text-zinc-400 text-lg">
            Compatible with most full-size pickups, vans, and trailers
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {trucks.map((truck, i) => (
            <div 
              key={i} 
              className="p-4 bg-zinc-800/50 border border-zinc-700 rounded-lg hover:border-amber-500/50 transition-colors"
            >
              <h3 className="text-white font-bold mb-2">{truck.name}</h3>
              <ul className="space-y-1">
                {truck.beds.map((bed, j) => (
                  <li key={j} className="text-sm text-zinc-400">
                    {bed}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p className="text-center mt-8 text-zinc-500">
          Don't see your truck? <a href="/contact" className="text-amber-500 hover:underline">Contact us</a> — we custom-cut ramps to fit.
        </p>
      </div>
    </section>
  );
}

// ------------------------------------------
// 5. TESTIMONIALS - Replace Lorem Ipsum!
// ------------------------------------------
export function Testimonials() {
  const reviews = [
    {
      name: "Mike R.",
      location: "Dallas, TX",
      bike: "2022 Harley Road Glide",
      text: "I'm 62 years old and loading my bagger was becoming a real problem. This ramp changed everything. Push a button, walk the bike up, done. Worth every penny.",
      rating: 5,
    },
    {
      name: "Jason T.",
      location: "Phoenix, AZ", 
      bike: "BMW R1250GS Adventure",
      text: "Tried three different ramp systems before finding EZ Cycle. The folding design fits perfectly in my Silverado short bed, and I can actually close the tailgate. Game changer for road trips.",
      rating: 5,
    },
    {
      name: "Carlos M.",
      location: "Atlanta, GA",
      bike: "Indian Chieftain",
      text: "The build quality is impressive—aerospace aluminum isn't marketing fluff. Had it for 8 months now, zero issues. Customer service helped me dial in the setup for my specific truck.",
      rating: 5,
    },
  ];

  return (
    <section className="py-16 bg-black">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            What Riders Are Saying
          </h2>
          <div className="flex items-center justify-center gap-1 text-amber-500">
            {[...Array(5)].map((_, i) => (
              <svg key={i} className="w-6 h-6 fill-current" viewBox="0 0 20 20">
                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
              </svg>
            ))}
            <span className="ml-2 text-white font-medium">4.9/5 from verified buyers</span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((review, i) => (
            <div 
              key={i} 
              className="p-6 bg-zinc-900 border border-zinc-800 rounded-lg"
            >
              {/* Stars */}
              <div className="flex gap-1 text-amber-500 mb-4">
                {[...Array(review.rating)].map((_, j) => (
                  <svg key={j} className="w-5 h-5 fill-current" viewBox="0 0 20 20">
                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                  </svg>
                ))}
              </div>
              
              {/* Quote */}
              <p className="text-zinc-300 mb-4 leading-relaxed">"{review.text}"</p>
              
              {/* Author */}
              <div className="border-t border-zinc-800 pt-4">
                <p className="text-white font-medium">{review.name}</p>
                <p className="text-zinc-500 text-sm">{review.location}</p>
                <p className="text-amber-500/70 text-sm">{review.bike}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ------------------------------------------
// 6. PRODUCT CARD - With visible pricing
// ------------------------------------------
export function ProductCard({ product }) {
  // Default product for demo
  const p = product || {
    name: "AUN 250 Folding Ramp",
    tagline: "Best for Short-Bed Trucks",
    price: 2795,
    image: "/images/aun-250.webp",
    badge: "Most Popular",
    specs: [
      "Up to 1,212 lb capacity",
      "Fits 5.5' truck beds",
      "Close tailgate with ramp installed",
      "4-hour DIY assembly"
    ]
  };

  return (
    <div className="group bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden hover:border-amber-500/50 transition-all">
      {/* Badge */}
      {p.badge && (
        <div className="bg-amber-500 text-black text-xs font-bold px-3 py-1 text-center">
          {p.badge}
        </div>
      )}
      
      {/* Image */}
      <div className="aspect-video bg-zinc-800 overflow-hidden">
        <img 
          src={p.image} 
          alt={p.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>
      
      {/* Content */}
      <div className="p-6">
        <p className="text-amber-500 text-sm font-medium mb-1">{p.tagline}</p>
        <h3 className="text-xl font-bold text-white mb-2">{p.name}</h3>
        
        {/* Specs */}
        <ul className="space-y-1 mb-4">
          {p.specs.map((spec, i) => (
            <li key={i} className="text-zinc-400 text-sm flex items-center gap-2">
              <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              {spec}
            </li>
          ))}
        </ul>
        
        {/* Price */}
        <div className="flex items-baseline gap-2 mb-4">
          <span className="text-3xl font-bold text-white">${p.price.toLocaleString()}</span>
          <span className="text-zinc-500 text-sm">+ free shipping</span>
        </div>
        
        {/* CTA */}
        <div className="flex gap-2">
          <a 
            href={`/shop/${p.name.toLowerCase().replace(/\s+/g, '-')}`}
            className="flex-1 py-3 bg-amber-500 hover:bg-amber-400 text-black font-bold text-center rounded transition-colors"
          >
            Buy Now
          </a>
          <button 
            className="px-4 py-3 border border-zinc-700 hover:border-zinc-500 text-white rounded transition-colors"
            aria-label="View details"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------
// 7. QUICK CONFIGURATOR - Find Your Ramp
// ------------------------------------------
export function QuickConfigurator() {
  const [step, setStep] = useState(1);
  const [answers, setAnswers] = useState({});

  const questions = [
    {
      id: 'bedLength',
      question: "What's your truck bed length?",
      options: [
        { value: 'short', label: "Short bed (5-5.8')", recommendation: 'AUN 250' },
        { value: 'standard', label: "Standard bed (6-6.5')", recommendation: 'AUN 200' },
        { value: 'long', label: "Long bed (8'+)", recommendation: 'AUN 200' },
        { value: 'unsure', label: "I'm not sure", recommendation: null },
      ]
    },
    {
      id: 'bikeWeight',
      question: "Approximate weight of your motorcycle?",
      options: [
        { value: 'light', label: "Under 500 lbs (Sportster, Street)", ok: true },
        { value: 'medium', label: "500-800 lbs (Road King, Indian Scout)", ok: true },
        { value: 'heavy', label: "800-1200 lbs (Road Glide, Goldwing)", ok: true },
        { value: 'over', label: "Over 1200 lbs", ok: false },
      ]
    },
    {
      id: 'tailgate',
      question: "Do you need to close your tailgate with the ramp installed?",
      options: [
        { value: 'yes', label: "Yes, tailgate must close", recommendation: 'AUN 250' },
        { value: 'no', label: "No, open tailgate is fine", recommendation: 'either' },
      ]
    },
  ];

  const getRecommendation = () => {
    if (answers.bikeWeight === 'over') {
      return { 
        model: null, 
        message: "Your bike exceeds our 1,200 lb capacity. Contact us for custom solutions." 
      };
    }
    if (answers.bedLength === 'short' || answers.tailgate === 'yes') {
      return { 
        model: 'AUN 250', 
        message: "The AUN 250 Folding Ramp is perfect for your setup." 
      };
    }
    return { 
      model: 'AUN 200', 
      message: "The AUN 200 Standard Ramp is ideal for your truck." 
    };
  };

  const currentQ = questions[step - 1];
  const isComplete = step > questions.length;

  return (
    <section id="configurator" className="py-16 bg-gradient-to-b from-zinc-900 to-black">
      <div className="max-w-2xl mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Find Your Ramp</h2>
          <p className="text-zinc-400">Answer 3 quick questions</p>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8">
          {!isComplete ? (
            <>
              {/* Progress */}
              <div className="flex gap-2 mb-8">
                {questions.map((_, i) => (
                  <div 
                    key={i}
                    className={`flex-1 h-1 rounded-full ${
                      i + 1 <= step ? 'bg-amber-500' : 'bg-zinc-700'
                    }`}
                  />
                ))}
              </div>

              {/* Question */}
              <h3 className="text-xl text-white font-medium mb-6">{currentQ.question}</h3>
              
              {/* Options */}
              <div className="space-y-3">
                {currentQ.options.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => {
                      setAnswers({ ...answers, [currentQ.id]: opt.value });
                      setStep(step + 1);
                    }}
                    className="w-full p-4 text-left bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-amber-500/50 rounded-lg text-white transition-all"
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </>
          ) : (
            /* Result */
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-amber-500/20 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-2">
                {getRecommendation().model ? `We recommend the ${getRecommendation().model}` : 'Custom Solution Needed'}
              </h3>
              <p className="text-zinc-400 mb-6">{getRecommendation().message}</p>
              
              {getRecommendation().model ? (
                <a 
                  href={`/shop/${getRecommendation().model.toLowerCase().replace(/\s+/g, '-')}`}
                  className="inline-flex items-center px-8 py-4 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded transition-colors"
                >
                  View {getRecommendation().model}
                  <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </a>
              ) : (
                <a 
                  href="/contact"
                  className="inline-flex items-center px-8 py-4 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded transition-colors"
                >
                  Contact Us
                </a>
              )}
              
              <button 
                onClick={() => { setStep(1); setAnswers({}); }}
                className="block mx-auto mt-4 text-zinc-500 hover:text-white text-sm"
              >
                Start over
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

// ------------------------------------------
// 8. MOBILE STICKY CTA
// ------------------------------------------
export function MobileStickyCTA() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-black border-t border-zinc-800 p-4">
      <div className="flex gap-3">
        <a 
          href="/shop"
          className="flex-1 py-3 bg-amber-500 text-black font-bold text-center rounded"
        >
          Shop Ramps
        </a>
        <a 
          href="tel:+19377256790"
          className="px-4 py-3 border border-zinc-700 text-white rounded flex items-center justify-center"
          aria-label="Call us"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
          </svg>
        </a>
      </div>
    </div>
  );
}

// ------------------------------------------
// DEMO: Full page layout
// ------------------------------------------
export default function EZCycleRampDemo() {
  return (
    <div className="min-h-screen bg-black text-white">
      <TrustBadges />
      <HeroSection />
      <QuickConfigurator />
      <ComparisonTable />
      <TruckCompatibility />
      <Testimonials />
      <MobileStickyCTA />
    </div>
  );
}

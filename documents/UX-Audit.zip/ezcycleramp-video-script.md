# EZ Cycle Ramp — Product Demo Video Script

## Video Overview

| Attribute | Value |
|-----------|-------|
| Target Length | 90-120 seconds (hero video) |
| Tone | Confident, straightforward, rider-to-rider |
| Goal | Show the "aha moment" — one person, no struggle, bike loaded |
| CTA | "Find your ramp at ezcycleramp.com" |

---

## Script with Shot List

### HOOK (0:00 - 0:08)
**Goal:** Stop the scroll. Show the problem everyone knows.

| Timecode | Visual | Audio/VO |
|----------|--------|----------|
| 0:00-0:03 | Close-up: Rider's frustrated face, looking at bike + truck | *Natural sound: truck tailgate dropping* |
| 0:03-0:06 | Wide shot: Traditional ramp leaning against tailgate, sketchy angle | VO: "You know this moment." |
| 0:06-0:08 | Close-up: Hands gripping handlebars, hesitation | VO: "The deep breath before you ride a $30,000 bike up a plank." |

---

### THE PROBLEM (0:08 - 0:18)
**Goal:** Agitate the pain. Make them nod.

| Timecode | Visual | Audio/VO |
|----------|--------|----------|
| 0:08-0:12 | B-roll montage: wobbly traditional ramps, two-person struggles, near-drops | VO: "Two people. Sketchy balance. One wrong move and it's a $5,000 repair." |
| 0:12-0:15 | Shot: Rider wiping sweat, bike finally in truck but clearly stressed | VO: "There's gotta be a better way." |
| 0:15-0:18 | *Beat of silence* — Cut to black, then EZ Cycle Ramp logo reveal | *Sound: Confident mechanical click* |

---

### THE SOLUTION (0:18 - 0:45)
**Goal:** Show the product in action. This is your hero moment.

| Timecode | Visual | Audio/VO |
|----------|--------|----------|
| 0:18-0:22 | Wide shot: Truck parked, ramp already installed in bed | VO: "Meet the EZ Cycle Ramp." |
| 0:22-0:28 | Medium shot: Rider presses drill trigger, ramp smoothly extends out and tilts down | VO: "One button. It slides out like a drawer and tilts to the ground." |
| 0:28-0:32 | Shot: Rider casually walks bike to ramp base, positions front wheel | VO: "Walk your bike up to the wheel chock." |
| 0:32-0:38 | Wide shot: Rider presses button again, bike is lifted smoothly into truck bed | VO: "Press again. The ramp lifts your bike—up to 1,200 pounds—right into the bed." |
| 0:38-0:42 | Close-up: Rider's relaxed face, slight smile | VO: "No riding it in. No spotter. No sweat." |
| 0:42-0:45 | Shot: Rider strapping down bike, secure in chock | VO: "Lock it down and you're done." |

---

### KEY FEATURES (0:45 - 1:05)
**Goal:** Quick hits on specs that matter. Trust builders.

| Timecode | Visual | Audio/VO |
|----------|--------|----------|
| 0:45-0:50 | Close-up: Aluminum frame, aerospace-grade material callout graphic | VO: "Built from aerospace-grade aluminum. Same stuff as aircraft." |
| 0:50-0:55 | Shot: Ramp with fat rear tire (300mm), tire fitting perfectly | VO: "Fat tire friendly—up to 300mm rear." |
| 0:55-1:00 | Shot: Tailgate closing with AUN 250 installed | VO: "The folding model lets you close your tailgate. No ramp sticking out." |
| 1:00-1:05 | Split screen: Different trucks (F-150, Silverado, RAM) with ramps installed | VO: "Fits F-150s, Silverados, RAMs, Tundras—any full-size truck." |

---

### SOCIAL PROOF (1:05 - 1:15)
**Goal:** Real riders, real words.

| Timecode | Visual | Audio/VO |
|----------|--------|----------|
| 1:05-1:08 | Testimonial graphic: "Worth every penny." — Mike R., Dallas | VO: (Read quote) |
| 1:08-1:11 | Shot: Rider loading bagger solo, smooth operation | VO: "I'm 62. Loading my bagger was becoming a problem. Not anymore." |
| 1:11-1:15 | Testimonial graphic: "Game changer for road trips." — Jason T., Phoenix | *Natural sound: click of lock engaging* |

---

### CTA (1:15 - 1:25)
**Goal:** Clear next step.

| Timecode | Visual | Audio/VO |
|----------|--------|----------|
| 1:15-1:18 | Wide shot: Rider driving away, bike secure | VO: "Load solo. Ride anywhere." |
| 1:18-1:22 | End card: EZ Cycle Ramp logo, website URL, "Free Shipping" badge | VO: "Find your ramp at ezcycleramp.com." |
| 1:22-1:25 | Fade to black with URL persistent | *Sound: Engine fading out* |

---

## Alternative Cuts

### 30-Second Version (Social Ads)
- 0:00-0:05: Hook (frustrated rider)
- 0:05-0:20: Solution (ramp extends, bike lifts)
- 0:20-0:25: One feature (1,200 lb capacity)
- 0:25-0:30: CTA (website + "Free Shipping")

### 15-Second Version (Pre-Roll)
- 0:00-0:03: "Loading your bike shouldn't be terrifying."
- 0:03-0:10: Ramp extends, bike lifts (speed up slightly)
- 0:10-0:15: "EZ Cycle Ramp. Load solo." + URL

---

## B-Roll Shot List

Capture these for editing flexibility:

| Shot | Description | Notes |
|------|-------------|-------|
| Ramp extension | Full cycle from retracted to tilted | Multiple angles: side, rear, POV |
| Bike loading | Complete load sequence | Wide + close-up of wheel entering chock |
| Bike unloading | Reverse sequence | Show control, smoothness |
| Wheel chock detail | Front tire locking into chock | Close-up, satisfying click |
| Drill trigger | Finger pressing trigger, ramp responding | Hero moment |
| Strapping down | Tie-down T-bar in use | Quick, efficient |
| Tailgate close | AUN 250 with tailgate closing over it | Key differentiator |
| Material quality | Slow pan across aluminum, powder coating | Texture, precision |
| Different bikes | Harley bagger, BMW ADV, cruiser | Versatility proof |
| Different trucks | F-150, Silverado, RAM | Compatibility proof |
| Solo rider | One person doing entire load | The whole point |

---

## Voiceover Notes

**Tone:** 
- Not salesy. Rider talking to rider.
- Confident but not boastful.
- Slight dry humor okay ("No sweat" delivered deadpan).

**Avoid:**
- "Revolutionary" or "game-changing" (overused)
- Technical jargon without context
- Rushing through features

**Emphasize:**
- "One person" / "Solo" — this is the key differentiator
- "No riding it in" — addresses the fear
- Specific numbers (1,200 lbs, 300mm, 2-year warranty)

---

## Music Suggestions

| Style | Why | Example Reference |
|-------|-----|-------------------|
| Driving indie rock | Energy without cheese | Black Keys vibe |
| Confident electronic | Modern, premium feel | Minimal beats, not EDM |
| Americana/country rock | Speaks to truck owners | Subtle, not twangy |

**Key:** Music should support, not dominate. VO needs to cut through clearly.

---

## Production Notes

1. **Golden hour lighting** — Shoot early morning or late afternoon for best truck/bike shots
2. **Real rider** — Don't use a model. Use someone who actually rides.
3. **Real truck** — Dirty is fine. Authenticity > showroom.
4. **Sound design** — Mechanical sounds of ramp are satisfying. Capture clean audio.
5. **No drone shots** — Keep it grounded, practical, real.

---

## Thumbnail/Poster Frame

Best frame for YouTube thumbnail or hero image:
- **Shot:** Rider pressing drill trigger, ramp mid-extension, bike visible
- **Text overlay:** "Load Solo"
- **Why:** Shows the action, the ease, the product in use

---

## Distribution Checklist

| Platform | Format | Length | Notes |
|----------|--------|--------|-------|
| Website hero | 16:9 | 90-120s | Full version, autoplay muted |
| YouTube | 16:9 | 90-120s | Full version with chapters |
| Instagram Reels | 9:16 | 30s | Vertical crop, hook first |
| TikTok | 9:16 | 15-30s | Fast cuts, text overlays |
| Facebook | 16:9 + 1:1 | 30-60s | Captions mandatory |
| Paid ads (Meta) | 1:1 | 15s | Hook in first 3 seconds |
| Paid ads (YouTube) | 16:9 | 15s | Skippable pre-roll version |

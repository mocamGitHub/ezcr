// ============================================
// SUPABASE EDGE FUNCTIONS — EZ CYCLE RAMP LEAD AUTOMATION
// ============================================

// ---------------------------------------------
// supabase/functions/handle-new-lead/index.ts
// Triggered via database webhook when new lead is inserted
// ---------------------------------------------

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface ConfiguratorLead {
  id: string
  email: string
  recommendation: 'AUN200' | 'AUN250' | 'custom' | null
  answers: {
    bedLength: string
    bikeWeight: string
    tailgateRequired: string
  }
  created_at: string
}

interface WebhookPayload {
  type: 'INSERT'
  table: 'configurator_leads'
  record: ConfiguratorLead
  schema: 'public'
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const payload: WebhookPayload = await req.json()
    const lead = payload.record

    console.log(`Processing new lead: ${lead.email}, recommendation: ${lead.recommendation}`)

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Run all integrations in parallel
    const results = await Promise.allSettled([
      sendToEmailMarketing(lead),
      sendToN8N(lead),
      sendSlackNotification(lead),
    ])

    // Log results
    results.forEach((result, index) => {
      const integrations = ['Email Marketing', 'N8N', 'Slack']
      if (result.status === 'fulfilled') {
        console.log(`✓ ${integrations[index]}: Success`)
      } else {
        console.error(`✗ ${integrations[index]}: ${result.reason}`)
      }
    })

    // Update lead with processing status
    await supabase
      .from('configurator_leads')
      .update({ 
        processed_at: new Date().toISOString(),
        integrations_status: results.map((r, i) => ({
          name: ['email', 'n8n', 'slack'][i],
          success: r.status === 'fulfilled'
        }))
      })
      .eq('id', lead.id)

    return new Response(
      JSON.stringify({ success: true, lead_id: lead.id }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error processing lead:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

// ---------------------------------------------
// Email Marketing Integrations
// ---------------------------------------------

async function sendToEmailMarketing(lead: ConfiguratorLead) {
  const provider = Deno.env.get('EMAIL_PROVIDER') // 'mailchimp' | 'convertkit' | 'sendgrid' | 'klaviyo'
  
  switch (provider) {
    case 'mailchimp':
      return sendToMailchimp(lead)
    case 'convertkit':
      return sendToConvertKit(lead)
    case 'sendgrid':
      return sendToSendGrid(lead)
    case 'klaviyo':
      return sendToKlaviyo(lead)
    default:
      console.log('No email provider configured, skipping')
      return { skipped: true }
  }
}

// Mailchimp Integration
async function sendToMailchimp(lead: ConfiguratorLead) {
  const apiKey = Deno.env.get('MAILCHIMP_API_KEY')
  const listId = Deno.env.get('MAILCHIMP_LIST_ID')
  const dc = apiKey?.split('-')[1] // Data center from API key

  if (!apiKey || !listId) {
    throw new Error('Mailchimp credentials not configured')
  }

  const response = await fetch(
    `https://${dc}.api.mailchimp.com/3.0/lists/${listId}/members`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${btoa(`anystring:${apiKey}`)}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email_address: lead.email,
        status: 'subscribed',
        merge_fields: {
          RECOMMEND: lead.recommendation || 'none',
          BEDLEN: lead.answers?.bedLength || '',
          BIKEWGT: lead.answers?.bikeWeight || '',
          TAILGATE: lead.answers?.tailgateRequired || '',
        },
        tags: [
          'configurator-lead',
          lead.recommendation ? `recommendation-${lead.recommendation.toLowerCase()}` : 'no-recommendation',
        ],
      }),
    }
  )

  if (!response.ok) {
    const error = await response.json()
    if (error.title !== 'Member Exists') {
      throw new Error(`Mailchimp error: ${error.detail}`)
    }
  }

  return { provider: 'mailchimp', success: true }
}

// ConvertKit Integration
async function sendToConvertKit(lead: ConfiguratorLead) {
  const apiKey = Deno.env.get('CONVERTKIT_API_KEY')
  const formId = Deno.env.get('CONVERTKIT_FORM_ID')

  if (!apiKey || !formId) {
    throw new Error('ConvertKit credentials not configured')
  }

  const tagMap: Record<string, string> = {
    'AUN200': Deno.env.get('CONVERTKIT_TAG_AUN200') || '',
    'AUN250': Deno.env.get('CONVERTKIT_TAG_AUN250') || '',
    'custom': Deno.env.get('CONVERTKIT_TAG_CUSTOM') || '',
  }

  const response = await fetch(
    `https://api.convertkit.com/v3/forms/${formId}/subscribe`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: apiKey,
        email: lead.email,
        tags: lead.recommendation ? [tagMap[lead.recommendation]].filter(Boolean) : [],
        fields: {
          recommendation: lead.recommendation,
          bed_length: lead.answers?.bedLength,
          bike_weight: lead.answers?.bikeWeight,
          tailgate_required: lead.answers?.tailgateRequired,
        },
      }),
    }
  )

  if (!response.ok) {
    const error = await response.json()
    throw new Error(`ConvertKit error: ${JSON.stringify(error)}`)
  }

  return { provider: 'convertkit', success: true }
}

// SendGrid Integration
async function sendToSendGrid(lead: ConfiguratorLead) {
  const apiKey = Deno.env.get('SENDGRID_API_KEY')
  const listId = Deno.env.get('SENDGRID_LIST_ID')

  if (!apiKey) {
    throw new Error('SendGrid API key not configured')
  }

  if (listId) {
    await fetch('https://api.sendgrid.com/v3/marketing/contacts', {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        list_ids: [listId],
        contacts: [{
          email: lead.email,
          custom_fields: {
            recommendation: lead.recommendation,
            bed_length: lead.answers?.bedLength,
            bike_weight: lead.answers?.bikeWeight,
          },
        }],
      }),
    })
  }

  const templateId = getTemplateIdForRecommendation(lead.recommendation)
  
  if (templateId) {
    await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [{
          to: [{ email: lead.email }],
          dynamic_template_data: {
            recommendation: lead.recommendation,
            product_url: getProductUrl(lead.recommendation),
            price: getPrice(lead.recommendation),
          },
        }],
        from: { 
          email: Deno.env.get('SENDGRID_FROM_EMAIL') || 'hello@ezcycleramp.com',
          name: 'EZ Cycle Ramp'
        },
        template_id: templateId,
      }),
    })
  }

  return { provider: 'sendgrid', success: true }
}

// Klaviyo Integration
async function sendToKlaviyo(lead: ConfiguratorLead) {
  const apiKey = Deno.env.get('KLAVIYO_API_KEY')
  const listId = Deno.env.get('KLAVIYO_LIST_ID')

  if (!apiKey || !listId) {
    throw new Error('Klaviyo credentials not configured')
  }

  const profileResponse = await fetch('https://a.klaviyo.com/api/profiles/', {
    method: 'POST',
    headers: {
      'Authorization': `Klaviyo-API-Key ${apiKey}`,
      'Content-Type': 'application/json',
      'revision': '2024-02-15',
    },
    body: JSON.stringify({
      data: {
        type: 'profile',
        attributes: {
          email: lead.email,
          properties: {
            configurator_recommendation: lead.recommendation,
            configurator_bed_length: lead.answers?.bedLength,
            configurator_bike_weight: lead.answers?.bikeWeight,
            configurator_tailgate: lead.answers?.tailgateRequired,
            configurator_completed_at: lead.created_at,
          },
        },
      },
    }),
  })

  const profileData = await profileResponse.json()
  const profileId = profileData.data?.id

  if (profileId) {
    await fetch(`https://a.klaviyo.com/api/lists/${listId}/relationships/profiles/`, {
      method: 'POST',
      headers: {
        'Authorization': `Klaviyo-API-Key ${apiKey}`,
        'Content-Type': 'application/json',
        'revision': '2024-02-15',
      },
      body: JSON.stringify({
        data: [{ type: 'profile', id: profileId }],
      }),
    })
  }

  await fetch('https://a.klaviyo.com/api/events/', {
    method: 'POST',
    headers: {
      'Authorization': `Klaviyo-API-Key ${apiKey}`,
      'Content-Type': 'application/json',
      'revision': '2024-02-15',
    },
    body: JSON.stringify({
      data: {
        type: 'event',
        attributes: {
          profile: { $email: lead.email },
          metric: { name: 'Configurator Completed' },
          properties: {
            recommendation: lead.recommendation,
            recommended_price: getPrice(lead.recommendation),
            product_url: getProductUrl(lead.recommendation),
            ...lead.answers,
          },
        },
      },
    }),
  })

  return { provider: 'klaviyo', success: true }
}

// ---------------------------------------------
// N8N Webhook Integration
// ---------------------------------------------

async function sendToN8N(lead: ConfiguratorLead) {
  const webhookUrl = Deno.env.get('N8N_WEBHOOK_URL')
  
  if (!webhookUrl) {
    console.log('N8N webhook URL not configured, skipping')
    return { skipped: true }
  }

  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      event: 'configurator_lead',
      timestamp: new Date().toISOString(),
      lead: {
        id: lead.id,
        email: lead.email,
        recommendation: lead.recommendation,
        answers: lead.answers,
        created_at: lead.created_at,
      },
      metadata: {
        product_url: getProductUrl(lead.recommendation),
        price: getPrice(lead.recommendation),
        product_name: getProductName(lead.recommendation),
      },
    }),
  })

  if (!response.ok) {
    throw new Error(`N8N webhook failed: ${response.status}`)
  }

  return { provider: 'n8n', success: true }
}

// ---------------------------------------------
// Slack Notification
// ---------------------------------------------

async function sendSlackNotification(lead: ConfiguratorLead) {
  const webhookUrl = Deno.env.get('SLACK_WEBHOOK_URL')
  
  if (!webhookUrl) {
    return { skipped: true }
  }

  const recommendationEmoji = {
    'AUN200': '🟢',
    'AUN250': '🟡',
    'custom': '🔴',
  }

  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      blocks: [
        {
          type: 'header',
          text: { type: 'plain_text', text: '🏍️ New Configurator Lead', emoji: true },
        },
        {
          type: 'section',
          fields: [
            { type: 'mrkdwn', text: `*Email:*\n${lead.email}` },
            { type: 'mrkdwn', text: `*Recommendation:*\n${recommendationEmoji[lead.recommendation || 'custom'] || '⚪'} ${lead.recommendation || 'Custom'}` },
          ],
        },
        {
          type: 'section',
          fields: [
            { type: 'mrkdwn', text: `*Bed Length:*\n${lead.answers?.bedLength || 'N/A'}` },
            { type: 'mrkdwn', text: `*Bike Weight:*\n${lead.answers?.bikeWeight || 'N/A'}` },
          ],
        },
        {
          type: 'section',
          fields: [
            { type: 'mrkdwn', text: `*Tailgate Required:*\n${lead.answers?.tailgateRequired || 'N/A'}` },
            { type: 'mrkdwn', text: `*Potential Value:*\n$${getPrice(lead.recommendation)?.toLocaleString() || 'Custom quote'}` },
          ],
        },
      ],
    }),
  })

  if (!response.ok) {
    throw new Error(`Slack notification failed: ${response.status}`)
  }

  return { provider: 'slack', success: true }
}

// ---------------------------------------------
// Helper Functions
// ---------------------------------------------

function getProductUrl(recommendation: string | null): string {
  switch (recommendation) {
    case 'AUN200': return 'https://ezcycleramp.com/shop/aun-200'
    case 'AUN250': return 'https://ezcycleramp.com/shop/aun-250'
    default: return 'https://ezcycleramp.com/contact'
  }
}

function getPrice(recommendation: string | null): number | null {
  switch (recommendation) {
    case 'AUN200': return 2495
    case 'AUN250': return 2795
    default: return null
  }
}

function getProductName(recommendation: string | null): string {
  switch (recommendation) {
    case 'AUN200': return 'AUN 200 Standard Ramp'
    case 'AUN250': return 'AUN 250 Folding Ramp'
    default: return 'Custom Solution'
  }
}

function getTemplateIdForRecommendation(recommendation: string | null): string | null {
  switch (recommendation) {
    case 'AUN200': return Deno.env.get('SENDGRID_TEMPLATE_AUN200') || null
    case 'AUN250': return Deno.env.get('SENDGRID_TEMPLATE_AUN250') || null
    case 'custom': return Deno.env.get('SENDGRID_TEMPLATE_CUSTOM') || null
    default: return null
  }
}

// ============================================
// EZ CYCLE RAMP — NEXT.JS CONFIGURATOR
// Production-ready with TypeScript, analytics, and Supabase integration
// ============================================

// ---------------------------------------------
// types/configurator.ts
// ---------------------------------------------
export interface ConfiguratorAnswer {
  bedLength: 'short' | 'standard' | 'long' | 'unsure' | null;
  bikeWeight: 'light' | 'medium' | 'heavy' | 'over' | null;
  tailgateRequired: 'yes' | 'no' | null;
  truckMake?: string;
  email?: string;
}

export interface ConfiguratorResult {
  recommendation: 'AUN200' | 'AUN250' | 'custom' | null;
  confidence: 'high' | 'medium' | 'low';
  message: string;
  price: number | null;
  productUrl: string | null;
  alternateOption?: {
    model: string;
    reason: string;
  };
}

export interface Question {
  id: keyof ConfiguratorAnswer;
  question: string;
  helpText?: string;
  options: {
    value: string;
    label: string;
    sublabel?: string;
    icon?: string;
  }[];
}

// ---------------------------------------------
// lib/configurator-logic.ts
// ---------------------------------------------
import { ConfiguratorAnswer, ConfiguratorResult } from '@/types/configurator';

export function calculateRecommendation(answers: ConfiguratorAnswer): ConfiguratorResult {
  // Handle edge cases first
  if (answers.bikeWeight === 'over') {
    return {
      recommendation: 'custom',
      confidence: 'high',
      message: 'Your bike exceeds our 1,200 lb capacity. Contact us for custom solutions or trailer options.',
      price: null,
      productUrl: '/contact',
    };
  }

  // Unsure about bed length? Default to AUN 250 (more versatile)
  if (answers.bedLength === 'unsure') {
    return {
      recommendation: 'AUN250',
      confidence: 'medium',
      message: "Not sure about your bed length? The AUN 250 works with most trucks and lets you close your tailgate.",
      price: 2795,
      productUrl: '/shop/aun-250',
      alternateOption: {
        model: 'AUN 200',
        reason: 'Better for beds 6.5\' or longer',
      },
    };
  }

  // Short bed OR tailgate required = AUN 250
  if (answers.bedLength === 'short' || answers.tailgateRequired === 'yes') {
    return {
      recommendation: 'AUN250',
      confidence: 'high',
      message: 'The AUN 250 Folding Ramp is perfect for your setup.',
      price: 2795,
      productUrl: '/shop/aun-250',
    };
  }

  // Standard or long bed, no tailgate requirement = AUN 200
  return {
    recommendation: 'AUN200',
    confidence: 'high',
    message: 'The AUN 200 Standard Ramp is ideal for your truck.',
    price: 2495,
    productUrl: '/shop/aun-200',
    alternateOption: {
      model: 'AUN 250',
      reason: 'If you want tailgate compatibility',
    },
  };
}

// ---------------------------------------------
// lib/configurator-analytics.ts
// ---------------------------------------------
type AnalyticsEvent = {
  event: string;
  properties?: Record<string, unknown>;
};

export function trackConfiguratorEvent({ event, properties }: AnalyticsEvent) {
  // Google Analytics 4
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', event, properties);
  }

  // Posthog (if using)
  if (typeof window !== 'undefined' && window.posthog) {
    window.posthog.capture(event, properties);
  }

  // Console log for development
  if (process.env.NODE_ENV === 'development') {
    console.log('[Analytics]', event, properties);
  }
}

export const ConfiguratorEvents = {
  STARTED: 'configurator_started',
  STEP_COMPLETED: 'configurator_step_completed',
  COMPLETED: 'configurator_completed',
  RESULT_CLICKED: 'configurator_result_clicked',
  ABANDONED: 'configurator_abandoned',
  EMAIL_CAPTURED: 'configurator_email_captured',
};

// ---------------------------------------------
// components/configurator/Configurator.tsx
// ---------------------------------------------
'use client';

import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ConfiguratorAnswer, ConfiguratorResult, Question } from '@/types/configurator';
import { calculateRecommendation } from '@/lib/configurator-logic';
import { trackConfiguratorEvent, ConfiguratorEvents } from '@/lib/configurator-analytics';

// Question configuration
const QUESTIONS: Question[] = [
  {
    id: 'bedLength',
    question: "What's your truck bed length?",
    helpText: "Check your truck's specs or measure from bulkhead to tailgate",
    options: [
      { value: 'short', label: 'Short bed', sublabel: "5' - 5.8'", icon: '📏' },
      { value: 'standard', label: 'Standard bed', sublabel: "6' - 6.5'", icon: '📐' },
      { value: 'long', label: 'Long bed', sublabel: "8'+", icon: '📏' },
      { value: 'unsure', label: "I'm not sure", sublabel: 'Help me decide', icon: '❓' },
    ],
  },
  {
    id: 'bikeWeight',
    question: 'Approximate weight of your motorcycle?',
    helpText: 'Include gear, bags, and accessories',
    options: [
      { value: 'light', label: 'Under 500 lbs', sublabel: 'Sportster, Street, Dirt bikes', icon: '🏍️' },
      { value: 'medium', label: '500-800 lbs', sublabel: 'Road King, Indian Scout', icon: '🏍️' },
      { value: 'heavy', label: '800-1,200 lbs', sublabel: 'Road Glide, Goldwing', icon: '🏍️' },
      { value: 'over', label: 'Over 1,200 lbs', sublabel: 'Trikes, heavily modified', icon: '⚠️' },
    ],
  },
  {
    id: 'tailgateRequired',
    question: 'Do you need to close your tailgate with the ramp installed?',
    helpText: 'Important for highway driving and security',
    options: [
      { value: 'yes', label: 'Yes, tailgate must close', sublabel: 'For highway trips, parking security', icon: '✅' },
      { value: 'no', label: 'No, open tailgate is fine', sublabel: 'Short trips, trailer use', icon: '➖' },
    ],
  },
];

interface ConfiguratorProps {
  onComplete?: (result: ConfiguratorResult, answers: ConfiguratorAnswer) => void;
  className?: string;
}

export function Configurator({ onComplete, className = '' }: ConfiguratorProps) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<ConfiguratorAnswer>({
    bedLength: null,
    bikeWeight: null,
    tailgateRequired: null,
  });
  const [result, setResult] = useState<ConfiguratorResult | null>(null);
  const [hasStarted, setHasStarted] = useState(false);

  const currentQuestion = QUESTIONS[step];
  const isComplete = step >= QUESTIONS.length;
  const progress = ((step) / QUESTIONS.length) * 100;

  // Track start
  useEffect(() => {
    if (!hasStarted && step === 0) {
      trackConfiguratorEvent({ event: ConfiguratorEvents.STARTED });
      setHasStarted(true);
    }
  }, [hasStarted, step]);

  // Calculate result when complete
  useEffect(() => {
    if (isComplete && !result) {
      const calculatedResult = calculateRecommendation(answers);
      setResult(calculatedResult);
      
      trackConfiguratorEvent({
        event: ConfiguratorEvents.COMPLETED,
        properties: {
          recommendation: calculatedResult.recommendation,
          confidence: calculatedResult.confidence,
          answers,
        },
      });

      onComplete?.(calculatedResult, answers);
    }
  }, [isComplete, result, answers, onComplete]);

  const handleAnswer = useCallback((questionId: keyof ConfiguratorAnswer, value: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
    
    trackConfiguratorEvent({
      event: ConfiguratorEvents.STEP_COMPLETED,
      properties: {
        step: step + 1,
        questionId,
        answer: value,
      },
    });

    setStep(prev => prev + 1);
  }, [step]);

  const handleBack = useCallback(() => {
    if (step > 0) {
      setStep(prev => prev - 1);
      setResult(null);
    }
  }, [step]);

  const handleReset = useCallback(() => {
    setStep(0);
    setAnswers({
      bedLength: null,
      bikeWeight: null,
      tailgateRequired: null,
    });
    setResult(null);
  }, []);

  const handleResultClick = useCallback(() => {
    if (result) {
      trackConfiguratorEvent({
        event: ConfiguratorEvents.RESULT_CLICKED,
        properties: {
          recommendation: result.recommendation,
          productUrl: result.productUrl,
        },
      });
    }
  }, [result]);

  return (
    <section id="configurator" className={`py-16 bg-gradient-to-b from-zinc-900 to-black ${className}`}>
      <div className="max-w-2xl mx-auto px-4">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Find Your Ramp</h2>
          <p className="text-zinc-400">Answer {QUESTIONS.length} quick questions</p>
        </div>

        {/* Card */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-8 shadow-2xl">
          
          {/* Progress bar */}
          <div className="mb-8">
            <div className="flex justify-between text-xs text-zinc-500 mb-2">
              <span>Step {Math.min(step + 1, QUESTIONS.length)} of {QUESTIONS.length}</span>
              <span>{Math.round(progress)}% complete</span>
            </div>
            <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-amber-500"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>

          <AnimatePresence mode="wait">
            {!isComplete ? (
              /* Question View */
              <motion.div
                key={`question-${step}`}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                {/* Back button */}
                {step > 0 && (
                  <button
                    onClick={handleBack}
                    className="flex items-center gap-2 text-zinc-400 hover:text-white mb-4 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                    Back
                  </button>
                )}

                {/* Question */}
                <h3 className="text-xl text-white font-medium mb-2">
                  {currentQuestion.question}
                </h3>
                {currentQuestion.helpText && (
                  <p className="text-zinc-500 text-sm mb-6">{currentQuestion.helpText}</p>
                )}

                {/* Options */}
                <div className="space-y-3">
                  {currentQuestion.options.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handleAnswer(currentQuestion.id, option.value)}
                      className="w-full p-4 text-left bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-amber-500/50 rounded-lg transition-all group"
                    >
                      <div className="flex items-center gap-4">
                        {option.icon && (
                          <span className="text-2xl">{option.icon}</span>
                        )}
                        <div className="flex-1">
                          <span className="text-white font-medium block">{option.label}</span>
                          {option.sublabel && (
                            <span className="text-zinc-500 text-sm">{option.sublabel}</span>
                          )}
                        </div>
                        <svg 
                          className="w-5 h-5 text-zinc-600 group-hover:text-amber-500 transition-colors" 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            ) : (
              /* Result View */
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className="text-center"
              >
                {/* Success icon */}
                <div className="w-20 h-20 mx-auto mb-6 bg-amber-500/20 rounded-full flex items-center justify-center">
                  {result?.recommendation === 'custom' ? (
                    <svg className="w-10 h-10 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                  ) : (
                    <svg className="w-10 h-10 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>

                {/* Recommendation */}
                <h3 className="text-2xl font-bold text-white mb-2">
                  {result?.recommendation === 'custom' 
                    ? 'Custom Solution Needed'
                    : `We recommend the ${result?.recommendation === 'AUN200' ? 'AUN 200' : 'AUN 250'}`
                  }
                </h3>
                <p className="text-zinc-400 mb-6">{result?.message}</p>

                {/* Price (if applicable) */}
                {result?.price && (
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-white">${result.price.toLocaleString()}</span>
                    <span className="text-zinc-500 ml-2">+ free shipping</span>
                  </div>
                )}

                {/* Confidence indicator */}
                {result?.confidence === 'medium' && (
                  <p className="text-amber-500/70 text-sm mb-6">
                    💡 Tip: Measure your truck bed to confirm the best fit
                  </p>
                )}

                {/* Primary CTA */}
                <a
                  href={result?.productUrl || '/shop'}
                  onClick={handleResultClick}
                  className="inline-flex items-center px-8 py-4 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg transition-colors"
                >
                  {result?.recommendation === 'custom' ? 'Contact Us' : `View ${result?.recommendation === 'AUN200' ? 'AUN 200' : 'AUN 250'}`}
                  <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </a>

                {/* Alternate option */}
                {result?.alternateOption && (
                  <p className="mt-4 text-zinc-500 text-sm">
                    Or consider the{' '}
                    <a href={`/shop/${result.alternateOption.model.toLowerCase().replace(' ', '-')}`} className="text-amber-500 hover:underline">
                      {result.alternateOption.model}
                    </a>
                    {' '}— {result.alternateOption.reason}
                  </p>
                )}

                {/* Reset */}
                <button
                  onClick={handleReset}
                  className="block mx-auto mt-6 text-zinc-500 hover:text-white text-sm transition-colors"
                >
                  Start over
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Trust indicators */}
        <p className="text-center mt-6 text-zinc-600 text-sm">
          🔒 No email required • Takes 30 seconds
        </p>
      </div>
    </section>
  );
}

export default Configurator;

// ---------------------------------------------
// components/configurator/ConfiguratorWithEmail.tsx
// (Variant that captures email before showing result)
// ---------------------------------------------
'use client';

import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Configurator } from './Configurator';
import { ConfiguratorResult, ConfiguratorAnswer } from '@/types/configurator';
import { trackConfiguratorEvent, ConfiguratorEvents } from '@/lib/configurator-analytics';

// Initialize Supabase client (use your env vars)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

interface ConfiguratorWithEmailProps {
  className?: string;
}

export function ConfiguratorWithEmail({ className }: ConfiguratorWithEmailProps) {
  const [showEmailCapture, setShowEmailCapture] = useState(false);
  const [pendingResult, setPendingResult] = useState<{
    result: ConfiguratorResult;
    answers: ConfiguratorAnswer;
  } | null>(null);
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleConfiguratorComplete = (result: ConfiguratorResult, answers: ConfiguratorAnswer) => {
    // Store result and show email capture
    setPendingResult({ result, answers });
    setShowEmailCapture(true);
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      // Save to Supabase
      const { error: dbError } = await supabase.from('configurator_leads').insert({
        email,
        recommendation: pendingResult?.result.recommendation,
        answers: pendingResult?.answers,
        created_at: new Date().toISOString(),
      });

      if (dbError) throw dbError;

      trackConfiguratorEvent({
        event: ConfiguratorEvents.EMAIL_CAPTURED,
        properties: {
          recommendation: pendingResult?.result.recommendation,
        },
      });

      // Redirect to product page
      if (pendingResult?.result.productUrl) {
        window.location.href = pendingResult.result.productUrl;
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
      console.error('Email capture error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSkip = () => {
    if (pendingResult?.result.productUrl) {
      window.location.href = pendingResult.result.productUrl;
    }
  };

  if (showEmailCapture && pendingResult) {
    return (
      <section className={`py-16 bg-gradient-to-b from-zinc-900 to-black ${className}`}>
        <div className="max-w-md mx-auto px-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-8 text-center">
            
            <div className="w-16 h-16 mx-auto mb-6 bg-amber-500/20 rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>

            <h3 className="text-xl font-bold text-white mb-2">
              Great news! The {pendingResult.result.recommendation === 'AUN200' ? 'AUN 200' : 'AUN 250'} fits your setup.
            </h3>
            
            <p className="text-zinc-400 mb-6">
              Enter your email to see your personalized recommendation and get exclusive offers.
            </p>

            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
              />
              
              {error && (
                <p className="text-red-500 text-sm">{error}</p>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-bold rounded-lg transition-colors"
              >
                {isSubmitting ? 'Saving...' : 'See My Recommendation'}
              </button>
            </form>

            <button
              onClick={handleSkip}
              className="mt-4 text-zinc-500 hover:text-white text-sm transition-colors"
            >
              Skip for now
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <Configurator 
      onComplete={handleConfiguratorComplete}
      className={className}
    />
  );
}

// ---------------------------------------------
// app/api/configurator/route.ts
// (API route for server-side lead capture)
// ---------------------------------------------
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, recommendation, answers } = body;

    // Validate email
    if (!email || !email.includes('@')) {
      return NextResponse.json(
        { error: 'Valid email required' },
        { status: 400 }
      );
    }

    // Save to Supabase
    const { error } = await supabase.from('configurator_leads').insert({
      email,
      recommendation,
      answers,
      ip_address: request.headers.get('x-forwarded-for') || 'unknown',
      user_agent: request.headers.get('user-agent'),
      created_at: new Date().toISOString(),
    });

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json(
        { error: 'Failed to save' },
        { status: 500 }
      );
    }

    // Optional: Send to email marketing (Mailchimp, ConvertKit, etc.)
    // await sendToMailchimp(email, recommendation);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ---------------------------------------------
// Supabase migration for leads table
// Run: npx supabase migration new configurator_leads
// ---------------------------------------------
/*
-- migrations/XXXXXX_configurator_leads.sql

CREATE TABLE configurator_leads (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL,
  recommendation TEXT,
  answers JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  converted_at TIMESTAMPTZ,
  order_id TEXT
);

-- Index for email lookups
CREATE INDEX idx_configurator_leads_email ON configurator_leads(email);

-- Index for analytics queries
CREATE INDEX idx_configurator_leads_recommendation ON configurator_leads(recommendation);
CREATE INDEX idx_configurator_leads_created_at ON configurator_leads(created_at DESC);

-- RLS policies
ALTER TABLE configurator_leads ENABLE ROW LEVEL SECURITY;

-- Only service role can read/write (no public access)
CREATE POLICY "Service role only" ON configurator_leads
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);
*/

// ---------------------------------------------
// Usage in page.tsx
// ---------------------------------------------
/*
import { Configurator } from '@/components/configurator/Configurator';
// OR with email capture:
import { ConfiguratorWithEmail } from '@/components/configurator/ConfiguratorWithEmail';

export default function HomePage() {
  return (
    <main>
      {/* ... other sections ... *\/}
      
      <Configurator />
      
      {/* OR *\/}
      <ConfiguratorWithEmail />
      
      {/* ... other sections ... *\/}
    </main>
  );
}
*/

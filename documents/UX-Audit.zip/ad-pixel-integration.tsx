// ============================================
// AD PIXEL & CONVERSION TRACKING INTEGRATION
// GA4, Meta Pixel, Google Ads for Next.js
// ============================================

// ---------------------------------------------
// 1. PIXEL INITIALIZATION SCRIPT
// Add to app/layout.tsx or _app.tsx
// ---------------------------------------------

// components/tracking/PixelProvider.tsx
'use client';

import Script from 'next/script';
import { usePathname, useSearchParams } from 'next/navigation';
import { useEffect, Suspense } from 'react';

// Configuration
const GA4_MEASUREMENT_ID = process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID;
const META_PIXEL_ID = process.env.NEXT_PUBLIC_META_PIXEL_ID;
const GOOGLE_ADS_ID = process.env.NEXT_PUBLIC_GOOGLE_ADS_ID;
const GOOGLE_ADS_CONVERSION_LABEL = process.env.NEXT_PUBLIC_GOOGLE_ADS_CONVERSION_LABEL;

// Extend window type
declare global {
  interface Window {
    gtag: (...args: any[]) => void;
    fbq: (...args: any[]) => void;
    dataLayer: any[];
    _fbq: any;
  }
}

function PageViewTracker() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  useEffect(() => {
    const url = pathname + (searchParams?.toString() ? `?${searchParams.toString()}` : '');
    
    // GA4 page view
    if (typeof window.gtag !== 'undefined' && GA4_MEASUREMENT_ID) {
      window.gtag('config', GA4_MEASUREMENT_ID, {
        page_path: url,
      });
    }

    // Meta page view
    if (typeof window.fbq !== 'undefined') {
      window.fbq('track', 'PageView');
    }
  }, [pathname, searchParams]);

  return null;
}

export function PixelProvider({ children }: { children: React.ReactNode }) {
  return (
    <>
      {/* Google Analytics 4 */}
      {GA4_MEASUREMENT_ID && (
        <>
          <Script
            src={`https://www.googletagmanager.com/gtag/js?id=${GA4_MEASUREMENT_ID}`}
            strategy="afterInteractive"
          />
          <Script id="ga4-init" strategy="afterInteractive">
            {`
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', '${GA4_MEASUREMENT_ID}', {
                page_path: window.location.pathname,
              });
              ${GOOGLE_ADS_ID ? `gtag('config', '${GOOGLE_ADS_ID}');` : ''}
            `}
          </Script>
        </>
      )}

      {/* Meta Pixel */}
      {META_PIXEL_ID && (
        <Script id="meta-pixel" strategy="afterInteractive">
          {`
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '${META_PIXEL_ID}');
            fbq('track', 'PageView');
          `}
        </Script>
      )}

      {/* Meta Pixel noscript fallback */}
      {META_PIXEL_ID && (
        <noscript>
          <img
            height="1"
            width="1"
            style={{ display: 'none' }}
            src={`https://www.facebook.com/tr?id=${META_PIXEL_ID}&ev=PageView&noscript=1`}
            alt=""
          />
        </noscript>
      )}

      {/* Page view tracking */}
      <Suspense fallback={null}>
        <PageViewTracker />
      </Suspense>

      {children}
    </>
  );
}

// ---------------------------------------------
// 2. TRACKING UTILITY FUNCTIONS
// lib/tracking.ts
// ---------------------------------------------

export const tracking = {
  // Track configurator events
  configuratorStarted: () => {
    // GA4
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'configurator_started', {
        event_category: 'engagement',
      });
    }
    // Meta
    if (typeof window.fbq !== 'undefined') {
      window.fbq('trackCustom', 'ConfiguratorStarted');
    }
  },

  configuratorStepCompleted: (step: number, questionId: string, answer: string) => {
    // GA4
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'configurator_step', {
        event_category: 'engagement',
        step_number: step,
        question_id: questionId,
        answer: answer,
      });
    }
  },

  configuratorCompleted: (recommendation: string) => {
    // GA4
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'configurator_completed', {
        event_category: 'engagement',
        recommendation: recommendation,
      });
      // Also track as lead
      window.gtag('event', 'generate_lead', {
        event_category: 'conversion',
        value: recommendation === 'AUN250' ? 2795 : 2495,
        currency: 'USD',
      });
    }
    // Meta - Lead event
    if (typeof window.fbq !== 'undefined') {
      window.fbq('track', 'Lead', {
        content_name: recommendation,
        value: recommendation === 'AUN250' ? 2795 : 2495,
        currency: 'USD',
      });
    }
    // Google Ads conversion (lead)
    if (typeof window.gtag !== 'undefined' && GOOGLE_ADS_ID) {
      window.gtag('event', 'conversion', {
        send_to: `${GOOGLE_ADS_ID}/lead`,
        value: recommendation === 'AUN250' ? 2795 : 2495,
        currency: 'USD',
      });
    }
  },

  // Track product views
  productViewed: (product: { id: string; name: string; price: number }) => {
    // GA4
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'view_item', {
        currency: 'USD',
        value: product.price,
        items: [{
          item_id: product.id,
          item_name: product.name,
          price: product.price,
          quantity: 1,
        }],
      });
    }
    // Meta
    if (typeof window.fbq !== 'undefined') {
      window.fbq('track', 'ViewContent', {
        content_ids: [product.id],
        content_name: product.name,
        content_type: 'product',
        value: product.price,
        currency: 'USD',
      });
    }
  },

  // Track add to cart
  addToCart: (product: { id: string; name: string; price: number }) => {
    // GA4
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'add_to_cart', {
        currency: 'USD',
        value: product.price,
        items: [{
          item_id: product.id,
          item_name: product.name,
          price: product.price,
          quantity: 1,
        }],
      });
    }
    // Meta
    if (typeof window.fbq !== 'undefined') {
      window.fbq('track', 'AddToCart', {
        content_ids: [product.id],
        content_name: product.name,
        content_type: 'product',
        value: product.price,
        currency: 'USD',
      });
    }
  },

  // Track checkout initiated
  checkoutStarted: (product: { id: string; name: string; price: number }) => {
    // GA4
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'begin_checkout', {
        currency: 'USD',
        value: product.price,
        items: [{
          item_id: product.id,
          item_name: product.name,
          price: product.price,
          quantity: 1,
        }],
      });
    }
    // Meta
    if (typeof window.fbq !== 'undefined') {
      window.fbq('track', 'InitiateCheckout', {
        content_ids: [product.id],
        content_name: product.name,
        content_type: 'product',
        value: product.price,
        currency: 'USD',
        num_items: 1,
      });
    }
  },

  // Track purchase (call this after successful payment)
  purchase: (order: { 
    orderId: string; 
    productId: string; 
    productName: string; 
    price: number;
    email?: string;
  }) => {
    // GA4
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', 'purchase', {
        transaction_id: order.orderId,
        value: order.price,
        currency: 'USD',
        items: [{
          item_id: order.productId,
          item_name: order.productName,
          price: order.price,
          quantity: 1,
        }],
      });
    }
    // Google Ads conversion
    if (typeof window.gtag !== 'undefined' && GOOGLE_ADS_ID && GOOGLE_ADS_CONVERSION_LABEL) {
      window.gtag('event', 'conversion', {
        send_to: `${GOOGLE_ADS_ID}/${GOOGLE_ADS_CONVERSION_LABEL}`,
        value: order.price,
        currency: 'USD',
        transaction_id: order.orderId,
      });
    }
    // Meta
    if (typeof window.fbq !== 'undefined') {
      window.fbq('track', 'Purchase', {
        content_ids: [order.productId],
        content_name: order.productName,
        content_type: 'product',
        value: order.price,
        currency: 'USD',
        num_items: 1,
      });
    }
  },
};

// ---------------------------------------------
// 3. USAGE EXAMPLES
// ---------------------------------------------

/*
// In your configurator component:
import { tracking } from '@/lib/tracking';

// When configurator starts
useEffect(() => {
  tracking.configuratorStarted();
}, []);

// When step is completed
const handleAnswer = (questionId, answer) => {
  tracking.configuratorStepCompleted(currentStep, questionId, answer);
  // ... rest of logic
};

// When configurator is completed
const handleComplete = (result) => {
  tracking.configuratorCompleted(result.recommendation);
  // ... rest of logic
};

// On product page:
useEffect(() => {
  tracking.productViewed({
    id: 'AUN250',
    name: 'AUN 250 Folding Ramp',
    price: 2795,
  });
}, []);

// On checkout button click:
const handleCheckout = () => {
  tracking.checkoutStarted({
    id: 'AUN250',
    name: 'AUN 250 Folding Ramp',
    price: 2795,
  });
  // redirect to checkout...
};

// On successful purchase (thank you page):
useEffect(() => {
  const orderData = getOrderFromURL(); // or however you get order data
  tracking.purchase({
    orderId: orderData.id,
    productId: orderData.productSku,
    productName: orderData.productName,
    price: orderData.amount,
  });
}, []);
*/

// ---------------------------------------------
// 4. ENHANCED ECOMMERCE DATA LAYER
// For GTM users who want more control
// ---------------------------------------------

export const dataLayer = {
  push: (data: Record<string, any>) => {
    if (typeof window !== 'undefined') {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push(data);
    }
  },

  // Enhanced ecommerce - view item list
  viewItemList: (items: Array<{ id: string; name: string; price: number; position: number }>) => {
    dataLayer.push({
      event: 'view_item_list',
      ecommerce: {
        item_list_name: 'Product Catalog',
        items: items.map(item => ({
          item_id: item.id,
          item_name: item.name,
          price: item.price,
          index: item.position,
        })),
      },
    });
  },

  // Enhanced ecommerce - select item
  selectItem: (item: { id: string; name: string; price: number }) => {
    dataLayer.push({
      event: 'select_item',
      ecommerce: {
        items: [{
          item_id: item.id,
          item_name: item.name,
          price: item.price,
        }],
      },
    });
  },
};

// ---------------------------------------------
// 5. ENVIRONMENT VARIABLES TEMPLATE
// Add to .env.local
// ---------------------------------------------

/*
# Google Analytics 4
NEXT_PUBLIC_GA4_MEASUREMENT_ID=G-XXXXXXXXXX

# Meta/Facebook Pixel
NEXT_PUBLIC_META_PIXEL_ID=XXXXXXXXXXXXXXX

# Google Ads
NEXT_PUBLIC_GOOGLE_ADS_ID=AW-XXXXXXXXXX
NEXT_PUBLIC_GOOGLE_ADS_CONVERSION_LABEL=XXXXXXXXXXXXXXXXXX

# Server-side (for Conversions API)
META_ACCESS_TOKEN=EAAG...
GA4_API_SECRET=XXXXXXXXXXXX
*/

// ---------------------------------------------
// 6. LAYOUT INTEGRATION
// app/layout.tsx
// ---------------------------------------------

/*
import { PixelProvider } from '@/components/tracking/PixelProvider';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <PixelProvider>
          {children}
        </PixelProvider>
      </body>
    </html>
  );
}
*/

// ---------------------------------------------
// 7. GOOGLE ADS REMARKETING AUDIENCES
// Configure in Google Ads UI, but here are recommended audiences:
// ---------------------------------------------

/*
RECOMMENDED REMARKETING AUDIENCES:

1. "Configurator Started - Not Completed"
   - Include: configurator_started event
   - Exclude: configurator_completed event
   - Duration: 7 days
   - Use for: Re-engagement ads

2. "Configurator Completed - Not Purchased"
   - Include: configurator_completed event
   - Exclude: purchase event
   - Duration: 30 days
   - Use for: Conversion ads with product they recommended

3. "Product Page Viewers - Not Purchased"
   - Include: view_item event
   - Exclude: purchase event
   - Duration: 14 days
   - Use for: Product-specific retargeting

4. "Cart Abandoners"
   - Include: add_to_cart event
   - Exclude: purchase event
   - Duration: 7 days
   - Use for: High-intent recovery

5. "Past Purchasers"
   - Include: purchase event
   - Duration: 540 days
   - Use for: Accessory upsells, referral campaigns
   - Exclude from prospecting campaigns

6. "High-Value Leads"
   - Include: configurator_completed where recommendation = AUN250
   - Exclude: purchase event
   - Duration: 30 days
   - Use for: Premium product ads
*/

export default tracking;

// ============================================
// EZ CYCLE RAMP — ANALYTICS DASHBOARD COMPONENT
// React + Recharts + Tailwind
// ============================================

'use client';

import React, { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';

// Initialize Supabase
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// Types
interface DashboardMetrics {
  summary: {
    leads_this_week: number;
    orders_this_week: number;
    revenue_this_week: number;
    leads_this_month: number;
    orders_this_month: number;
    revenue_this_month: number;
    conversion_rate_30d: number;
    active_sequences: number;
    pending_reviews: number;
  };
  daily_leads: Array<{
    date: string;
    total_leads: number;
    conversions: number;
    conversion_rate: number;
  }>;
  conversion_by_recommendation: Array<{
    recommendation: string;
    total_leads: number;
    conversions: number;
    conversion_rate: number;
  }>;
  email_performance: Array<{
    template: string;
    sent: number;
    opened: number;
    clicked: number;
    open_rate: number;
  }>;
  revenue_attribution: Array<{
    attribution: string;
    orders: number;
    total_revenue: number;
  }>;
  bed_length_distribution: Array<{
    bed_length: string;
    count: number;
    percentage: number;
  }>;
}

// Color palette
const COLORS = {
  primary: '#f59e0b',
  secondary: '#3b82f6',
  success: '#22c55e',
  danger: '#ef4444',
  muted: '#71717a',
  chart: ['#f59e0b', '#3b82f6', '#22c55e', '#ef4444', '#8b5cf6'],
};

// ---------------------------------------------
// KPI Card Component
// ---------------------------------------------
function KPICard({ 
  title, 
  value, 
  change, 
  changeLabel,
  format = 'number' 
}: { 
  title: string;
  value: number;
  change?: number;
  changeLabel?: string;
  format?: 'number' | 'currency' | 'percent';
}) {
  const formatValue = (val: number) => {
    switch (format) {
      case 'currency':
        return `$${val.toLocaleString()}`;
      case 'percent':
        return `${val}%`;
      default:
        return val.toLocaleString();
    }
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
      <p className="text-zinc-400 text-sm font-medium mb-1">{title}</p>
      <p className="text-3xl font-bold text-white">{formatValue(value)}</p>
      {change !== undefined && (
        <p className={`text-sm mt-2 ${change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
          {change >= 0 ? '↑' : '↓'} {Math.abs(change)}% {changeLabel}
        </p>
      )}
    </div>
  );
}

// ---------------------------------------------
// Chart Card Wrapper
// ---------------------------------------------
function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
      <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
      {children}
    </div>
  );
}

// ---------------------------------------------
// Main Dashboard Component
// ---------------------------------------------
export function AnalyticsDashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  useEffect(() => {
    fetchMetrics();
  }, [timeRange]);

  const fetchMetrics = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('get_dashboard_metrics');
      
      if (error) throw error;
      setMetrics(data);
    } catch (err) {
      console.error('Error fetching metrics:', err);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading dashboard...</div>
      </div>
    );
  }

  if (error || !metrics) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-red-500">{error || 'No data available'}</div>
      </div>
    );
  }

  const { summary, daily_leads, conversion_by_recommendation, email_performance, revenue_attribution } = metrics;

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">Analytics Dashboard</h1>
            <p className="text-zinc-400">EZ Cycle Ramp Performance</p>
          </div>
          <div className="flex gap-2">
            {(['7d', '30d', '90d'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  timeRange === range
                    ? 'bg-amber-500 text-black'
                    : 'bg-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : '90 Days'}
              </button>
            ))}
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <KPICard
            title="Leads This Month"
            value={summary.leads_this_month}
          />
          <KPICard
            title="Orders This Month"
            value={summary.orders_this_month}
          />
          <KPICard
            title="Revenue This Month"
            value={summary.revenue_this_month}
            format="currency"
          />
          <KPICard
            title="Conversion Rate"
            value={summary.conversion_rate_30d}
            format="percent"
          />
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          
          {/* Daily Leads Chart */}
          <ChartCard title="Daily Leads & Conversions">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={daily_leads?.slice(0, 30).reverse()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                <XAxis 
                  dataKey="date" 
                  stroke="#71717a"
                  tickFormatter={(val) => new Date(val).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis stroke="#71717a" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#27272a', border: '1px solid #3f3f46' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="total_leads" 
                  name="Leads"
                  stroke={COLORS.primary} 
                  strokeWidth={2}
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="conversions" 
                  name="Conversions"
                  stroke={COLORS.success} 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Conversion by Recommendation */}
          <ChartCard title="Conversion by Recommendation">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={conversion_by_recommendation}>
                <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                <XAxis dataKey="recommendation" stroke="#71717a" />
                <YAxis stroke="#71717a" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#27272a', border: '1px solid #3f3f46' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Legend />
                <Bar dataKey="total_leads" name="Leads" fill={COLORS.muted} />
                <Bar dataKey="conversions" name="Conversions" fill={COLORS.success} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          
          {/* Revenue Attribution Pie */}
          <ChartCard title="Revenue Attribution">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={revenue_attribution}
                  dataKey="total_revenue"
                  nameKey="attribution"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ attribution, percent }) => 
                    `${attribution}: ${(percent * 100).toFixed(0)}%`
                  }
                  labelLine={false}
                >
                  {revenue_attribution?.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS.chart[index % COLORS.chart.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#27272a', border: '1px solid #3f3f46' }}
                  formatter={(value: number) => `$${value.toLocaleString()}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          {/* Email Performance */}
          <ChartCard title="Email Performance">
            <div className="space-y-4">
              {email_performance?.slice(0, 5).map((email) => (
                <div key={email.template} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-white text-sm font-medium truncate">
                      {email.template.replace(/_/g, ' ')}
                    </p>
                    <div className="flex gap-4 mt-1">
                      <span className="text-xs text-zinc-500">
                        Sent: {email.sent}
                      </span>
                      <span className="text-xs text-green-500">
                        Open: {email.open_rate}%
                      </span>
                    </div>
                  </div>
                  <div className="w-24 h-2 bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-amber-500 rounded-full"
                      style={{ width: `${email.open_rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </ChartCard>

          {/* Quick Stats */}
          <ChartCard title="Active Items">
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-zinc-800 rounded-lg">
                <span className="text-zinc-400">Active Email Sequences</span>
                <span className="text-white font-bold">{summary.active_sequences}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-zinc-800 rounded-lg">
                <span className="text-zinc-400">Pending Review Requests</span>
                <span className="text-white font-bold">{summary.pending_reviews}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-zinc-800 rounded-lg">
                <span className="text-zinc-400">This Week's Leads</span>
                <span className="text-white font-bold">{summary.leads_this_week}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-zinc-800 rounded-lg">
                <span className="text-zinc-400">This Week's Revenue</span>
                <span className="text-amber-500 font-bold">
                  ${summary.revenue_this_week.toLocaleString()}
                </span>
              </div>
            </div>
          </ChartCard>
        </div>

        {/* Recent Activity Table */}
        <ChartCard title="Recent Leads">
          <RecentLeadsTable />
        </ChartCard>
      </div>
    </div>
  );
}

// ---------------------------------------------
// Recent Leads Table Component
// ---------------------------------------------
function RecentLeadsTable() {
  const [leads, setLeads] = useState<any[]>([]);

  useEffect(() => {
    fetchRecentLeads();
  }, []);

  const fetchRecentLeads = async () => {
    const { data } = await supabase
      .from('configurator_leads')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (data) setLeads(data);
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-zinc-800">
            <th className="text-left p-3 text-zinc-400 font-medium">Email</th>
            <th className="text-left p-3 text-zinc-400 font-medium">Recommendation</th>
            <th className="text-left p-3 text-zinc-400 font-medium">Bed Length</th>
            <th className="text-left p-3 text-zinc-400 font-medium">Status</th>
            <th className="text-left p-3 text-zinc-400 font-medium">Date</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => (
            <tr key={lead.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30">
              <td className="p-3 text-white">{lead.email}</td>
              <td className="p-3">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  lead.recommendation === 'AUN250' ? 'bg-amber-500/20 text-amber-500' :
                  lead.recommendation === 'AUN200' ? 'bg-blue-500/20 text-blue-500' :
                  'bg-zinc-500/20 text-zinc-400'
                }`}>
                  {lead.recommendation || 'None'}
                </span>
              </td>
              <td className="p-3 text-zinc-400">{lead.answers?.bedLength || '—'}</td>
              <td className="p-3">
                {lead.converted_at ? (
                  <span className="text-green-500">✓ Converted</span>
                ) : (
                  <span className="text-zinc-500">Pending</span>
                )}
              </td>
              <td className="p-3 text-zinc-400">
                {new Date(lead.created_at).toLocaleDateString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AnalyticsDashboard;

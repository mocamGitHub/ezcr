import { NextResponse } from "next/server";
import { createSupabaseAdmin } from "@/lib/comms/admin";

/**
 * SendGrid Inbound Parse Webhook (multipart/form-data)
 *
 * URL: /api/webhooks/sendgrid/inbound/[secret]
 * - secret is resolved against comms_inbound_routes.route_secret to get tenant_id
 * - creates/updates contact by email
 * - creates/updates conversation (email thread)
 * - inserts comms_messages inbound
 * - stores attachments metadata (and optionally uploads to Storage bucket `comms-attachments` if available)
 */

function normalizeEmail(s: string | null | undefined): string {
  return (s ?? "").trim().toLowerCase();
}

function parseEmailAddress(fromField: string): { email: string; name?: string } {
  // Handles: "Name <email@x.com>" or "email@x.com"
  const m = /<([^>]+)>/.exec(fromField);
  if (m) {
    const email = normalizeEmail(m[1]);
    const name = fromField.replace(m[0], "").trim().replace(/^"|"$/g, "");
    return { email, name: name || undefined };
  }
  return { email: normalizeEmail(fromField) };
}

async function maybeUploadAttachment(args: {
  tenantId: string;
  messageId: string;
  filename: string;
  contentType: string;
  file: File;
}) {
  const supabase = createSupabaseAdmin();

  // Upload is optional; skip if bucket doesn't exist or errors.
  const bucket = "comms-attachments";
  const key = `${args.tenantId}/${args.messageId}/${Date.now()}_${args.filename}`.replace(/\s+/g, "_");

  try {
    const arrayBuffer = await args.file.arrayBuffer();
    const { error } = await supabase.storage.from(bucket).upload(key, new Uint8Array(arrayBuffer), {
      contentType: args.contentType,
      upsert: false,
    });
    if (error) return { storage_key: null as string | null, upload_error: error.message };
    return { storage_key: key, upload_error: null as string | null };
  } catch (e: any) {
    return { storage_key: null as string | null, upload_error: e?.message ?? String(e) };
  }
}

export async function POST(req: Request, { params }: { params: { secret: string } }) {
  const secret = params.secret;
  const supabase = createSupabaseAdmin();

  // Resolve inbound route -> tenant
  const { data: route, error: routeErr } = await supabase
    .from("comms_inbound_routes")
    .select("tenant_id,provider,channel,route_secret,metadata")
    .eq("provider", "sendgrid")
    .eq("route_secret", secret)
    .maybeSingle();

  if (routeErr) throw routeErr;
  if (!route?.tenant_id) return NextResponse.json({ error: "Invalid route secret" }, { status: 403 });

  const tenantId = route.tenant_id as string;

  const form = await req.formData();

  const fromField = String(form.get("from") ?? "");
  const toField = String(form.get("to") ?? "");
  const subject = String(form.get("subject") ?? "");
  const text = String(form.get("text") ?? "");
  const html = String(form.get("html") ?? "");
  const headersRaw = String(form.get("headers") ?? "");

  const { email: fromEmail, name: fromName } = parseEmailAddress(fromField);
  if (!fromEmail) return NextResponse.json({ error: "Missing from email" }, { status: 400 });

  // Contact by email
  const { data: existingContact, error: cSelErr } = await supabase
    .from("comms_contacts")
    .select("id,display_name")
    .eq("tenant_id", tenantId)
    .eq("email", fromEmail)
    .maybeSingle();
  if (cSelErr) throw cSelErr;

  let contactId = existingContact?.id as string | undefined;

  if (!contactId) {
    const { data: created, error: cInsErr } = await supabase
      .from("comms_contacts")
      .insert({
        tenant_id: tenantId,
        email: fromEmail,
        display_name: fromName ?? fromEmail,
        metadata: { source: "sendgrid_inbound" },
      })
      .select("id")
      .single();
    if (cInsErr) throw cInsErr;
    contactId = created.id as string;
  } else if (fromName && existingContact?.display_name !== fromName) {
    // soft update display name
    await supabase.from("comms_contacts").update({ display_name: fromName }).eq("id", contactId);
  }

  // Conversation: one per contact/channel by default
  const { data: existingConv, error: convSelErr } = await supabase
    .from("comms_conversations")
    .select("id")
    .eq("tenant_id", tenantId)
    .eq("contact_id", contactId)
    .eq("channel", "email")
    .order("updated_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (convSelErr) throw convSelErr;

  let conversationId = existingConv?.id as string | undefined;

  if (!conversationId) {
    const { data: convCreated, error: convInsErr } = await supabase
      .from("comms_conversations")
      .insert({
        tenant_id: tenantId,
        contact_id: contactId,
        channel: "email",
        subject: subject || `Email with ${fromEmail}`,
        status: "open",
        metadata: { to: toField, from: fromEmail, provider: "sendgrid" },
      })
      .select("id")
      .single();
    if (convInsErr) throw convInsErr;
    conversationId = convCreated.id as string;
  }

  // Insert inbound message
  const { data: msg, error: msgErr } = await supabase
    .from("comms_messages")
    .insert({
      tenant_id: tenantId,
      conversation_id: conversationId,
      contact_id: contactId,
      direction: "inbound",
      channel: "email",
      provider: "sendgrid",
      from_address: fromEmail,
      to_address: toField,
      subject: subject || null,
      body_text: text || "",
      body_html: html || null,
      status: "received",
      received_at: new Date().toISOString(),
      metadata: {
        raw_headers: headersRaw || null,
        raw_to: toField || null,
        route_secret: secret,
      },
    })
    .select("id")
    .single();
  if (msgErr) throw msgErr;

  await supabase.from("comms_message_events").insert({
    tenant_id: tenantId,
    message_id: msg.id,
    provider: "sendgrid",
    event_type: "inbound_received",
    payload: { from: fromEmail, to: toField, subject, has_html: Boolean(html), headers: headersRaw ? "present" : "missing" },
  });

  // Attachments
  const attachmentsCount = Number(form.get("attachments") ?? "0");
  const attachmentInfoRaw = String(form.get("attachment-info") ?? "");
  let attachmentInfo: any = null;
  try { attachmentInfo = attachmentInfoRaw ? JSON.parse(attachmentInfoRaw) : null; } catch { attachmentInfo = null; }

  const insertedAttachments = [];
  for (let i = 1; i <= attachmentsCount; i++) {
    const file = form.get(`attachment${i}`) as File | null;
    if (!file) continue;

    const filename = file.name || `attachment${i}`;
    const contentType = file.type || "application/octet-stream";
    const size = file.size;

    const upload = await maybeUploadAttachment({ tenantId, messageId: msg.id, filename, contentType, file });

    const { data: attRow, error: attErr } = await supabase
      .from("comms_message_attachments")
      .insert({
        tenant_id: tenantId,
        message_id: msg.id,
        filename,
        content_type: contentType,
        byte_size: size,
        storage_key: upload.storage_key,
        metadata: {
          upload_error: upload.upload_error,
          attachment_info: attachmentInfo?.[filename] ?? null,
        },
      })
      .select("id")
      .single();

    if (attErr) throw attErr;
    insertedAttachments.push(attRow.id);
  }

  return NextResponse.json({ ok: true, tenantId, messageId: msg.id, attachments: insertedAttachments.length });
}

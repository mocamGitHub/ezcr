import { NextResponse } from "next/server";
import { createSupabaseAdmin } from "@/lib/comms/admin";
import { verifySendGridEventWebhookSignature } from "@/lib/comms/sendgridSignature";

/**
 * SendGrid Event Webhook
 * Receives JSON array of events.
 * Maps using event.custom_args.nc_message_id + nc_tenant_id
 * Updates comms_messages status + inserts comms_message_events
 *
 * Optional signature validation (recommended in production):
 * - SENDGRID_VERIFY_EVENT_SIGNATURE=true
 * - SENDGRID_EVENT_WEBHOOK_PUBLIC_KEY=PEM
 */
function mapSendGridEventToStatus(evt: string): string | null {
  switch ((evt || "").toLowerCase()) {
    case "processed":
    case "delivered":
      return evt.toLowerCase() === "delivered" ? "delivered" : "sent";
    case "deferred":
      return "queued";
    case "bounce":
    case "dropped":
    case "spamreport":
      return "failed";
    case "unsubscribe":
    case "group_unsubscribe":
      return "failed";
    default:
      return null;
  }
}

export async function POST(req: Request) {
  const rawBody = await req.text();
  const verify = (process.env.SENDGRID_VERIFY_EVENT_SIGNATURE ?? "false").toLowerCase() === "true";

  if (verify) {
    const signature = req.headers.get("x-twilio-email-event-webhook-signature");
    const timestamp = req.headers.get("x-twilio-email-event-webhook-timestamp");
    const publicKey = process.env.SENDGRID_EVENT_WEBHOOK_PUBLIC_KEY ?? "";
    const ok = verifySendGridEventWebhookSignature({ signature, timestamp, rawBody, publicKeyPem: publicKey });
    if (!ok) return NextResponse.json({ error: "Invalid SendGrid signature" }, { status: 403 });
  }

  let events: any[] = [];
  try { events = JSON.parse(rawBody); } catch { return NextResponse.json({ error: "Invalid JSON" }, { status: 400 }); }
  if (!Array.isArray(events)) return NextResponse.json({ error: "Expected JSON array" }, { status: 400 });

  const supabase = createSupabaseAdmin();
  let processed = 0;

  for (const e of events) {
    const evt = String(e.event ?? "");
    const custom = e.custom_args ?? e.customArgs ?? {};
    const tenantId = String(custom.nc_tenant_id ?? "");
    const messageId = String(custom.nc_message_id ?? "");
    if (!tenantId || !messageId) {
      // best-effort: skip events we can't map
      continue;
    }

    // Insert event log
    const { error: evErr } = await supabase.from("comms_message_events").insert({
      tenant_id: tenantId,
      message_id: messageId,
      provider: "sendgrid",
      event_type: evt || "unknown",
      payload: e,
    });
    if (evErr) throw evErr;

    // Update status if relevant
    const mapped = mapSendGridEventToStatus(evt);
    if (mapped) {
      const patch: Record<string, any> = { status: mapped, provider_status: evt };
      if (mapped === "delivered") patch.delivered_at = new Date().toISOString();
      if (mapped === "sent") patch.sent_at = new Date().toISOString();
      if (mapped === "failed") patch.failed_at = new Date().toISOString();

      const { error: updErr } = await supabase
        .from("comms_messages")
        .update(patch)
        .eq("tenant_id", tenantId)
        .eq("id", messageId);

      if (updErr) throw updErr;
    }

    // Unsubscribe handling -> channel prefs best-effort
    if (evt === "unsubscribe" || evt === "group_unsubscribe") {
      const email = String(e.email ?? "");
      if (email) {
        const { data: contact } = await supabase
          .from("comms_contacts")
          .select("id")
          .eq("tenant_id", tenantId)
          .eq("email", email.toLowerCase())
          .maybeSingle();

        if (contact?.id) {
          await supabase
            .from("comms_channel_preferences")
            .upsert(
              {
                tenant_id: tenantId,
                contact_id: contact.id,
                channel: "email",
                consent_status: "opted_out",
                consent_source: "sendgrid_unsubscribe_event",
                updated_at: new Date().toISOString(),
              },
              { onConflict: "tenant_id,contact_id,channel" }
            );
        }
      }
    }

    processed += 1;
  }

  return NextResponse.json({ ok: true, processed });
}

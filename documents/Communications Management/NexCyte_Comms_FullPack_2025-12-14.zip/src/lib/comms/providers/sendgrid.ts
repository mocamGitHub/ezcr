export type SendGridSendArgs = {
  apiKey: string;
  fromEmail: string;
  toEmail: string;
  subject: string;
  text?: string | null;
  html?: string | null;
  customArgs?: Record<string, string>;
  onBehalfOf?: string | null;
  replyTo?: string | null;
  headers?: Record<string, string>;
};

export async function sendSendGridEmail(args: SendGridSendArgs): Promise<{ messageId?: string; raw: any }> {
  const payload: any = {
    personalizations: [
      {
        to: [{ email: args.toEmail }],
        custom_args: args.customArgs ?? {},
      },
    ],
    from: { email: args.fromEmail },
    subject: args.subject,
    content: [],
  };

  if (args.replyTo) payload.reply_to = { email: args.replyTo };
  if (args.headers) payload.headers = args.headers;

  if (args.text) payload.content.push({ type: "text/plain", value: args.text });
  if (args.html) payload.content.push({ type: "text/html", value: args.html });
  if (!payload.content.length) payload.content.push({ type: "text/plain", value: "" });

  const headers: Record<string, string> = {
    "Authorization": `Bearer ${args.apiKey}`,
    "Content-Type": "application/json",
  };
  if (args.onBehalfOf) headers["On-Behalf-Of"] = args.onBehalfOf;

  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers,
    body: JSON.stringify(payload),
  });

  const rawText = await res.text();
  const raw = rawText ? safeJson(rawText) : {};
  if (!res.ok) {
    const err = raw?.errors?.[0]?.message ?? raw?.message ?? `SendGrid send failed (${res.status})`;
    throw new Error(err);
  }

  const messageId = res.headers.get("x-message-id") ?? undefined;
  return { messageId, raw };
}

function safeJson(s: string) {
  try { return JSON.parse(s); } catch { return { raw: s }; }
}

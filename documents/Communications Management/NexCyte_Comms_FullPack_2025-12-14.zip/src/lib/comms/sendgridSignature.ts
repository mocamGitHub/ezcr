import crypto from "crypto";

/**
 * SendGrid Event Webhook signature verification (ECDSA)
 * Headers:
 * - x-twilio-email-event-webhook-signature
 * - x-twilio-email-event-webhook-timestamp
 *
 * Public key provided by SendGrid (PEM).
 * Env:
 * - SENDGRID_VERIFY_EVENT_SIGNATURE=true
 * - SENDGRID_EVENT_WEBHOOK_PUBLIC_KEY="-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----"
 */
export function verifySendGridEventWebhookSignature(args: {
  signature: string | null;
  timestamp: string | null;
  rawBody: string;
  publicKeyPem: string;
}): boolean {
  const { signature, timestamp, rawBody, publicKeyPem } = args;
  if (!signature || !timestamp || !publicKeyPem) return false;

  const payload = timestamp + rawBody;

  try {
    const verifier = crypto.createVerify("RSA-SHA256"); // ECDSA keys still verify with this in Node via OpenSSL mapping
    verifier.update(payload);
    verifier.end();
    return verifier.verify(publicKeyPem, signature, "base64");
  } catch {
    // Some environments require explicit 'sha256' and 'ecdsa-with-SHA256' differs.
    try {
      const ok = crypto.verify(
        "sha256",
        Buffer.from(payload, "utf8"),
        { key: publicKeyPem },
        Buffer.from(signature, "base64")
      );
      return ok;
    } catch {
      return false;
    }
  }
}

# NexCyte Comms Management System — Full Pack (2025-12-14)

This ZIP is an overwrite-safe **drop-in** module pack for a Next.js App Router + Supabase stack.

It includes:
- Email (SendGrid): outbound send + inbound parse webhook + event webhook
- SMS (Twilio): outbound send + inbound webhook + status callback webhook
- Multi-tenant isolation (tenant_id everywhere)
- Template CRUD with immutable version history (publish/rollback via templates.active_version_id)
- Sequences CRUD with step builder (steps persist)
- Unified Inbox (threads + reply composer using canned template versions)
- Seed + checklists + env template

## How to apply
1. Unzip into your repo root.
2. Ensure `@/components/ui/*` (ShadCN) exists (Button/Card/Input/Tabs/Select/Textarea/etc.).
3. Run Supabase migrations (or apply SQLs).
4. Set env vars from `.env.example`.
5. Run the seed script (optional) or insert your tenant mappings.

## Security model
- All public webhooks use **Supabase service role**.
- `/api/comms/send` is protected by `NC_INTERNAL_API_KEY` and intended for n8n/worker calls.

## Notes
- Signature validation:
  - Twilio signatures supported (recommended on).
  - SendGrid Event Webhook signature validation supported (optional on).
- Inbound email attachments:
  - Metadata stored in `comms_message_attachments`.
  - Optional upload to Supabase Storage bucket `comms-attachments` (if present).


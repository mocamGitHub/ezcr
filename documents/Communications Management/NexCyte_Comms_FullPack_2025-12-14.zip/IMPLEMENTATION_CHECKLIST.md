# NexCyte Comms Management System — Full Deployment Checklist (2025-12-14)

## 1) Apply DB migrations
- [ ] Apply `supabase/migrations/20251214_0001_comms_phone_numbers.sql`
- [ ] Confirm existing comms tables exist (from prior schema pack):
  - comms_contacts
  - comms_channel_preferences
  - comms_templates, comms_template_versions
  - comms_sequences, comms_sequence_steps
  - comms_conversations, comms_messages, comms_message_events
  - comms_message_attachments
  - comms_tenant_settings, comms_inbound_routes

## 2) Environment variables
Copy `.env.example` to `.env.local` and fill:

### Core
- [ ] NEXT_PUBLIC_SUPABASE_URL
- [ ] SUPABASE_SERVICE_ROLE_KEY

### Dev tenant resolution
- [ ] NC_DEFAULT_TENANT_ID (recommended for local dev unless you inject `x-nc-tenant-id`)

### Internal send endpoint security
- [ ] NC_INTERNAL_API_KEY
- n8n calls must include header: `x-nc-internal-key: <NC_INTERNAL_API_KEY>`

### SendGrid
- [ ] SENDGRID_API_KEY
- [ ] SENDGRID_FROM_EMAIL
- [ ] Optional: SENDGRID_ON_BEHALF_OF (subuser)

### SendGrid Event Webhook signature (optional but recommended)
- [ ] SENDGRID_VERIFY_EVENT_SIGNATURE=true
- [ ] SENDGRID_EVENT_WEBHOOK_PUBLIC_KEY=PEM public key from SendGrid UI

### Twilio
- [ ] TWILIO_ACCOUNT_SID
- [ ] TWILIO_AUTH_TOKEN
- [ ] TWILIO_DEFAULT_FROM (fallback if no tenant primary number found)
- [ ] TWILIO_VALIDATE_SIGNATURE=true
- [ ] TWILIO_STATUS_CALLBACK_URL=https://<domain>/api/webhooks/twilio/status

## 3) Provider setup

### A) SendGrid domain auth
- [ ] Authenticate domain (SPF/DKIM) in SendGrid and add DNS records.
- [ ] Verify test email passes SPF/DKIM/DMARC.

### B) SendGrid Inbound Parse
- [ ] Create Inbound Parse route in SendGrid.
- [ ] Destination URL:
  - `POST https://<domain>/api/webhooks/sendgrid/inbound/<secret>`
- [ ] Seed the secret into `comms_inbound_routes`:
  - provider=sendgrid, channel=email, route_secret=<secret>, tenant_id=<tenant>

### C) SendGrid Event Webhook
- [ ] Set Event Webhook URL:
  - `POST https://<domain>/api/webhooks/sendgrid/events`
- [ ] Select events:
  - processed, delivered, deferred, bounce, dropped, spamreport, unsubscribe, group_unsubscribe
- [ ] If using signature validation, enable it and set the public key in env.

### D) Twilio inbound + status callbacks
- [ ] For each Twilio number:
  - Messaging webhook: `POST https://<domain>/api/webhooks/twilio/inbound`
  - Status callback:  `POST https://<domain>/api/webhooks/twilio/status`
- [ ] Ensure tenant mapping exists:
  - Insert row in `comms_phone_numbers` where phone_number == Twilio "To" E.164.

## 4) Seed (optional but recommended for first run)
- [ ] Set env: EZCR_TENANT_ID, EZCR_TWILIO_NUMBER, EZCR_SENDGRID_INBOUND_SECRET
- [ ] Run:
  - `node scripts/seed-comms-full.ts`

## 5) Test plan (end-to-end)

### Email outbound + events
- [ ] Create a contact with email
- [ ] Create template version + publish
- [ ] Call internal send API:
  - POST `/api/comms/send`
  - headers: x-nc-internal-key
  - body: tenantId, contactId, channel=email, templateVersionId, variables
- [ ] Confirm DB:
  - comms_messages status queued -> sent
  - comms_message_events includes queued + sent + sendgrid events
- [ ] Confirm delivered event updates status to delivered

### Email inbound
- [ ] Send email to inbound parse address
- [ ] Confirm:
  - contact created/updated
  - conversation created/updated
  - inbound comms_message inserted
  - attachments metadata recorded (uploads optional)

### SMS inbound + status
- [ ] Text your Twilio number
- [ ] Confirm inbound message inserted and tenant resolved by To
- [ ] Send outbound SMS via `/api/comms/send`
- [ ] Confirm Twilio status callback updates message to delivered/failed and logs events


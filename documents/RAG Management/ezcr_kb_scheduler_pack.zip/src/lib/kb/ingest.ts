import { load } from "cheerio";
import crypto from "node:crypto";
import OpenAI from "openai";
import { supabaseAdmin } from "@/src/lib/supabase/admin";

export type DocType = "web" | "pdf" | "faq" | "policy" | "manual" | "other";

export function sha256(text: string) {
  return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

export function chunkText(text: string, maxChars = 1100, overlapChars = 150): string[] {
  const t = text.replace(/\s+/g, " ").trim();
  if (!t) return [];
  const chunks: string[] = [];
  let i = 0;
  while (i < t.length) {
    const end = Math.min(t.length, i + maxChars);
    const chunk = t.slice(i, end).trim();
    if (chunk.length > 0) chunks.push(chunk);
    if (end >= t.length) break;
    i = Math.max(0, end - overlapChars);
  }
  return chunks;
}

export function extractTextFromHtml(html: string): { title?: string; text: string } {
  const $ = load(html);
  $("script, style, noscript, svg, canvas, nav, footer, header, form, iframe").remove();

  const title = $("title").first().text().trim() || undefined;

  const main =
    $("main").first().text().trim() ||
    $("article").first().text().trim() ||
    $("#__next").first().text().trim() ||
    $("body").text().trim();

  const text = main.replace(/\s+/g, " ").trim();
  return { title, text };
}

function openai() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("Missing OPENAI_API_KEY");
  return new OpenAI({ apiKey: key });
}

async function embed(text: string): Promise<number[]> {
  const model = process.env.OPENAI_EMBED_MODEL || "text-embedding-3-small";
  const res = await openai().embeddings.create({ model, input: text });
  const v = res.data?.[0]?.embedding;
  if (!v) throw new Error("No embedding returned");
  return v as number[];
}

async function upsertDocument(params: {
  tenant_id: string;
  doc_type: DocType;
  title?: string;
  source_url: string;
  source_hash: string;
  tags?: string[];
}) {
  const sb = supabaseAdmin();

  const { data: existing, error: selErr } = await sb
    .from("kb_documents")
    .select("id, source_hash")
    .eq("tenant_id", params.tenant_id)
    .eq("source_url", params.source_url)
    .maybeSingle();

  if (selErr) throw new Error(`Select kb_documents failed: ${selErr.message}`);

  if (existing?.id) {
    if (existing.source_hash === params.source_hash) {
      return { document_id: existing.id as string, unchanged: true };
    }
    const { error: upErr } = await sb
      .from("kb_documents")
      .update({
        doc_type: params.doc_type,
        title: params.title,
        source_hash: params.source_hash,
        tags: params.tags ?? [],
        status: "active",
      })
      .eq("id", existing.id);

    if (upErr) throw new Error(`Update kb_documents failed: ${upErr.message}`);
    return { document_id: existing.id as string, unchanged: false };
  }

  const { data: ins, error: insErr } = await sb
    .from("kb_documents")
    .insert({
      tenant_id: params.tenant_id,
      doc_type: params.doc_type,
      title: params.title,
      source_url: params.source_url,
      source_hash: params.source_hash,
      tags: params.tags ?? [],
      status: "active",
    })
    .select("id")
    .single();

  if (insErr) throw new Error(`Insert kb_documents failed: ${insErr.message}`);
  return { document_id: ins.id as string, unchanged: false };
}

async function replaceChunks(params: {
  tenant_id: string;
  document_id: string;
  source_url: string;
  chunks: string[];
  rate_sleep_ms?: number;
}) {
  const sb = supabaseAdmin();

  const { error: delErr } = await sb
    .from("kb_chunks")
    .delete()
    .eq("tenant_id", params.tenant_id)
    .eq("document_id", params.document_id);

  if (delErr) throw new Error(`Delete kb_chunks failed: ${delErr.message}`);

  const rate = params.rate_sleep_ms ?? 120;
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  const batchSize = 20;
  for (let i = 0; i < params.chunks.length; i += batchSize) {
    const slice = params.chunks.slice(i, i + batchSize);

    const rows = [];
    for (let j = 0; j < slice.length; j++) {
      const idx = i + j;
      const content = slice[j];

      const embedding = await embed(content);
      await sleep(rate);

      rows.push({
        tenant_id: params.tenant_id,
        document_id: params.document_id,
        chunk_index: idx,
        content,
        content_tokens: null,
        heading: null,
        source_url: params.source_url,
        tags: [],
        embedding,
      });
    }

    const { error: insErr } = await sb.from("kb_chunks").insert(rows);
    if (insErr) throw new Error(`Insert kb_chunks failed: ${insErr.message}`);
  }
}

export async function ingestSingleUrl(params: {
  tenant_id: string;
  url: string;
  doc_type?: DocType;
  tags?: string[];
  chunk_max_chars?: number;
  chunk_overlap_chars?: number;
  min_text_len?: number;
}) {
  const res = await fetch(params.url, { headers: { "user-agent": "EZCR-KB-Ingest/1.0" } });
  if (!res.ok) throw new Error(`Fetch failed ${res.status} for ${params.url}`);
  const html = await res.text();

  const { title, text } = extractTextFromHtml(html);
  const minLen = params.min_text_len ?? 200;
  if (!text || text.length < minLen) return { url: params.url, skipped: true, reason: "too_short" as const };

  const hash = sha256(text);
  const { document_id, unchanged } = await upsertDocument({
    tenant_id: params.tenant_id,
    doc_type: params.doc_type ?? "web",
    title,
    source_url: params.url,
    source_hash: hash,
    tags: params.tags ?? [],
  });

  if (unchanged) return { url: params.url, skipped: true, reason: "unchanged" as const };

  const chunks = chunkText(
    text,
    params.chunk_max_chars ?? 1100,
    params.chunk_overlap_chars ?? 150
  );

  await replaceChunks({ tenant_id: params.tenant_id, document_id, source_url: params.url, chunks });

  return { url: params.url, skipped: false, chunks: chunks.length, title };
}

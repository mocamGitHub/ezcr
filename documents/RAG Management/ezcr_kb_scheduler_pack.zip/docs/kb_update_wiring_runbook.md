# KB Update Wiring (n8n + Webhooks + Cron)

## Recommended approach
Use BOTH:
1) Nightly ingest (covers everything)
2) Event-driven ingest for a single URL when something changes (fast updates)

## Option 1: n8n nightly (self-hosted)
Import:
- `n8n/workflows/kb_ingest_nightly_execute_command.json`

Then:
- Set it ACTIVE
- Ensure the n8n container has access to your repo folder OR the script path you run
- Ensure required env vars are available to n8n (container env or n8n credentials):
  - SUPABASE_URL
  - SUPABASE_SERVICE_ROLE_KEY
  - OPENAI_API_KEY
  - TENANT_ID
  - KB_SITEMAP_URL
  - KB_URL_PREFIX_FILTER

## Option 2: Event-driven single URL ingest
### A) Next.js endpoint
- `POST /api/admin/kb/ingest-url` (Bearer protected with EZCR_RAG_SHARED_SECRET)
Body:
```json
{ "url": "https://ezcycleramp.com/some-page" }
```
Header:
- Authorization: Bearer <EZCR_RAG_SHARED_SECRET>
- x-tenant-id: <tenant uuid>  (or Host must map in tenant_domains)

### B) n8n webhook -> call Next endpoint
Import:
- `n8n/workflows/kb_ingest_single_url_webhook.json`

Then call your n8n webhook with:
```json
{ "tenant_id": "<uuid>", "url": "https://ezcycleramp.com/new-product-page" }
```

You can trigger that webhook from:
- CMS publish webhook
- internal admin UI “Re-index this page” button
- your deployment pipeline after content changes

## Option 3: GitHub Actions nightly
If you prefer, use:
- `.github/workflows/kb_ingest_nightly.yml`

Set repo secrets accordingly.

## “Keep learning” loop
Log and review:
- questions with citations_count == 0
- questions with confidence.overall < 0.5
Then add/update content and trigger single-URL ingest.

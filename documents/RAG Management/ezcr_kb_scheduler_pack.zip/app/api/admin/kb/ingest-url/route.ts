import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { resolveTenantId } from "@/src/lib/tenant/resolve";
import { ingestSingleUrl } from "@/src/lib/kb/ingest";

export const runtime = "nodejs";

/**
 * POST /api/admin/kb/ingest-url
 * Server-to-server only. Use a separate secret from EZCR_RAG_SHARED_SECRET if you prefer,
 * but using the same is okay if you keep it server-only.
 */
const Body = z.object({
  url: z.string().url(),
  doc_type: z.enum(["web", "pdf", "faq", "policy", "manual", "other"]).optional(),
  tags: z.array(z.string()).optional(),
});

function jsonError(trace_id: string, status: number, code: string, message: string, details?: any) {
  return NextResponse.json({ trace_id, error: { code, message, details } }, { status });
}

export async function POST(req: NextRequest) {
  const trace_id = crypto.randomUUID();

  const secret = process.env.EZCR_RAG_SHARED_SECRET;
  const auth = req.headers.get("authorization") || "";
  const ok = secret && auth.toLowerCase().startsWith("bearer ") && auth.slice(7).trim() === secret;
  if (!ok) return jsonError(trace_id, 401, "UNAUTHORIZED", "Missing or invalid Authorization token.");

  let body: z.infer<typeof Body>;
  try {
    body = Body.parse(await req.json());
  } catch (e: any) {
    return jsonError(trace_id, 400, "BAD_REQUEST", "Invalid body", e?.errors ?? String(e));
  }

  const tenant_id = req.headers.get("x-tenant-id") || (await resolveTenantId(req));

  try {
    const r = await ingestSingleUrl({
      tenant_id,
      url: body.url,
      doc_type: body.doc_type,
      tags: body.tags,
    });

    return NextResponse.json({ trace_id, tenant_id, result: r });
  } catch (e: any) {
    return jsonError(trace_id, 500, "INTERNAL", "Ingestion failed", String(e?.message ?? e));
  }
}

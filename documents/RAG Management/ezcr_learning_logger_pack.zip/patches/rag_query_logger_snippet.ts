// --- Add near the bottom of /api/rag/query after you compute response ---
import { supabaseAdmin } from "@/src/lib/supabase/admin";

// ... inside POST handler, after toolUsed/toolResult/citations/confidence are known:
try {
  const citations_count = citations?.length ?? 0;
  const top_score = citations_count ? (citations[0]?.score ?? null) : null;
  const overall = confidence?.overall ?? null;
  const shouldLog =
    citations_count === 0 ||
    (typeof overall === "number" && overall < 0.55) ||
    (toolUsed && toolResult?.error);

  if (shouldLog) {
    const sb = supabaseAdmin();
    await sb.from("assistant_question_log").insert({
      tenant_id,
      channel,
      question,
      intent,
      citations_count,
      top_score,
      confidence_overall: overall,
      tool_used: toolUsed,
      tool_error: toolResult?.error ?? null,
      page_url: body.context?.page_url ?? null,
      conversation_id: body.conversation?.conversation_id ?? null,
      customer_email: body.user?.email ?? null,
      customer_phone: body.user?.phone ?? null,
    });
  }
} catch {
  // never fail the request due to logging
}

# Patch: “Unanswered Questions” logger

## 1) Apply migration
- `supabase/migrations/20251215_assistant_learning_log.sql`

## 2) Patch `/api/rag/query` to insert logs
Add an insert into `assistant_question_log` when any of these conditions are true:
- citations_count == 0
- confidence_overall < 0.55
- toolUsed exists AND toolResult.error exists

This gives you a weekly list of gaps to fix by adding docs/rules, then re-indexing.

## 3) Suggested weekly review query (Supabase SQL editor)
```sql
select
  date_trunc('day', created_at) as day,
  intent,
  count(*) as cnt,
  avg(confidence_overall) as avg_conf,
  sum(case when citations_count = 0 then 1 else 0 end) as no_citations
from public.assistant_question_log
where tenant_id = '<TENANT_UUID>'
  and created_at >= now() - interval '14 days'
group by 1,2
order by 1 desc, cnt desc;
```

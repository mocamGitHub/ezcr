-- Assistant learning log: capture unanswered / low-confidence queries for KB improvement
create extension if not exists pgcrypto;

create table if not exists public.assistant_question_log (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  channel text not null check (channel in ('chat','voice')),
  question text not null,
  intent text,
  citations_count int not null default 0,
  top_score float,
  confidence_overall float,
  tool_used text,
  tool_error text,
  page_url text,
  conversation_id text,
  customer_email text,
  customer_phone text,
  created_at timestamptz not null default now()
);

create index if not exists assistant_question_log_tenant_idx on public.assistant_question_log (tenant_id);
create index if not exists assistant_question_log_created_idx on public.assistant_question_log (created_at desc);
create index if not exists assistant_question_log_intent_idx on public.assistant_question_log (intent);

alter table public.assistant_question_log enable row level security;

-- No anon access by default.
-- Create admin policies later for your internal dashboard.

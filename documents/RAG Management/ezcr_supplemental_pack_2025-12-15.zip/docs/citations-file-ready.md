# File-ready citations

This repo’s RAG response includes `citations` that point to sources used to answer the user.

This document defines an **additive** extension to citations so the system can later support
file-based sources (PDF/DOCX/manuals) without changing existing clients.

## Backwards compatibility guarantee

- Existing citation fields (for example `url`, `title`, `snippet`, `score`) **must not be removed or renamed**.
- Only **optional** fields are added.
- For URL sources, `url` remains populated as it is today.
- For file sources later, `url` may be null, and `source_uri` will be used.

## Citation shape

Existing fields vary by implementation, but the new optional fields are:

- `source_type`: `"url" | "file" | "text"` (default `"url"` when absent)
- `source_uri`: string (URL or storage key for files, e.g. `tenants/<tenant_id>/kb_files/manual.pdf`)
- `doc_version`: string (e.g. `"v1.2"`, `"2025-01"`)
- `page_number`: number (for PDFs)
- `section`: string (heading/anchor)

Example:

```json
{
  "title": "AUN-250 Manual",
  "url": null,
  "snippet": "…",
  "score": 0.82,
  "source_type": "file",
  "source_uri": "tenants/<tenant_id>/kb_files/aun-250-manual-v1.2.pdf",
  "doc_version": "v1.2",
  "page_number": 7,
  "section": "Loading Procedure"
}
```

## Implementation notes

- These fields may come from `kb_chunks` directly, or be mirrored from `kb_documents`.
- Prefer chunk values; fall back to document mirror values.
- Never expose storage buckets publicly; when file citations are enabled, resolve them through a tenant-checked server route that issues a signed URL.

## Future endpoint (optional stub)

A future endpoint can exist to resolve file sources:

`GET /api/kb/source?source_type=file&source_uri=<...>`

The handler must:
- resolve tenant via Host → `tenant_domains`
- verify the requested `source_uri` belongs to that tenant
- return a signed URL (not implemented in this pack)

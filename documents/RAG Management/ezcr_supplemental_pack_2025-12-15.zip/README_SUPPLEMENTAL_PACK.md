# EZ Cycle Ramp / NexCyte — Supplemental Pack (2025-12-15)

This pack contains **new** artifacts discussed after the original ZIPs:
- File-ready KB metadata migration (additive only)
- File-ready citations documentation
- Optional n8n workflow: reindex KB URL when an admin resolves a learning log entry
- One-command staging deploy scripts with DRY_RUN support
- n8n API verify + workflow sync scripts (Header Auth)

## What’s inside

- `supabase/migrations/20251215_0100_kb_file_ready_metadata.sql`
- `docs/citations-file-ready.md`
- `n8n/workflows/ezcr_reindex_on_log_resolve.json`
- `scripts/verify_n8n_api.sh`
- `scripts/n8n_sync_workflows.sh`
- `scripts/n8n_sync_workflows.mjs`
- `scripts/deploy_staging.sh` (supports `DRY_RUN=1`)
- `scripts/smoke_test_staging.sh`
- `scripts/sql/seed_staging_domain.sql` (optional helper)

## How to use

1) Unzip at the **repo root** (so folders merge).
2) Commit.
3) In staging env, set:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - (recommended for scripts) `SUPABASE_DB_URL`
   - `RAG_BEARER_TOKEN` (for smoke test)
   - For n8n sync (optional):
     - `N8N_BASE_URL`
     - `N8N_API_KEY`
     - `N8N_API_KEY_HEADER` (default `X-N8N-API-KEY`)
     - `N8N_API_VERSION` (default `v1`)
   - For the reindex workflow itself:
     - `EZCR_BASE_URL=https://staging.ezcycleramp.com`
     - `EZCR_KB_ADMIN_TOKEN=<bearer token for /api/admin/kb/ingest-url>`

Run:
- `DRY_RUN=1 bash scripts/deploy_staging.sh`
- `bash scripts/deploy_staging.sh`
- `bash scripts/smoke_test_staging.sh`

> Note: This pack does NOT patch your existing `/api/rag/query` citations mapping automatically because repo implementations differ.
> Use the Claude prompt in `claude/CLAUDE_FILE_READY_CITATIONS_PROMPT.md` to apply the additive code edits safely.

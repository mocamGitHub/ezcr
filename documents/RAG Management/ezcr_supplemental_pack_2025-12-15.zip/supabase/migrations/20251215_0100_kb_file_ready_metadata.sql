-- 20251215_0100_kb_file_ready_metadata.sql
-- Purpose: Make KB schema "file-ready" via metadata only (no parser/UI required).
-- Safe, additive, idempotent.

-- 1) kb_documents: add source metadata + versioning fields
alter table if exists public.kb_documents
  add column if not exists source_type text not null default 'url',           -- url | file | text
  add column if not exists source_uri text null,                               -- url OR storage key (e.g., tenants/<tenant_id>/kb_files/...)
  add column if not exists doc_version text null,                              -- e.g., "v1.0", "2025-01"
  add column if not exists mime_type text null,                                -- application/pdf, etc.
  add column if not exists file_size_bytes bigint null,
  add column if not exists checksum_sha256 text null,
  add column if not exists effective_at timestamptz null,
  add column if not exists expires_at timestamptz null;

-- Optional: keep an updated_at timestamp if you don’t already have one
do $$
begin
  if not exists (
    select 1
    from information_schema.columns
    where table_schema='public' and table_name='kb_documents' and column_name='updated_at'
  ) then
    alter table public.kb_documents add column updated_at timestamptz not null default now();
  end if;
end $$;

-- 2) kb_chunks: add citation-friendly anchors (page/section) and source mirror fields (optional but useful)
alter table if exists public.kb_chunks
  add column if not exists source_type text null,        -- mirrors doc.source_type for convenience
  add column if not exists source_uri text null,         -- mirrors doc.source_uri
  add column if not exists doc_version text null,        -- mirrors doc.doc_version
  add column if not exists page_number int null,         -- for PDFs
  add column if not exists section text null;            -- for headings/anchors

-- 3) Constraints (safe “add if missing”)
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'kb_documents_source_type_chk'
  ) then
    alter table public.kb_documents
      add constraint kb_documents_source_type_chk
      check (source_type in ('url','file','text'));
  end if;

  if not exists (
    select 1 from pg_constraint
    where conname = 'kb_chunks_source_type_chk'
  ) then
    alter table public.kb_chunks
      add constraint kb_chunks_source_type_chk
      check (source_type is null or source_type in ('url','file','text'));
  end if;
end $$;

-- 4) Indexes (helps future lookups + reindex workflows)
create index if not exists kb_documents_tenant_source_idx
  on public.kb_documents (tenant_id, source_type);

create index if not exists kb_documents_tenant_source_uri_idx
  on public.kb_documents (tenant_id, source_uri);

create index if not exists kb_chunks_tenant_source_uri_idx
  on public.kb_chunks (tenant_id, source_uri);

create index if not exists kb_chunks_doc_page_idx
  on public.kb_chunks (document_id, page_number);

-- 5) Optional backfill: mirror fields from documents to chunks (non-destructive)
update public.kb_chunks c
set
  source_type = coalesce(c.source_type, d.source_type),
  source_uri = coalesce(c.source_uri, d.source_uri),
  doc_version = coalesce(c.doc_version, d.doc_version)
from public.kb_documents d
where c.document_id = d.id
  and (c.source_type is null or c.source_uri is null or c.doc_version is null);

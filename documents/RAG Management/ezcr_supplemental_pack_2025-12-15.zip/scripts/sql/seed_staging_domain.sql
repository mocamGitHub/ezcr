-- scripts/sql/seed_staging_domain.sql
-- Optional helper. Safe/idempotent.
-- This tries to insert staging.ezcycleramp.com into tenant_domains without guessing tenant_id.
-- It attempts common tenant key columns (slug/key/code/name) if a tenants table exists.
-- If it cannot resolve a tenant_id, it will do nothing.

do $$
declare
  v_tenant_id uuid;
begin
  -- Try common patterns; adjust if your schema differs.
  if exists (select 1 from information_schema.tables where table_schema='public' and table_name='tenants') then

    -- Try slug
    if exists (select 1 from information_schema.columns where table_schema='public' and table_name='tenants' and column_name='slug') then
      select id into v_tenant_id from public.tenants where slug in ('ezcr','ez-cycle-ramp','ezcycleramp') limit 1;
    end if;

    -- Try key
    if v_tenant_id is null and exists (select 1 from information_schema.columns where table_schema='public' and table_name='tenants' and column_name='key') then
      select id into v_tenant_id from public.tenants where key in ('ezcr','ezcycleramp') limit 1;
    end if;

    -- Try code
    if v_tenant_id is null and exists (select 1 from information_schema.columns where table_schema='public' and table_name='tenants' and column_name='code') then
      select id into v_tenant_id from public.tenants where code in ('ezcr','ezcycleramp') limit 1;
    end if;

    -- Try name
    if v_tenant_id is null and exists (select 1 from information_schema.columns where table_schema='public' and table_name='tenants' and column_name='name') then
      select id into v_tenant_id from public.tenants where name ilike '%EZ Cycle Ramp%' limit 1;
    end if;

    if v_tenant_id is not null then
      insert into public.tenant_domains (tenant_id, domain)
      values (v_tenant_id, 'staging.ezcycleramp.com')
      on conflict do nothing;
    end if;
  end if;
end $$;

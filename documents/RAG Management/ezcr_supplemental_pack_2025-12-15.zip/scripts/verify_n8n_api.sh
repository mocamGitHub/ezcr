#!/usr/bin/env bash
set -euo pipefail

: "${N8N_BASE_URL:?N8N_BASE_URL is required (e.g. https://n8n.example.com)}"
: "${N8N_API_KEY:?N8N_API_KEY is required}"

N8N_API_VERSION="${N8N_API_VERSION:-v1}"
N8N_API_KEY_HEADER="${N8N_API_KEY_HEADER:-X-N8N-API-KEY}"

URL="${N8N_BASE_URL%/}/api/${N8N_API_VERSION}/workflows?limit=1"

tmp="$(mktemp)"
status="$(curl -sS -o "$tmp" -w "%{http_code}" \
  -H "${N8N_API_KEY_HEADER}: ${N8N_API_KEY}" \
  "$URL" || true)"

if [[ "$status" != "200" ]]; then
  echo "n8n API check FAILED (status=$status) for: $URL" >&2
  echo "Response:" >&2
  cat "$tmp" >&2 || true
  rm -f "$tmp"
  exit 1
fi

rm -f "$tmp"
echo "n8n API OK"

#!/usr/bin/env bash
set -euo pipefail

STAGING_BASE_URL="${STAGING_BASE_URL:-https://staging.ezcycleramp.com}"
: "${RAG_BEARER_TOKEN:?RAG_BEARER_TOKEN is required}"

endpoint="${STAGING_BASE_URL%/}/api/rag/query"

call() {
  local q="$1"
  echo
  echo "==> Question: $q"
  tmp="$(mktemp)"
  status="$(curl -sS -o "$tmp" -w "%{http_code}" \
    -H "Authorization: Bearer ${RAG_BEARER_TOKEN}" \
    -H "Content-Type: application/json" \
    -X POST \
    -d "{\"question\": $(python - <<'PY'\nimport json,sys\nprint(json.dumps(sys.argv[1]))\nPY\n"$q") }" \
    "$endpoint" || true)"
  echo "HTTP $status"
  cat "$tmp"
  rm -f "$tmp"
}

echo "== EZCR staging smoke test =="
echo "Endpoint: $endpoint"

call "What is the difference between AUN-210 and AUN-250?"
call "Do you ship to Antarctica and what is the price in pesos?"

echo
echo "To verify learning logs inserted (run in SQL editor):"
cat <<'SQL'
select created_at, host, question, citations_count, confidence, status
from public.assistant_question_log
order by created_at desc
limit 20;
SQL

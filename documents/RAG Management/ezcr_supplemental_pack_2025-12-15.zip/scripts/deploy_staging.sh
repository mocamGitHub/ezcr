#!/usr/bin/env bash
set -euo pipefail

DRY_RUN="${DRY_RUN:-0}"

need() {
  local var="$1"
  if [[ -z "${!var:-}" ]]; then
    echo "Missing required env var: $var" >&2
    exit 1
  fi
}

echo "== EZCR staging deploy =="

# Recommended for scripting
# SUPABASE_DB_URL should be a Postgres connection string for psql.
# If absent, we fall back to supabase CLI for migrations in normal mode.
if [[ "$DRY_RUN" == "1" ]]; then
  echo "DRY_RUN=1 (no changes will be made)"
fi

# Validate core env (for runtime)
need SUPABASE_URL
need SUPABASE_SERVICE_ROLE_KEY

# Optional but recommended for scripted DB operations
HAS_PSQL_DB_URL="0"
if [[ -n "${SUPABASE_DB_URL:-}" ]]; then
  HAS_PSQL_DB_URL="1"
fi

has_cmd() { command -v "$1" >/dev/null 2>&1; }

# --- Connectivity checks (DRY_RUN) ---
if [[ "$DRY_RUN" == "1" ]]; then
  echo "-- Checking DB connectivity"
  if [[ "$HAS_PSQL_DB_URL" == "1" && $(has_cmd psql && echo yes || echo no) == "yes" ]]; then
    psql "$SUPABASE_DB_URL" -c "select 1;" >/dev/null
    echo "DB OK (psql)"
  elif has_cmd supabase; then
    # supabase doesn't have a universal ping, but we can at least confirm CLI exists
    echo "Supabase CLI present. (DB ping via psql is recommended for full validation.)"
  else
    echo "DRY_RUN requires either SUPABASE_DB_URL+psql or supabase CLI installed." >&2
    exit 1
  fi

  if [[ -n "${N8N_BASE_URL:-}" && -n "${N8N_API_KEY:-}" ]]; then
    echo "-- Checking n8n API connectivity"
    bash scripts/verify_n8n_api.sh
  else
    echo "-- n8n env not set; skipping n8n check"
  fi

  echo "DRY_RUN succeeded."
  exit 0
fi

# --- Apply migrations ---
echo "-- Applying migrations"
if has_cmd supabase; then
  echo "Using supabase CLI: supabase db push"
  supabase db push
elif [[ "$HAS_PSQL_DB_URL" == "1" && $(has_cmd psql && echo yes || echo no) == "yes" ]]; then
  echo "Using psql with SUPABASE_DB_URL. Applying migrations in directory order."
  # Apply all migrations in lexical order
  for f in supabase/migrations/*.sql; do
    echo "Applying $f"
    psql "$SUPABASE_DB_URL" -v ON_ERROR_STOP=1 -f "$f"
  done
else
  echo "Cannot apply migrations. Install supabase CLI OR set SUPABASE_DB_URL and have psql installed." >&2
  exit 1
fi

# --- Sanity check: assistant_question_log ---
if [[ "$HAS_PSQL_DB_URL" == "1" && $(has_cmd psql && echo yes || echo no) == "yes" ]]; then
  echo "-- Sanity check: assistant_question_log exists"
  psql "$SUPABASE_DB_URL" -v ON_ERROR_STOP=1 -c "select 1 from public.assistant_question_log limit 1;" >/dev/null || true
fi

# --- Optional: seed tenant_domains for staging ---
if [[ -f "scripts/sql/seed_staging_domain.sql" && "$HAS_PSQL_DB_URL" == "1" && $(has_cmd psql && echo yes || echo no) == "yes" ]]; then
  echo "-- Seeding tenant domain (optional): staging.ezcycleramp.com"
  psql "$SUPABASE_DB_URL" -v ON_ERROR_STOP=1 -f "scripts/sql/seed_staging_domain.sql" || true
else
  echo "-- No seed script run (either missing scripts/sql/seed_staging_domain.sql or no psql/SUPABASE_DB_URL)"
fi

# --- Optional: sync n8n workflows ---
if [[ -n "${N8N_BASE_URL:-}" && -n "${N8N_API_KEY:-}" ]]; then
  echo "-- Syncing n8n workflows"
  bash scripts/n8n_sync_workflows.sh
else
  echo "-- n8n env not set; skipping workflow sync"
fi

echo "Deploy complete."

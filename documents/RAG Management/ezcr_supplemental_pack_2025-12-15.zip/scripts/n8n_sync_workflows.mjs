// scripts/n8n_sync_workflows.mjs
// Helper to avoid jq. Node >= 18 recommended.
//
// Commands:
//  node scripts/n8n_sync_workflows.mjs readName <path-to-workflow.json>
//  node scripts/n8n_sync_workflows.mjs readActive <path-to-workflow.json>
//  node scripts/n8n_sync_workflows.mjs findIdByName <name> <path-to-list-response.json>

import fs from "node:fs";

const [,, cmd, ...args] = process.argv;

function readJson(path) {
  return JSON.parse(fs.readFileSync(path, "utf-8"));
}

if (cmd === "readName") {
  const wf = readJson(args[0]);
  process.stdout.write(String(wf.name ?? ""));
  process.exit(0);
}

if (cmd === "readActive") {
  const wf = readJson(args[0]);
  process.stdout.write(String(Boolean(wf.active)));
  process.exit(0);
}

if (cmd === "findIdByName") {
  const name = args[0];
  const listPath = args[1];
  const payload = readJson(listPath);

  // n8n list response may be:
  // - array of workflows
  // - { data: [...] }
  const arr = Array.isArray(payload) ? payload : (payload?.data ?? payload?.workflows ?? []);
  const found = arr.find((w) => w?.name === name);
  process.stdout.write(found?.id ? String(found.id) : "");
  process.exit(0);
}

if (cmd === "listNames") {
  const listPath = args[0];
  const payload = readJson(listPath);
  const arr = Array.isArray(payload) ? payload : (payload?.data ?? payload?.workflows ?? []);
  process.stdout.write(JSON.stringify(arr.map(w => ({id: w.id, name: w.name, active: w.active}))));
  process.exit(0);
}

console.error("Unknown command:", cmd);
process.exit(1);

#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

: "${N8N_BASE_URL:?N8N_BASE_URL is required}"
: "${N8N_API_KEY:?N8N_API_KEY is required}"

N8N_API_VERSION="${N8N_API_VERSION:-v1}"
N8N_API_KEY_HEADER="${N8N_API_KEY_HEADER:-X-N8N-API-KEY}"

bash "$SCRIPT_DIR/verify_n8n_api.sh"

list_url="${N8N_BASE_URL%/}/api/${N8N_API_VERSION}/workflows?limit=250"
list_tmp="$(mktemp)"
curl -sS -o "$list_tmp" \
  -H "${N8N_API_KEY_HEADER}: ${N8N_API_KEY}" \
  "$list_url"

workflows_dir="$REPO_ROOT/n8n/workflows"
shopt -s nullglob
files=("$workflows_dir"/*.json)
if [[ "${#files[@]}" -eq 0 ]]; then
  echo "No workflow JSON files found in $workflows_dir"
  rm -f "$list_tmp"
  exit 0
fi

for wf_file in "${files[@]}"; do
  name="$(node "$SCRIPT_DIR/n8n_sync_workflows.mjs" readName "$wf_file")"
  desired_active="$(node "$SCRIPT_DIR/n8n_sync_workflows.mjs" readActive "$wf_file")"
  if [[ -z "$name" ]]; then
    echo "Skipping workflow with no name: $wf_file" >&2
    continue
  fi

  existing_id="$(node "$SCRIPT_DIR/n8n_sync_workflows.mjs" findIdByName "$name" "$list_tmp")"

  if [[ -n "$existing_id" ]]; then
    echo "Updating workflow: $name (id=$existing_id)"
    url="${N8N_BASE_URL%/}/api/${N8N_API_VERSION}/workflows/${existing_id}"
    status="$(curl -sS -o /tmp/n8n_update_resp.json -w "%{http_code}" \
      -H "${N8N_API_KEY_HEADER}: ${N8N_API_KEY}" \
      -H "Content-Type: application/json" \
      -X PUT \
      --data-binary "@${wf_file}" \
      "$url" || true)"
    if [[ "$status" != "200" ]]; then
      echo "Update failed (status=$status) for $name" >&2
      cat /tmp/n8n_update_resp.json >&2 || true
      exit 1
    fi
  else
    echo "Creating workflow: $name"
    url="${N8N_BASE_URL%/}/api/${N8N_API_VERSION}/workflows"
    status="$(curl -sS -o /tmp/n8n_create_resp.json -w "%{http_code}" \
      -H "${N8N_API_KEY_HEADER}: ${N8N_API_KEY}" \
      -H "Content-Type: application/json" \
      -X POST \
      --data-binary "@${wf_file}" \
      "$url" || true)"
    if [[ "$status" != "201" && "$status" != "200" ]]; then
      echo "Create failed (status=$status) for $name" >&2
      cat /tmp/n8n_create_resp.json >&2 || true
      exit 1
    fi

    # refresh list to capture new id
    curl -sS -o "$list_tmp" \
      -H "${N8N_API_KEY_HEADER}: ${N8N_API_KEY}" \
      "$list_url"
    existing_id="$(node "$SCRIPT_DIR/n8n_sync_workflows.mjs" findIdByName "$name" "$list_tmp")"
  fi

  if [[ -z "$existing_id" ]]; then
    echo "Could not determine workflow id after create/update for: $name" >&2
    exit 1
  fi

  # Activate/deactivate to match desired state
  if [[ "$desired_active" == "true" ]]; then
    echo "Ensuring active: $name"
    url="${N8N_BASE_URL%/}/api/${N8N_API_VERSION}/workflows/${existing_id}/activate"
  else
    echo "Ensuring inactive: $name"
    url="${N8N_BASE_URL%/}/api/${N8N_API_VERSION}/workflows/${existing_id}/deactivate"
  fi

  status="$(curl -sS -o /tmp/n8n_toggle_resp.json -w "%{http_code}" \
    -H "${N8N_API_KEY_HEADER}: ${N8N_API_KEY}" \
    -X POST \
    "$url" || true)"
  if [[ "$status" != "200" ]]; then
    # Some n8n builds may return 204; accept it too
    if [[ "$status" != "204" ]]; then
      echo "Toggle failed (status=$status) for $name" >&2
      cat /tmp/n8n_toggle_resp.json >&2 || true
      exit 1
    fi
  fi
done

rm -f "$list_tmp"
echo "n8n workflows sync complete."

# Claude Code — File-ready citations + KB metadata (additive)

You are working in an existing Next.js + Supabase repo for a multi-tenant RAG assistant.

Goal:
- Keep current behavior unchanged.
- Make citations “file-ready” by adding optional fields:
  source_type, source_uri, doc_version, page_number, section
- Ensure DB returns these fields (RPC or direct select).
- Ensure /api/rag/query includes these fields in citations mapping (additive only).
- Do NOT remove/rename existing citation fields (especially `url`).

Instructions:
1) Apply the new migration already present:
   - supabase/migrations/20251215_0100_kb_file_ready_metadata.sql
2) Find match_kb_chunks (if present) and update it via a NEW migration to return the new fields.
   - Additive only.
3) Patch app/api/rag/query/route.ts (or equivalent) to include new fields in citations.
   - Keep `url` behavior for URL sources.
   - For file sources later, allow url=null but include source_uri.
4) Optional: add stub GET /api/kb/source route returning 501 for file sources (tenant-checked skeleton).
5) Update/ensure docs reference docs/citations-file-ready.md

Output:
- List all files changed and any new migration created.

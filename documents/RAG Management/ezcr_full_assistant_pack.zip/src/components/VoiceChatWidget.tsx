"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Msg = { role: "user" | "assistant"; content: string };

declare global {
  interface Window {
    webkitSpeechRecognition?: any;
    SpeechRecognition?: any;
  }
}

/**
 * Minimal voice-enabled chat input:
 * - Uses browser SpeechRecognition (when available) to transcribe -> sends to /api/chat
 * - Uses SpeechSynthesis to read assistant replies (optional toggle)
 *
 * This is NOT LiveKit. It's the quickest way to add voice to the *existing* chatbot UI.
 * If/when you switch to LiveKit Agents for full-duplex voice, keep /api/rag/query as the shared brain.
 */
export function VoiceChatWidget() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const [speakReplies, setSpeakReplies] = useState(false);
  const recRef = useRef<any>(null);

  const SpeechRecognition = useMemo(() => window.SpeechRecognition || window.webkitSpeechRecognition, []);

  useEffect(() => {
    if (!SpeechRecognition) return;

    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = "en-US";

    rec.onresult = (event: any) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setInput(transcript.trim());
    };

    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);

    recRef.current = rec;
  }, [SpeechRecognition]);

  async function sendMessage(text: string) {
    const msg = text.trim();
    if (!msg) return;

    setMessages((m) => [...m, { role: "user", content: msg }]);
    setInput("");

    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ message: msg, channel: "chat" }),
    });

    const data = await res.json();
    const reply = data?.answer?.text ?? "Sorry — I had trouble answering that.";

    setMessages((m) => [...m, { role: "assistant", content: reply }]);

    if (speakReplies && "speechSynthesis" in window) {
      const u = new SpeechSynthesisUtterance(reply);
      u.lang = "en-US";
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    }
  }

  function toggleListening() {
    if (!recRef.current) return;
    if (listening) {
      recRef.current.stop();
      setListening(false);
    } else {
      setListening(true);
      recRef.current.start();
    }
  }

  return (
    <div className="w-full max-w-xl space-y-3 rounded-xl border p-4">
      <div className="flex items-center justify-between">
        <div className="font-semibold">EZ Cycle Ramp Assistant</div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={speakReplies} onChange={(e) => setSpeakReplies(e.target.checked)} />
          Speak replies
        </label>
      </div>

      <div className="space-y-2">
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "text-right" : "text-left"}>
            <div className="inline-block rounded-lg bg-muted px-3 py-2 text-sm">
              {m.content}
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <button
          type="button"
          onClick={toggleListening}
          disabled={!SpeechRecognition}
          className="rounded-lg border px-3 py-2 text-sm"
          title={!SpeechRecognition ? "Speech recognition not supported in this browser" : "Speak"}
        >
          {listening ? "Stop" : "🎤 Talk"}
        </button>

        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about fitment, loading, warranty, shipping..."
          className="flex-1 rounded-lg border px-3 py-2 text-sm"
        />

        <button
          type="button"
          onClick={() => sendMessage(input)}
          className="rounded-lg bg-black px-4 py-2 text-sm text-white"
        >
          Send
        </button>
      </div>

      {!SpeechRecognition && (
        <div className="text-xs text-muted-foreground">
          Tip: For best voice support across browsers/devices, use LiveKit voice rooms + an agent. This widget is the
          “quick win” in-browser approach.
        </div>
      )}
    </div>
  );
}

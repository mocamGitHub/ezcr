import crypto from "node:crypto";

export function randomToken(bytes = 24) {
  return crypto.randomBytes(bytes).toString("hex");
}

export function sha256hex(text: string) {
  return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

import { supabaseAdmin } from "@/src/lib/supabase/admin";

/**
 * Resolve tenant_id from request host using `tenant_domains`.
 * - Works for multi-tenant domains and subdomains.
 * - For local dev, set `x-tenant-id` header to bypass.
 */
export async function resolveTenantId(req: Request): Promise<string> {
  const forced = req.headers.get("x-tenant-id");
  if (forced) return forced;

  const host = req.headers.get("host")?.toLowerCase();
  if (!host) throw new Error("Missing Host header");

  const sb = supabaseAdmin();
  const { data, error } = await sb
    .from("tenant_domains")
    .select("tenant_id")
    .eq("domain", host)
    .maybeSingle();

  if (error) throw new Error(`tenant_domains lookup failed: ${error.message}`);
  if (!data?.tenant_id) throw new Error(`No tenant mapped for host: ${host}`);

  return data.tenant_id as string;
}

export async function callTool<T>(params: {
  origin: string;
  path: string;
  tenant_id: string;
  bearerSecret?: string; // used for server-to-server protected tools
  body: any;
}): Promise<T> {
  const url = `${params.origin}${params.path}`;
  const headers: Record<string, string> = { "content-type": "application/json", "x-tenant-id": params.tenant_id };
  if (params.bearerSecret) headers["authorization"] = `Bearer ${params.bearerSecret}`;

  const res = await fetch(url, { method: "POST", headers, body: JSON.stringify(params.body) });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.error?.message || `Tool call failed ${res.status}`);
  return json as T;
}

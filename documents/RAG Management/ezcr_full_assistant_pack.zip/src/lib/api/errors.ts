import { NextResponse } from "next/server";

export function jsonError(trace_id: string, status: number, code: string, message: string, details?: any) {
  return NextResponse.json({ trace_id, error: { code, message, details } }, { status });
}

export function getBearerToken(req: Request) {
  const a = req.headers.get("authorization") || "";
  if (!a.toLowerCase().startsWith("bearer ")) return null;
  return a.slice(7).trim();
}

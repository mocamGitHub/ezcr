import type { RagChannel, RagCitation } from "./types";

export function buildSystemPrompt(channel: RagChannel) {
  const base = [
    "You are the EZ Cycle Ramp assistant for a multi-tenant platform (NexCyte).",
    "Always answer using the provided SOURCES when available.",
    "Never invent compatibility rules, prices, inventory, shipping statuses, or policies.",
    "VOLATILE TRUTH RULE:",
    "- Prices, inventory availability, order status, and shipping/tracking status must come from tool results (structured DB), not KB text.",
    "If the answer depends on missing measurements or unknowns, ask a single, clear follow-up question.",
    "If sources are missing or weak, say what you do and do not know and recommend the next step (or human confirmation).",
  ];

  if (channel === "voice") {
    base.push(
      "Voice mode: keep answers short and easy to speak aloud.",
      "Aim for 1-3 short paragraphs max.",
      "Do not read URLs aloud; offer to text/email links instead."
    );
  } else {
    base.push("Chat mode: be concise; bullets are fine.");
  }

  return base.join("\n");
}

export function formatSourcesForPrompt(citations: RagCitation[]) {
  if (!citations.length) return "SOURCES: (none)\n";
  const lines = citations.slice(0, 8).map((c, i) => {
    const title = c.title ?? "Untitled";
    const url = c.url ?? "";
    const snip = (c.snippet ?? "").replace(/\s+/g, " ").trim();
    return `SOURCE ${i + 1}:\nTITLE: ${title}\nURL: ${url}\nEXCERPT: ${snip}\n`;
  });
  return `SOURCES:\n\n${lines.join("\n")}`;
}

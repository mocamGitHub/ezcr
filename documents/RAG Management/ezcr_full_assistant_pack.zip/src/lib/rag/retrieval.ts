import type { RagCitation } from "./types";
import { supabaseAdmin } from "../supabase/admin";

export interface RetrievalParams {
  tenant_id: string;
  embedding: number[];
  top_k: number;
  min_score: number;
  doc_types?: string[];
  tags?: string[];
  url_prefix?: string;
}

export async function retrieveCitations(p: RetrievalParams): Promise<RagCitation[]> {
  const sb = supabaseAdmin();

  const { data, error } = await sb.rpc("match_kb_chunks", {
    p_tenant_id: p.tenant_id,
    p_query_embedding: p.embedding,
    p_match_count: p.top_k,
    p_min_score: p.min_score,
    p_doc_types: p.doc_types ?? null,
    p_tags: p.tags ?? null,
    p_url_prefix: p.url_prefix ?? null,
  });

  if (error) throw new Error(`match_kb_chunks failed: ${error.message}`);

  return (data ?? []).map((row: any) => ({
    source_id: row.source_id,
    title: row.title ?? undefined,
    url: row.url ?? undefined,
    doc_type: row.doc_type ?? undefined,
    snippet: row.snippet ?? undefined,
    score: typeof row.score === "number" ? row.score : undefined,
  }));
}

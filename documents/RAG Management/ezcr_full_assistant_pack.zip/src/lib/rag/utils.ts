export function clamp01(x: number) {
  if (Number.isNaN(x)) return 0;
  return Math.max(0, Math.min(1, x));
}

export function toSSML(text: string) {
  const escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  // Add small breaks after sentence endings.
  const withBreaks = escaped.replace(/([.!?])\s+/g, `$1 <break time="200ms"/> `);
  return `<speak>${withBreaks}</speak>`;
}

export function inferIntent(question: string) {
  const q = question.toLowerCase();
  if (/(fitment|will it fit|truck bed|tailgate|long bed|short bed|extension|ac004|4-beam)/.test(q)) return "fitment";
  if (/(warranty|guarantee|return|refund)/.test(q)) return "policy";
  if (/(shipping|delivery|freight|tracking)/.test(q)) return "shipping";
  if (/(price|cost|financing|payment)/.test(q)) return "pricing";
  if (/(install|installation|setup|how do i)/.test(q)) return "how_to";
  return "general";
}

export function buildActions(intent: string, page_url?: string) {
  const actions: any[] = [];
  if (intent === "fitment") {
    actions.push({ type: "START_CONFIGURATOR", label: "Check Fitment", payload: { step: "truck" } });
  }
  actions.push({ type: "CAPTURE_LEAD", label: "Text me links & updates", payload: { method: "sms" } });

  if (page_url) actions.push({ type: "OPEN_URL", label: "Open this page", payload: { url: page_url } });
  return actions;
}

export function computeConfidence(scores: number[]) {
  if (!scores.length) return { overall: 0.35, retrieval: 0, generation: 0.6, reason: "No KB sources matched yet." };
  const top = scores.slice(0, 6);
  const avg = top.reduce((a, b) => a + b, 0) / top.length;
  const retrieval = clamp01((avg - 0.6) / 0.4); // map 0.6..1.0 -> 0..1
  const overall = clamp01(0.45 + 0.55 * retrieval);
  return { overall, retrieval, generation: 0.8 };
}

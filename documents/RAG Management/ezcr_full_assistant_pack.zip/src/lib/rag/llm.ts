import { openaiClient } from "../openai/client";

export async function embedText(text: string): Promise<number[]> {
  const client = openaiClient();
  const model = process.env.OPENAI_EMBED_MODEL || "text-embedding-3-small";

  const res = await client.embeddings.create({
    model,
    input: text,
  });

  const v = res.data?.[0]?.embedding;
  if (!v || !Array.isArray(v)) throw new Error("Embedding failed");
  return v as number[];
}

export async function generateAnswer(params: {
  system: string;
  user: string;
  max_output_tokens?: number;
}): Promise<string> {
  const client = openaiClient();
  const model = process.env.OPENAI_CHAT_MODEL || "gpt-4.1-mini";

  const res = await client.chat.completions.create({
    model,
    messages: [
      { role: "system", content: params.system },
      { role: "user", content: params.user },
    ],
    temperature: 0.2,
    max_tokens: params.max_output_tokens ?? 350,
  });

  const text = res.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("LLM returned empty content");
  return text;
}

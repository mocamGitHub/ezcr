export type RagChannel = "chat" | "voice";
export type RagRole = "system" | "user" | "assistant" | "tool";

export interface RagMessage {
  role: RagRole;
  content: string;
  ts?: string;
  message_id?: string;
}

export interface RagRequest {
  tenant_id: string;         // uuid string
  channel: RagChannel;
  question: string;

  conversation?: {
    conversation_id?: string;
    messages?: RagMessage[];
    summary?: string;
  };

  user?: {
    user_id?: string;
    name?: string;
    email?: string;
    phone?: string;
  };

  customer?: {
    order_number?: string;
    lookup_token?: string;
    sku?: string;
    tracking_number?: string;
  };

  context?: {
    page_url?: string;
    locale?: string;
    timezone?: string;
    product_hint?: "AUN-210" | "AUN-250" | "ACCESSORY" | "UNKNOWN";
    fitment?: {
      truck_bed_length_in?: number;
      tailgate_must_close?: boolean;
      bike_weight_lb?: number;
    };
  };

  retrieval?: {
    enabled?: boolean;
    top_k?: number;
    min_score?: number;
    filters?: {
      doc_type?: ("web" | "pdf" | "faq" | "policy" | "manual" | "other")[];
      tags?: string[];
      url_prefix?: string;
    };
  };

  output?: {
    format?: "text" | "ssml";
    max_words?: number;
    include_citations?: boolean;
    include_actions?: boolean;
    include_debug?: boolean;
  };

  trace?: { request_id?: string };
}

export interface RagCitation {
  source_id: string;
  title?: string;
  url?: string;
  doc_type?: "web" | "pdf" | "faq" | "policy" | "manual" | "other";
  snippet?: string;
  score?: number;
}

export type RagActionType =
  | "OPEN_URL"
  | "START_CONFIGURATOR"
  | "CAPTURE_LEAD"
  | "HANDOFF_HUMAN"
  | "SEND_FOLLOWUP"
  | "SHOW_PRODUCTS";

export interface RagAction {
  type: RagActionType;
  label: string;
  payload?: Record<string, any>;
}

export interface RagConfidence {
  overall: number;      // 0..1
  retrieval?: number;   // 0..1
  generation?: number;  // 0..1
  reason?: string;
}

export interface RagResponse {
  trace_id: string;
  answer: { text: string; ssml?: string };
  confidence: RagConfidence;
  citations?: RagCitation[];
  actions?: RagAction[];
  followups?: string[];
  route?: {
    intent?: string;
    handoff_recommended?: boolean;
    handoff_reason?: string;
  };
  debug?: any;
}

export interface RagErrorResponse {
  trace_id: string;
  error: {
    code:
      | "BAD_REQUEST"
      | "UNAUTHORIZED"
      | "RATE_LIMITED"
      | "KB_NOT_READY"
      | "UPSTREAM_FAILURE"
      | "INTERNAL";
    message: string;
    details?: any;
  };
}

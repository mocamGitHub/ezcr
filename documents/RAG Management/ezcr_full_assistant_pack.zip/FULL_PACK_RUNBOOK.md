# EZ Cycle Ramp Full Assistant Pack
A single cohesive pack for:
- Multi-tenant KB RAG (Supabase pgvector)
- Multi-tenant customer data tools (orders/shipping/products/inventory)
- Website chat + website voice (browser STT/TTS)
- LiveKit voice later using the same `/api/rag/query` endpoint

## Apply Supabase migrations
Run these migrations in order (dates may match):
1) `supabase/migrations/20251215_kb_rag.sql`
2) `supabase/migrations/20251215_customer_data_tools.sql`

After ingesting KB data, run:
- `ANALYZE public.kb_chunks;`

## Next.js environment variables
Server-only:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `EZCR_RAG_SHARED_SECRET` (random long secret)

For customer portal (authenticated path):
- `SUPABASE_ANON_KEY` (used by SSR client + cookies for RLS)

For embeddings/LLM:
- `OPENAI_API_KEY`
- `OPENAI_EMBED_MODEL=text-embedding-3-small`
- `OPENAI_CHAT_MODEL=gpt-4.1-mini`

Optional:
- `EZCR_RAG_INTERNAL_URL` (override when calling /api/rag/query internally)

## Multi-tenancy: tenant resolution
- Add `tenant_domains` rows mapping your domain -> tenant_id.
- The server resolves tenant by `Host` header (or `x-tenant-id` for internal calls).

## Ingest the knowledge base
1) Install deps:
   - `npm i -D tsx`
   - `npm i @supabase/supabase-js cheerio openai`
2) Set env vars (see `scripts/ingest/.env.example`)
3) Run:
   - PowerShell: `./scripts/ingest/run_ingest.ps1`
   - Or: `npx tsx scripts/ingest/ingest_kb.ts`

## How the assistant answers “dynamic truth”
- Prices -> `/api/tools/product` (reads `products.price_current`)
- Inventory -> `/api/tools/inventory` (reads `inventory.available_qty`)
- Order status -> `/api/tools/order-status` (authenticated via RLS OR guest token)
- Shipping status -> `/api/tools/shipping-status`

The assistant uses KB RAG for explanations, not for volatile values.

## Website voice
- Use `src/components/VoiceChatWidget.tsx` as the “quick win” (browser STT/TTS).
- Later: replace/augment with LiveKit voice rooms; keep `/api/rag/query` as the shared brain.

## KB updates / “learning”
- Re-run ingestion nightly (cron) + on-demand when pages change.
- Log unanswered questions (low confidence / no citations), add docs, re-ingest.
See `docs/kb_updates_and_learning.md`.

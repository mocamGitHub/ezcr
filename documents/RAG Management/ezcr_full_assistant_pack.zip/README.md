# EZCR Customer Data Tools Pack (Multi-tenant)

This adds:
- Tenant domain mapping (`tenant_domains`)
- Customer / order / shipment / inventory / product tables
- Secure guest lookup tokens for order status without an account
- Next.js tool endpoints to fetch customer-specific data safely

## Apply migration
- `supabase/migrations/20251215_customer_data_tools.sql`

## Environment variables (Next.js)
Server-only:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `EZCR_RAG_SHARED_SECRET`  (same as your /api/rag/query Bearer secret)

Optional (if you want to resolve tenant automatically from host):
- none (we look up tenant_id in `tenant_domains`)

## Security model
Two supported access paths:

### A) Authenticated customer (best)
- customer logs in (Supabase Auth)
- RLS allows them to read their own orders/shipments/items
- tool endpoints use the user's JWT session

### B) Guest lookup token (no login)
- you generate a token for an order
- you send token link via email/SMS
- endpoint validates token_hash + expiry and returns limited order/shipping info

## Next steps
- Wire your `/api/rag/query` intent router to call these tool endpoints for:
  - "Where is my order?"
  - "What's my tracking?"
  - "Do you have this in stock?"
  - "What's the price now?"

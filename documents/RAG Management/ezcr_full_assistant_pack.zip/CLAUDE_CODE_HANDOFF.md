# Claude Code Handoff — EZ Cycle Ramp Full Assistant Pack

You are implementing a multi-tenant assistant for NexCyte with EZ Cycle Ramp as Tenant #1.

## Deliverables to verify
1) Supabase migrations applied successfully:
- KB RAG: kb_documents/kb_chunks + match_kb_chunks RPC
- Customer data tools schema: customers/orders/shipments/products/inventory + RLS templates
2) Next.js routes compile:
- /api/rag/query (Bearer-protected, resolves tenant by Host)
- /api/chat (public, calls /api/rag/query)
- /api/tools/* (order-status, shipping-status, inventory, product, order-lookup-token)
3) KB ingestion script runs and populates kb_* tables from sitemap.
4) Voice-enabled chat widget renders and can:
- send text messages
- optionally transcribe speech (when browser supports it)

## Commands
- Install deps (if missing):
  - npm i zod openai @supabase/supabase-js @supabase/ssr cheerio
  - npm i -D tsx
- Run ingestion:
  - npx tsx scripts/ingest/ingest_kb.ts

## Required environment variables
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY
- SUPABASE_ANON_KEY (for authenticated portal / RLS reads)
- OPENAI_API_KEY
- EZCR_RAG_SHARED_SECRET
- OPENAI_EMBED_MODEL=text-embedding-3-small
- OPENAI_CHAT_MODEL=gpt-4.1-mini

## Tenant setup
Insert mapping in `tenant_domains`:
- domain = your site host (e.g., ezcycleramp.com or staging.ezcycleramp.com)
- tenant_id = EZ Cycle Ramp tenant uuid

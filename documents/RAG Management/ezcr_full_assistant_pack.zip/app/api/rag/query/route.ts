import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { embedText, generateAnswer } from "@/src/lib/rag/llm";
import { retrieveCitations } from "@/src/lib/rag/retrieval";
import { buildSystemPrompt, formatSourcesForPrompt } from "@/src/lib/rag/prompt";
import { buildActions, computeConfidence, inferIntent, toSSML } from "@/src/lib/rag/utils";
import { resolveTenantId } from "@/src/lib/tenant/resolve";
import { callTool } from "@/src/lib/tools/call";
import type { RagResponse } from "@/src/lib/rag/types";

export const runtime = "nodejs";

const RagSchema = z.object({
  tenant_id: z.string().optional(), // optional; can be resolved by host/x-tenant-id
  channel: z.enum(["chat", "voice"]),
  question: z.string().min(1),

  customer: z
    .object({
      order_number: z.string().optional(),
      lookup_token: z.string().optional(),
      sku: z.string().optional(),
      tracking_number: z.string().optional(),
    })
    .optional(),

  conversation: z
    .object({
      conversation_id: z.string().optional(),
      messages: z.array(z.object({ role: z.string(), content: z.string() })).optional(),
      summary: z.string().optional(),
    })
    .optional(),

  context: z
    .object({
      page_url: z.string().optional(),
      locale: z.string().optional(),
      timezone: z.string().optional(),
      product_hint: z.enum(["AUN-210", "AUN-250", "ACCESSORY", "UNKNOWN"]).optional(),
      fitment: z
        .object({
          truck_bed_length_in: z.number().optional(),
          tailgate_must_close: z.boolean().optional(),
          bike_weight_lb: z.number().optional(),
        })
        .optional(),
    })
    .optional(),

  retrieval: z
    .object({
      enabled: z.boolean().optional(),
      top_k: z.number().int().min(1).max(12).optional(),
      min_score: z.number().min(0).max(1).optional(),
      filters: z
        .object({
          doc_type: z.array(z.enum(["web", "pdf", "faq", "policy", "manual", "other"])).optional(),
          tags: z.array(z.string()).optional(),
          url_prefix: z.string().optional(),
        })
        .optional(),
    })
    .optional(),

  output: z
    .object({
      format: z.enum(["text", "ssml"]).optional(),
      max_words: z.number().int().min(30).max(600).optional(),
      include_citations: z.boolean().optional(),
      include_actions: z.boolean().optional(),
      include_debug: z.boolean().optional(),
    })
    .optional(),

  trace: z.object({ request_id: z.string().optional() }).optional(),
});

function jsonError(trace_id: string, status: number, code: string, message: string, details?: any) {
  return NextResponse.json({ trace_id, error: { code, message, details } }, { status });
}

export async function POST(req: NextRequest) {
  const trace_id = crypto.randomUUID();

  // Server-to-server protection (this is your shared "brain" endpoint)
  const secret = process.env.EZCR_RAG_SHARED_SECRET;
  if (!secret) return jsonError(trace_id, 500, "INTERNAL", "Server missing EZCR_RAG_SHARED_SECRET.");

  const auth = req.headers.get("authorization") || "";
  const ok = auth.toLowerCase().startsWith("bearer ") && auth.slice(7).trim() === secret;
  if (!ok) return jsonError(trace_id, 401, "UNAUTHORIZED", "Missing or invalid Authorization token.");

  let body: z.infer<typeof RagSchema>;
  try {
    body = RagSchema.parse(await req.json());
  } catch (e: any) {
    return jsonError(trace_id, 400, "BAD_REQUEST", "Invalid request body.", e?.errors ?? String(e));
  }

  // Resolve tenant
  const tenant_id = body.tenant_id || req.headers.get("x-tenant-id") || (await resolveTenantId(req));
  const channel = body.channel;
  const question = body.question.trim();

  const retrievalEnabled = body.retrieval?.enabled ?? true;
  const top_k = body.retrieval?.top_k ?? 6;
  const min_score = body.retrieval?.min_score ?? 0.75;
  const include_citations = body.output?.include_citations ?? true;
  const include_actions = body.output?.include_actions ?? true;
  const include_debug = body.output?.include_debug ?? false;
  const format = body.output?.format ?? (channel === "voice" ? "ssml" : "text");
  const max_words = body.output?.max_words ?? (channel === "voice" ? 120 : 250);

  const intent = inferIntent(question);

  // ---------- Tool routing for volatile/structured data ----------
  const origin = req.nextUrl.origin;
  const customer = body.customer || {};
  const likelyOrder = /(where is my order|order status|my order|track my order)/i.test(question);
  const likelyShipping = /(tracking|shipment|shipping status|where is my package)/i.test(question);
  const likelyInventory = /(in stock|available|inventory|lead time)/i.test(question);
  const likelyPrice = /(price|cost|how much|msrp)/i.test(question);

  // Small helper to infer SKU from text when possible
  function inferSku(q: string): string | undefined {
    const m = q.match(/\b(AUN[-\s]?250|AUN[-\s]?210|AUN[-\s]?200)\b/i);
    if (m) return m[1].toUpperCase().replace(/\s/g, "");
    return customer.sku;
  }

  let toolResult: any = null;
  let toolUsed: string | null = null;

  try {
    if (likelyOrder) {
      // Need order_number (+ lookup_token if guest)
      if (!customer.order_number) {
        toolUsed = "order-status";
        toolResult = { need: ["order_number", "lookup_token(optional if signed in)"] };
      } else {
        toolUsed = "order-status";
        toolResult = await callTool({
          origin,
          path: "/api/tools/order-status",
          tenant_id,
          body: { order_number: customer.order_number, lookup_token: customer.lookup_token },
        });
      }
    } else if (likelyShipping) {
      toolUsed = "shipping-status";
      toolResult = await callTool({
        origin,
        path: "/api/tools/shipping-status",
        tenant_id,
        body: { tracking_number: customer.tracking_number, order_number: customer.order_number, lookup_token: customer.lookup_token },
      });
    } else if (likelyInventory) {
      const sku = inferSku(question);
      if (!sku) {
        toolUsed = "inventory";
        toolResult = { need: ["sku (e.g., AUN-250 or AUN-210)"] };
      } else {
        toolUsed = "inventory";
        toolResult = await callTool({ origin, path: "/api/tools/inventory", tenant_id, body: { sku } });
      }
    } else if (likelyPrice) {
      const sku = inferSku(question);
      if (!sku) {
        toolUsed = "product";
        toolResult = { need: ["sku (e.g., AUN-250 or AUN-210)"] };
      } else {
        toolUsed = "product";
        toolResult = await callTool({ origin, path: "/api/tools/product", tenant_id, body: { sku } });
      }
    }
  } catch (e: any) {
    // Tool failures should not brick the assistant; we'll explain and proceed with KB if possible.
    toolResult = { error: String(e?.message ?? e) };
  }

  // ---------- KB RAG retrieval ----------
  let citations: any[] = [];
  let embedding: number[] | null = null;

  // For tool-driven intents, we still retrieve KB for explanation (policies/how-to), but we don't use it for volatile truth.
  try {
    embedding = await embedText(question);
    if (retrievalEnabled) {
      citations = await retrieveCitations({
        tenant_id,
        embedding,
        top_k,
        min_score,
        doc_types: body.retrieval?.filters?.doc_type,
        tags: body.retrieval?.filters?.tags,
        url_prefix: body.retrieval?.filters?.url_prefix,
      });
    }
  } catch {
    citations = [];
  }

  const scores = citations.map((c) => (typeof c.score === "number" ? c.score : 0)).filter((n) => n > 0);
  const confidence = computeConfidence(scores);

  const system = buildSystemPrompt(channel);
  const sources = formatSourcesForPrompt(citations);

  // Tool summary for the model
  const toolBlock =
    toolUsed
      ? `\n\nTOOL_USED: ${toolUsed}\nTOOL_RESULT(JSON):\n${JSON.stringify(toolResult).slice(0, 6000)}\n`
      : "\n\nTOOL_USED: none\n";

  const userPrompt =
    `User question:\n${question}\n\n` +
    `Constraints:\n- Keep under ~${max_words} words.\n` +
    `- If the answer depends on missing measurements or unknowns, ask ONE follow-up.\n` +
    `- For prices/inventory/order/shipping status, prefer TOOL_RESULT.\n` +
    toolBlock +
    `\n` +
    sources;

  let answerText = "";
  try {
    answerText = await generateAnswer({
      system,
      user: userPrompt,
      max_output_tokens: channel === "voice" ? 240 : 420,
    });
  } catch (e: any) {
    return jsonError(trace_id, 502, "UPSTREAM_FAILURE", "Chat model failed.", String(e));
  }

  // If tool indicates missing inputs, make sure we ask for them cleanly.
  if (toolResult?.need?.length) {
    const needs = toolResult.need.join(", ");
    const add = channel === "voice"
      ? ` I just need ${needs}.`
      : `\n\nTo look that up, I need: **${needs}**.`;
    if (!answerText.toLowerCase().includes("i need")) answerText = answerText.trim() + add;
  }

  const handoffRecommended =
    intent === "fitment" && citations.length === 0
      ? true
      : confidence.overall < 0.5 && /compatible|exact|guarantee/i.test(question);

  const resp: RagResponse = {
    trace_id,
    answer: {
      text: answerText,
      ...(format === "ssml" ? { ssml: toSSML(answerText) } : {}),
    },
    confidence,
    ...(include_citations ? { citations } : {}),
    ...(include_actions ? { actions: buildActions(intent, body.context?.page_url) } : {}),
    followups:
      likelyOrder
        ? ["What is your order number?", "If you checked out as a guest, do you have the lookup link/token from your confirmation message?"]
        : intent === "fitment"
          ? ["What is your truck bed length (inches)?", "Does the tailgate need to close while the bike is loaded?"]
          : ["Would you like links to the relevant page(s)?"],
    route: {
      intent,
      handoff_recommended: handoffRecommended,
      handoff_reason: handoffRecommended ? "KB sources missing for precision confirmation." : undefined,
    },
    ...(include_debug
      ? { debug: { tenant_id, toolUsed, toolResult, retrievalEnabled, top_k, min_score, scores, citations_count: citations.length } }
      : {}),
  };

  return NextResponse.json(resp, { status: 200 });
}

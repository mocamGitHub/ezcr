import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { resolveTenantId } from "@/src/lib/tenant/resolve";

export const runtime = "nodejs";

// Public endpoint for your website chat/voice UI.
// It calls /api/rag/query server-to-server so the client never sees EZCR_RAG_SHARED_SECRET.

const ChatSchema = z.object({
  message: z.string().min(1),
  channel: z.enum(["chat", "voice"]).optional(),
  conversation_id: z.string().optional(),
  page_url: z.string().optional(),
  // Optional structured context captured in your UI:
  order_number: z.string().optional(),
  lookup_token: z.string().optional(),
  sku: z.string().optional(),
  tracking_number: z.string().optional(),
});

export async function POST(req: NextRequest) {
  const trace_id = crypto.randomUUID();

  let body: z.infer<typeof ChatSchema>;
  try {
    body = ChatSchema.parse(await req.json());
  } catch (e: any) {
    return NextResponse.json(
      { trace_id, error: { code: "BAD_REQUEST", message: "Invalid request body.", details: e?.errors ?? String(e) } },
      { status: 400 }
    );
  }

  const secret = process.env.EZCR_RAG_SHARED_SECRET;
  if (!secret) {
    return NextResponse.json(
      { trace_id, error: { code: "INTERNAL", message: "Missing EZCR_RAG_SHARED_SECRET on server." } },
      { status: 500 }
    );
  }

  const tenant_id = await resolveTenantId(req);

  const ragUrl = process.env.EZCR_RAG_INTERNAL_URL || `${req.nextUrl.origin}/api/rag/query`;

  const res = await fetch(ragUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${secret}`,
      "x-tenant-id": tenant_id,
    },
    body: JSON.stringify({
      // tenant_id optional in /api/rag/query; we pass it anyway
      tenant_id,
      channel: body.channel ?? "chat",
      question: body.message,
      context: { page_url: body.page_url },
      customer: {
        order_number: body.order_number,
        lookup_token: body.lookup_token,
        sku: body.sku,
        tracking_number: body.tracking_number,
      },
      retrieval: { enabled: true, top_k: 6, min_score: 0.75 },
      output: {
        format: (body.channel ?? "chat") === "voice" ? "ssml" : "text",
        include_citations: true,
        include_actions: true
      },
    }),
  });

  const json = await res.json();
  return NextResponse.json(json, { status: res.status });
}

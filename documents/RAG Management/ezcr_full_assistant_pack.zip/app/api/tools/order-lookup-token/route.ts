import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin } from "@/src/lib/supabase/admin";
import { resolveTenantId } from "@/src/lib/tenant/resolve";
import { jsonError } from "@/src/lib/api/errors";
import { randomToken, sha256hex } from "@/src/lib/security/tokens";

export const runtime = "nodejs";

/**
 * Creates a guest order lookup token.
 * You would typically call this after order creation and then email/SMS the token link.
 */
const Body = z.object({
  order_number: z.string().min(1),
  expires_in_hours: z.number().int().min(1).max(720).optional(), // default 168 (7 days)
});

export async function POST(req: Request) {
  const trace_id = crypto.randomUUID();

  // Protect with shared secret (server-to-server only)
  const secret = process.env.EZCR_RAG_SHARED_SECRET;
  const auth = req.headers.get("authorization") || "";
  const ok = secret && auth.toLowerCase().startsWith("bearer ") && auth.slice(7).trim() === secret;
  if (!ok) return jsonError(trace_id, 401, "UNAUTHORIZED", "Missing or invalid Authorization token");

  let body: z.infer<typeof Body>;
  try {
    body = Body.parse(await req.json());
  } catch (e: any) {
    return jsonError(trace_id, 400, "BAD_REQUEST", "Invalid body", e?.errors ?? String(e));
  }

  const tenant_id = await resolveTenantId(req);
  const admin = supabaseAdmin();

  const { data: order, error: ordErr } = await admin
    .from("orders")
    .select("id")
    .eq("tenant_id", tenant_id)
    .eq("order_number", body.order_number)
    .maybeSingle();

  if (ordErr) return jsonError(trace_id, 500, "INTERNAL", "Order lookup failed", ordErr);
  if (!order) return jsonError(trace_id, 404, "NOT_FOUND", "Order not found");

  const token = randomToken(24);
  const token_hash = sha256hex(token);
  const hours = body.expires_in_hours ?? 168;
  const expires_at = new Date(Date.now() + hours * 3600 * 1000).toISOString();

  const { error: insErr } = await admin.from("order_lookup_tokens").insert({
    tenant_id,
    order_id: order.id,
    token_hash,
    expires_at,
  });

  if (insErr) return jsonError(trace_id, 500, "INTERNAL", "Token insert failed", insErr);

  // You return the raw token only here (to be sent via SMS/email). Never store raw token.
  return NextResponse.json({ trace_id, tenant_id, order_number: body.order_number, token, expires_at });
}

import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseServer } from "@/src/lib/supabase/server";
import { supabaseAdmin } from "@/src/lib/supabase/admin";
import { resolveTenantId } from "@/src/lib/tenant/resolve";
import { jsonError } from "@/src/lib/api/errors";
import { sha256hex } from "@/src/lib/security/tokens";

export const runtime = "nodejs";

const Body = z.object({
  tracking_number: z.string().min(3).optional(),
  order_number: z.string().min(1).optional(),
  lookup_token: z.string().min(10).optional(),
});

export async function POST(req: Request) {
  const trace_id = crypto.randomUUID();
  let body: z.infer<typeof Body>;
  try {
    body = Body.parse(await req.json());
  } catch (e: any) {
    return jsonError(trace_id, 400, "BAD_REQUEST", "Invalid body", e?.errors ?? String(e));
  }

  const tenant_id = await resolveTenantId(req);

  // Authenticated path via RLS
  const sb = supabaseServer();
  const { data: auth } = await sb.auth.getUser();

  if (auth?.user) {
    if (!body.tracking_number && !body.order_number) {
      return jsonError(trace_id, 400, "BAD_REQUEST", "Provide tracking_number or order_number");
    }

    if (body.tracking_number) {
      const { data, error } = await sb
        .from("shipments")
        .select("carrier, tracking_number, status, last_event, last_event_at, order_id")
        .eq("tenant_id", tenant_id)
        .eq("tracking_number", body.tracking_number);
      if (error) return jsonError(trace_id, 500, "INTERNAL", "Shipment lookup failed", error);
      return NextResponse.json({ trace_id, tenant_id, shipments: data ?? [] });
    }

    const { data: order, error: oerr } = await sb
      .from("orders")
      .select("id")
      .eq("tenant_id", tenant_id)
      .eq("order_number", body.order_number!)
      .maybeSingle();

    if (oerr) return jsonError(trace_id, 500, "INTERNAL", "Order lookup failed", oerr);
    if (!order) return jsonError(trace_id, 404, "NOT_FOUND", "Order not found");

    const { data: shipments, error: serr } = await sb
      .from("shipments")
      .select("carrier, tracking_number, status, last_event, last_event_at")
      .eq("tenant_id", tenant_id)
      .eq("order_id", order.id);

    if (serr) return jsonError(trace_id, 500, "INTERNAL", "Shipment lookup failed", serr);
    return NextResponse.json({ trace_id, tenant_id, shipments: shipments ?? [] });
  }

  // Guest token path
  if (!body.lookup_token || !body.order_number) {
    return jsonError(trace_id, 401, "UNAUTHORIZED", "Provide order_number + lookup_token, or sign in.");
  }

  const admin = supabaseAdmin();
  const token_hash = sha256hex(body.lookup_token);

  const { data: order, error: ordErr } = await admin
    .from("orders")
    .select("id")
    .eq("tenant_id", tenant_id)
    .eq("order_number", body.order_number)
    .maybeSingle();

  if (ordErr) return jsonError(trace_id, 500, "INTERNAL", "Order lookup failed", ordErr);
  if (!order) return jsonError(trace_id, 404, "NOT_FOUND", "Order not found");

  const { data: tok } = await admin
    .from("order_lookup_tokens")
    .select("id, expires_at")
    .eq("tenant_id", tenant_id)
    .eq("order_id", order.id)
    .eq("token_hash", token_hash)
    .maybeSingle();

  if (!tok) return jsonError(trace_id, 401, "UNAUTHORIZED", "Invalid token");
  if (new Date(tok.expires_at).getTime() < Date.now()) return jsonError(trace_id, 401, "UNAUTHORIZED", "Token expired");

  const { data: shipments } = await admin
    .from("shipments")
    .select("carrier, tracking_number, status, last_event, last_event_at")
    .eq("tenant_id", tenant_id)
    .eq("order_id", order.id);

  return NextResponse.json({ trace_id, tenant_id, shipments: shipments ?? [] });
}

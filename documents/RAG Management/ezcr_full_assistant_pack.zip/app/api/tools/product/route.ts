import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin } from "@/src/lib/supabase/admin";
import { resolveTenantId } from "@/src/lib/tenant/resolve";
import { jsonError } from "@/src/lib/api/errors";

export const runtime = "nodejs";

const Body = z.object({
  sku: z.string().min(1),
});

export async function POST(req: Request) {
  const trace_id = crypto.randomUUID();
  let body: z.infer<typeof Body>;
  try {
    body = Body.parse(await req.json());
  } catch (e: any) {
    return jsonError(trace_id, 400, "BAD_REQUEST", "Invalid body", e?.errors ?? String(e));
  }

  const tenant_id = await resolveTenantId(req);
  const admin = supabaseAdmin();

  const { data, error } = await admin
    .from("products")
    .select("sku, name, description, status, currency, price_current, msrp, updated_at")
    .eq("tenant_id", tenant_id)
    .eq("sku", body.sku)
    .maybeSingle();

  if (error) return jsonError(trace_id, 500, "INTERNAL", "Product lookup failed", error);
  if (!data) return jsonError(trace_id, 404, "NOT_FOUND", "SKU not found");

  return NextResponse.json({ trace_id, tenant_id, product: data });
}

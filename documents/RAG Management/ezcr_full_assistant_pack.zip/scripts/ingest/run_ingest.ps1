# Run ingestion (Windows PowerShell)
# Usage:
#   ./scripts/ingest/run_ingest.ps1

if (-not $env:SUPABASE_URL) { throw "Missing SUPABASE_URL" }
if (-not $env:SUPABASE_SERVICE_ROLE_KEY) { throw "Missing SUPABASE_SERVICE_ROLE_KEY" }
if (-not $env:OPENAI_API_KEY) { throw "Missing OPENAI_API_KEY" }
if (-not $env:TENANT_ID) { throw "Missing TENANT_ID" }
if (-not $env:KB_SITEMAP_URL) { throw "Missing KB_SITEMAP_URL" }

npx tsx scripts/ingest/ingest_kb.ts

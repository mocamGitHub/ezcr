# EZ Cycle Ramp KB Ingestion Pack (Multi-tenant)

This pack ingests your public docs (starting with sitemap URLs) into the Supabase KB tables:

- `kb_documents`
- `kb_chunks` (with `embedding`)

It is **tenant-aware**: every write is scoped to `TENANT_ID`.

## What it does
1) Fetch sitemap XML (or a URL list)
2) Fetch each page
3) Extract readable text from HTML
4) Chunk (target ~800–1200 chars)
5) Embed each chunk (OpenAI embeddings)
6) Upsert `kb_documents` and replace `kb_chunks` for the doc

## Requirements
- Node 18+
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `OPENAI_API_KEY`
- `TENANT_ID` (uuid string)
- Optional:
  - `KB_SITEMAP_URL` (e.g., https://ezcycleramp.com/sitemap.xml)
  - `KB_URL_PREFIX_FILTER` (only ingest URLs starting with this)

## Install deps
From your Next.js project root (or any Node project folder):

```bash
npm i -D tsx
npm i @supabase/supabase-js cheerio
npm i openai
```

## Run (Windows PowerShell)
```powershell
$env:SUPABASE_URL="..."
$env:SUPABASE_SERVICE_ROLE_KEY="..."
$env:OPENAI_API_KEY="..."
$env:TENANT_ID="..."
$env:KB_SITEMAP_URL="https://ezcycleramp.com/sitemap.xml"
npx tsx scripts/ingest/ingest_kb.ts
```

## Notes
- This script stores `source_hash` on `kb_documents` (sha256 of extracted text). If unchanged, it skips re-embedding.
- For PDFs: keep them as sources in `kb_documents` with doc_type="pdf", then add a PDF text extractor later (recommended in a separate step).

import { load } from "cheerio";

/**
 * Extract readable text:
 * - remove nav/footer/script/style
 * - prioritize main/article if present
 */
export function extractTextFromHtml(html: string): { title?: string; text: string } {
  const $ = load(html);

  $("script, style, noscript, svg, canvas, nav, footer, header, form, iframe").remove();

  const title = $("title").first().text().trim() || undefined;

  const main =
    $("main").first().text().trim() ||
    $("article").first().text().trim() ||
    $("#__next").first().text().trim() ||
    $("body").text().trim();

  const text = main.replace(/\s+/g, " ").trim();
  return { title, text };
}

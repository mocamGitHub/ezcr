import crypto from "node:crypto";

export function sha256(text: string) {
  return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

export function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

/** Very simple chunker (chars-based). Good enough to start; you can switch to token-based later. */
export function chunkText(text: string, maxChars = 1100, overlapChars = 150): string[] {
  const t = text.replace(/\s+/g, " ").trim();
  if (!t) return [];
  const chunks: string[] = [];
  let i = 0;
  while (i < t.length) {
    const end = Math.min(t.length, i + maxChars);
    const chunk = t.slice(i, end).trim();
    if (chunk.length > 0) chunks.push(chunk);
    if (end >= t.length) break;
    i = Math.max(0, end - overlapChars);
  }
  return chunks;
}

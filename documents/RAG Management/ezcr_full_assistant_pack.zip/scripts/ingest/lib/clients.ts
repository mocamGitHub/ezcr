import OpenAI from "openai";
import { createClient } from "@supabase/supabase-js";

export function getSupabaseAdmin() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  return createClient(url, key, { auth: { persistSession: false } });
}

export function getOpenAI() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("Missing OPENAI_API_KEY");
  return new OpenAI({ apiKey: key });
}

export async function embed(text: string): Promise<number[]> {
  const client = getOpenAI();
  const model = process.env.OPENAI_EMBED_MODEL || "text-embedding-3-small";
  const res = await client.embeddings.create({ model, input: text });
  const v = res.data?.[0]?.embedding;
  if (!v) throw new Error("No embedding returned");
  return v as number[];
}

import { load } from "cheerio";

/**
 * Supports:
 * - standard sitemapindex -> nested sitemaps
 * - urlset -> urls
 */
export async function fetchSitemapUrls(sitemapUrl: string): Promise<string[]> {
  const xml = await fetchText(sitemapUrl);
  const $ = load(xml, { xmlMode: true });

  const sitemapLocs = $("sitemapindex sitemap loc")
    .toArray()
    .map((el) => $(el).text().trim())
    .filter(Boolean);

  if (sitemapLocs.length) {
    const nested = await Promise.all(sitemapLocs.map((u) => fetchSitemapUrls(u)));
    return [...new Set(nested.flat())];
  }

  const urls = $("urlset url loc")
    .toArray()
    .map((el) => $(el).text().trim())
    .filter(Boolean);

  return [...new Set(urls)];
}

async function fetchText(url: string): Promise<string> {
  const res = await fetch(url, { headers: { "user-agent": "EZCR-KB-Ingest/1.0" } });
  if (!res.ok) throw new Error(`Fetch failed ${res.status} for ${url}`);
  return await res.text();
}

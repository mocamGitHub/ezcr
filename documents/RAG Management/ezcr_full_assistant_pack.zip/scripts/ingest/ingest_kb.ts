import { fetchSitemapUrls } from "./lib/sitemap";
import { extractTextFromHtml } from "./lib/html";
import { chunkText, sha256, sleep } from "./lib/utils";
import { embed, getSupabaseAdmin } from "./lib/clients";

type DocType = "web" | "pdf" | "faq" | "policy" | "manual" | "other";

function mustEnv(name: string) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env ${name}`);
  return v;
}

const TENANT_ID = mustEnv("TENANT_ID");
const SITEMAP_URL = process.env.KB_SITEMAP_URL || "";
const URL_PREFIX = process.env.KB_URL_PREFIX_FILTER || "";
const TOP_N = parseInt(process.env.TOP_N || "0", 10) || 0;

const CHUNK_MAX = parseInt(process.env.CHUNK_MAX_CHARS || "1100", 10);
const CHUNK_OVERLAP = parseInt(process.env.CHUNK_OVERLAP_CHARS || "150", 10);

const RATE_SLEEP_MS = parseInt(process.env.RATE_SLEEP_MS || "120", 10); // simple throttle

async function upsertDocument(params: {
  tenant_id: string;
  doc_type: DocType;
  title?: string;
  source_url: string;
  source_hash: string;
  tags?: string[];
}) {
  const sb = getSupabaseAdmin();

  // Idempotent upsert by (tenant_id, source_url) pattern:
  // We don't have a unique constraint in the migration for source_url, so we do select->update/insert.
  const { data: existing, error: selErr } = await sb
    .from("kb_documents")
    .select("id, source_hash")
    .eq("tenant_id", params.tenant_id)
    .eq("source_url", params.source_url)
    .maybeSingle();

  if (selErr) throw new Error(`Select kb_documents failed: ${selErr.message}`);

  if (existing?.id) {
    // unchanged?
    if (existing.source_hash === params.source_hash) {
      return { document_id: existing.id as string, unchanged: true };
    }
    const { error: upErr } = await sb
      .from("kb_documents")
      .update({
        doc_type: params.doc_type,
        title: params.title,
        source_hash: params.source_hash,
        tags: params.tags ?? [],
        status: "active",
      })
      .eq("id", existing.id);

    if (upErr) throw new Error(`Update kb_documents failed: ${upErr.message}`);
    return { document_id: existing.id as string, unchanged: false };
  }

  const { data: ins, error: insErr } = await sb
    .from("kb_documents")
    .insert({
      tenant_id: params.tenant_id,
      doc_type: params.doc_type,
      title: params.title,
      source_url: params.source_url,
      source_hash: params.source_hash,
      tags: params.tags ?? [],
      status: "active",
    })
    .select("id")
    .single();

  if (insErr) throw new Error(`Insert kb_documents failed: ${insErr.message}`);
  return { document_id: ins.id as string, unchanged: false };
}

async function replaceChunks(params: {
  tenant_id: string;
  document_id: string;
  source_url: string;
  title?: string;
  chunks: string[];
}) {
  const sb = getSupabaseAdmin();

  // delete existing chunks
  const { error: delErr } = await sb
    .from("kb_chunks")
    .delete()
    .eq("tenant_id", params.tenant_id)
    .eq("document_id", params.document_id);

  if (delErr) throw new Error(`Delete kb_chunks failed: ${delErr.message}`);

  // insert new chunks in batches
  const batchSize = 20;
  for (let i = 0; i < params.chunks.length; i += batchSize) {
    const slice = params.chunks.slice(i, i + batchSize);

    const rows = [];
    for (let j = 0; j < slice.length; j++) {
      const idx = i + j;
      const content = slice[j];

      // embedding call (throttled)
      const embedding = await embed(content);
      await sleep(RATE_SLEEP_MS);

      rows.push({
        tenant_id: params.tenant_id,
        document_id: params.document_id,
        chunk_index: idx,
        content,
        content_tokens: null,
        heading: null,
        source_url: params.source_url,
        tags: [],
        embedding,
      });
    }

    const { error: insErr } = await sb.from("kb_chunks").insert(rows);
    if (insErr) throw new Error(`Insert kb_chunks failed: ${insErr.message}`);
  }
}

async function ingestUrl(url: string) {
  const res = await fetch(url, { headers: { "user-agent": "EZCR-KB-Ingest/1.0" } });
  if (!res.ok) throw new Error(`Fetch failed ${res.status} ${url}`);
  const html = await res.text();

  const { title, text } = extractTextFromHtml(html);
  if (!text || text.length < 200) return { url, skipped: true, reason: "too_short" as const };

  const hash = sha256(text);
  const { document_id, unchanged } = await upsertDocument({
    tenant_id: TENANT_ID,
    doc_type: "web",
    title,
    source_url: url,
    source_hash: hash,
    tags: [],
  });

  if (unchanged) return { url, skipped: true, reason: "unchanged" as const };

  const chunks = chunkText(text, CHUNK_MAX, CHUNK_OVERLAP);
  await replaceChunks({ tenant_id: TENANT_ID, document_id, source_url: url, title, chunks });

  return { url, skipped: false, chunks: chunks.length };
}

export async function main() {
  if (!SITEMAP_URL) throw new Error("KB_SITEMAP_URL not set");

  let urls = await fetchSitemapUrls(SITEMAP_URL);
  if (URL_PREFIX) urls = urls.filter((u) => u.startsWith(URL_PREFIX));
  if (TOP_N > 0) urls = urls.slice(0, TOP_N);

  console.log(`Found ${urls.length} URLs from sitemap.`);
  let ok = 0, skip = 0, fail = 0;

  for (const url of urls) {
    try {
      const r = await ingestUrl(url);
      if (r.skipped) {
        skip++;
        console.log(`SKIP: ${url} (${r.reason})`);
      } else {
        ok++;
        console.log(`OK:   ${url} (chunks=${r.chunks})`);
      }
      await sleep(60);
    } catch (e: any) {
      fail++;
      console.error(`FAIL: ${url} -> ${e?.message ?? String(e)}`);
      await sleep(150);
    }
  }

  console.log(`Done. ok=${ok} skipped=${skip} failed=${fail}`);
}

if (require.main === module) {
  main().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}

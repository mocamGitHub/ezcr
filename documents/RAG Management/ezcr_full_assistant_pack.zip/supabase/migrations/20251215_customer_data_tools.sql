-- Customer data foundation (multi-tenant) + secure lookup tokens + basic RLS templates
-- NOTE: These tables are intentionally generic so you can map from Shopify/Woo/etc later.
-- If you already have ecom tables, adapt the views/tool queries accordingly.

create extension if not exists pgcrypto;

-- Tenant domain mapping (server resolves tenant_id from Host header)
create table if not exists public.tenant_domains (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  domain text not null,
  is_primary boolean not null default false,
  created_at timestamptz not null default now(),
  unique (domain)
);

create index if not exists tenant_domains_tenant_idx on public.tenant_domains (tenant_id);

-- Customers (link to Supabase Auth user if they have an account)
create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  auth_user_id uuid,            -- nullable (guest checkout)
  email text,
  phone text,
  name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, email)
);

create index if not exists customers_tenant_idx on public.customers (tenant_id);
create index if not exists customers_auth_user_idx on public.customers (auth_user_id);

-- Products (structured truth for prices/specs; do NOT rely on KB for changing prices)
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  sku text not null,
  name text not null,
  description text,
  status text not null default 'active' check (status in ('active','inactive')),
  currency text not null default 'USD',
  price_current numeric(12,2),        -- current sale price
  msrp numeric(12,2),
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (tenant_id, sku)
);

create index if not exists products_tenant_idx on public.products (tenant_id);

-- Inventory (optional if you track stock)
create table if not exists public.inventory (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  sku text not null,
  available_qty int not null default 0,
  reserved_qty int not null default 0,
  lead_time_days int,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (tenant_id, sku)
);

create index if not exists inventory_tenant_idx on public.inventory (tenant_id);

-- Orders
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  order_number text not null,
  customer_id uuid references public.customers(id) on delete set null,
  status text not null default 'processing'
    check (status in ('processing','paid','fulfilled','shipped','delivered','cancelled','refunded','on_hold')),
  currency text not null default 'USD',
  total numeric(12,2) not null default 0,
  placed_at timestamptz,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (tenant_id, order_number)
);

create index if not exists orders_tenant_idx on public.orders (tenant_id);
create index if not exists orders_customer_idx on public.orders (customer_id);
create index if not exists orders_order_number_idx on public.orders (order_number);

-- Order items
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  sku text,
  name text,
  qty int not null default 1,
  unit_price numeric(12,2),
  created_at timestamptz not null default now()
);

create index if not exists order_items_order_idx on public.order_items (order_id);
create index if not exists order_items_tenant_idx on public.order_items (tenant_id);

-- Shipments
create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  order_id uuid not null references public.orders(id) on delete cascade,
  carrier text,
  tracking_number text,
  status text not null default 'label_created'
    check (status in ('label_created','in_transit','out_for_delivery','delivered','exception','returned','unknown')),
  last_event text,
  last_event_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists shipments_order_idx on public.shipments (order_id);
create index if not exists shipments_tenant_idx on public.shipments (tenant_id);
create index if not exists shipments_tracking_idx on public.shipments (tracking_number);

-- Secure guest lookup tokens (so customers can check status without creating accounts)
-- Store only a hash. Token is generated server-side and shared via email/SMS.
create table if not exists public.order_lookup_tokens (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  order_id uuid not null references public.orders(id) on delete cascade,
  token_hash text not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  used_at timestamptz,
  unique (tenant_id, token_hash)
);

create index if not exists order_lookup_tokens_order_idx on public.order_lookup_tokens (order_id);
create index if not exists order_lookup_tokens_tenant_idx on public.order_lookup_tokens (tenant_id);

-- ==========
-- updated_at
-- ==========
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists trg_customers_updated_at on public.customers;
create trigger trg_customers_updated_at before update on public.customers for each row execute function public.set_updated_at();

drop trigger if exists trg_products_updated_at on public.products;
create trigger trg_products_updated_at before update on public.products for each row execute function public.set_updated_at();

drop trigger if exists trg_inventory_updated_at on public.inventory;
create trigger trg_inventory_updated_at before update on public.inventory for each row execute function public.set_updated_at();

drop trigger if exists trg_orders_updated_at on public.orders;
create trigger trg_orders_updated_at before update on public.orders for each row execute function public.set_updated_at();

drop trigger if exists trg_shipments_updated_at on public.shipments;
create trigger trg_shipments_updated_at before update on public.shipments for each row execute function public.set_updated_at();

-- =====================
-- RLS (Authenticated)
-- =====================
-- These are safe defaults for *authenticated customer portals* (Supabase Auth).
-- Your public website chat should NOT directly query these tables from the browser.

alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.shipments enable row level security;

-- Customers can see their own customer record.
drop policy if exists customers_self_read on public.customers;
create policy customers_self_read
on public.customers for select
to authenticated
using (auth_user_id = auth.uid());

-- Orders: customer can see orders linked to their customer record.
drop policy if exists orders_customer_read on public.orders;
create policy orders_customer_read
on public.orders for select
to authenticated
using (
  exists (
    select 1
    from public.customers c
    where c.id = orders.customer_id
      and c.auth_user_id = auth.uid()
  )
);

-- Order items: readable if order readable.
drop policy if exists order_items_customer_read on public.order_items;
create policy order_items_customer_read
on public.order_items for select
to authenticated
using (
  exists (
    select 1
    from public.orders o
    join public.customers c on c.id = o.customer_id
    where o.id = order_items.order_id
      and c.auth_user_id = auth.uid()
  )
);

-- Shipments: readable if order readable.
drop policy if exists shipments_customer_read on public.shipments;
create policy shipments_customer_read
on public.shipments for select
to authenticated
using (
  exists (
    select 1
    from public.orders o
    join public.customers c on c.id = o.customer_id
    where o.id = shipments.order_id
      and c.auth_user_id = auth.uid()
  )
);

-- Products + inventory are typically read server-side (service role) for multi-tenant public sites,
-- because RLS needs tenant context. Enable RLS but do NOT create anon policies by default.
alter table public.products enable row level security;
alter table public.inventory enable row level security;

-- You can add tenant-scoped public read later (e.g., via edge functions injecting tenant_id claim).

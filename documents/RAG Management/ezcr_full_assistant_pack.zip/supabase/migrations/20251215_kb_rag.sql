-- EZ Cycle Ramp / NexCyte KB + RAG foundation (Supabase Postgres)
-- Assumes: Postgres 15+ on Supabase
-- Embedding dim default: 1536 (OpenAI text-embedding-3-small). Change vector(dim) if needed.

create extension if not exists vector;
create extension if not exists pgcrypto;

-- =========
-- Documents
-- =========
create table if not exists public.kb_documents (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  doc_type text not null check (doc_type in ('web','pdf','faq','policy','manual','other')),
  title text,
  source_url text,
  source_hash text,              -- optional: hash of raw source for change detection
  tags text[] default '{}'::text[],
  status text not null default 'active' check (status in ('active','inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists kb_documents_tenant_idx on public.kb_documents (tenant_id);
create index if not exists kb_documents_doc_type_idx on public.kb_documents (doc_type);
create index if not exists kb_documents_tags_gin on public.kb_documents using gin (tags);

-- =========
-- Chunks
-- =========
create table if not exists public.kb_chunks (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  document_id uuid not null references public.kb_documents(id) on delete cascade,
  chunk_index int not null,
  content text not null,
  content_tokens int,
  heading text,
  source_url text,              -- override (e.g., anchor link)
  tags text[] default '{}'::text[],
  embedding vector(1536),       -- CHANGE DIMENSIONS IF YOU USE A DIFFERENT EMBEDDING MODEL
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (document_id, chunk_index)
);

create index if not exists kb_chunks_tenant_idx on public.kb_chunks (tenant_id);
create index if not exists kb_chunks_doc_idx on public.kb_chunks (document_id);
create index if not exists kb_chunks_tags_gin on public.kb_chunks using gin (tags);

-- Vector index (IVFFLAT). Requires ANALYZE after loading data.
-- Note: ivfflat requires setting "lists" to tune performance/recall.
do $$
begin
  if not exists (
    select 1 from pg_indexes where schemaname='public' and indexname='kb_chunks_embedding_ivfflat'
  ) then
    execute 'create index kb_chunks_embedding_ivfflat on public.kb_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100)';
  end if;
end $$;

-- ==============
-- Updated_at trig
-- ==============
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists trg_kb_documents_updated_at on public.kb_documents;
create trigger trg_kb_documents_updated_at
before update on public.kb_documents
for each row execute function public.set_updated_at();

drop trigger if exists trg_kb_chunks_updated_at on public.kb_chunks;
create trigger trg_kb_chunks_updated_at
before update on public.kb_chunks
for each row execute function public.set_updated_at();

-- ======================
-- Similarity search RPC
-- ======================
-- Returns top chunks for a tenant with optional filters.
-- Similarity score = 1 - cosine_distance (higher is better).
create or replace function public.match_kb_chunks(
  p_tenant_id uuid,
  p_query_embedding vector(1536),
  p_match_count int default 6,
  p_min_score float default 0.75,
  p_doc_types text[] default null,
  p_tags text[] default null,
  p_url_prefix text default null
)
returns table (
  source_id text,
  chunk_id uuid,
  document_id uuid,
  title text,
  url text,
  doc_type text,
  snippet text,
  score float
)
language sql
stable
as $$
  with c as (
    select
      kc.id as chunk_id,
      kc.document_id,
      kd.title,
      coalesce(kc.source_url, kd.source_url) as url,
      kd.doc_type,
      kc.content as snippet,
      (1 - (kc.embedding <=> p_query_embedding))::float as score
    from public.kb_chunks kc
    join public.kb_documents kd on kd.id = kc.document_id
    where kc.tenant_id = p_tenant_id
      and kd.tenant_id = p_tenant_id
      and kd.status = 'active'
      and kc.embedding is not null
      and (p_doc_types is null or kd.doc_type = any(p_doc_types))
      and (p_tags is null or kc.tags && p_tags or kd.tags && p_tags)
      and (p_url_prefix is null or coalesce(kc.source_url, kd.source_url) like (p_url_prefix || '%'))
  )
  select
    ('doc_' || document_id::text || ':chunk_' || chunk_id::text) as source_id,
    chunk_id,
    document_id,
    title,
    url,
    doc_type,
    left(snippet, 360) as snippet,
    score
  from c
  where score >= p_min_score
  order by score desc
  limit p_match_count;
$$;

-- =========
-- RLS (optional)
-- =========
-- For a public website chat, you will likely use a server-side key for retrieval (service role),
-- which bypasses RLS. These policies are still useful for authenticated admin tooling later.
alter table public.kb_documents enable row level security;
alter table public.kb_chunks enable row level security;

-- Default: no access for anon.
-- Add your own authenticated policies later (e.g., based on JWT claims tenant_id).
-- Example policy template (commented):
-- create policy "kb_docs_tenant_read"
-- on public.kb_documents for select
-- to authenticated
-- using (tenant_id::text = (auth.jwt() ->> 'tenant_id'));

-- =========
-- Post-load advice
-- =========
-- After ingesting a decent amount of data, run:
--   analyze public.kb_chunks;

# Multi-tenant foundation + customer DB data access (design notes)

## Goal
Your assistant must answer:
1) **Public knowledge** (product info, fitment rules, policies) via KB RAG
2) **Customer-specific data** (order status, shipping status, inventory availability, invoice, etc) via *structured DB queries*

## Pattern: "RAG + Tools"
In `/api/rag/query`, keep KB retrieval as-is, but add **tool calls** for DB lookups.

Example tools:
- `get_order_status(order_number | email | phone)`
- `get_shipping_status(tracking_number | order_id)`
- `get_inventory(sku | product_id)`
- `get_product(product_id | sku)`
- `create_support_ticket(...)`

## Security / Tenancy
Every table must include `tenant_id`.
Customers must only see their own records.
Recommended:
- Authenticated customers (Supabase Auth) -> RLS policies based on `auth.uid()` + `tenant_id`
- Guest lookups -> use short-lived "lookup token" per order (emailed to customer), **not** raw order id

## Implementation steps (recommended)
1) Create/confirm these tenant-scoped tables (or mapping views if your ecommerce is elsewhere):
   - `customers (id, tenant_id, auth_user_id, email, phone, ...)`
   - `orders (id, tenant_id, customer_id, order_number, status, total, ...)`
   - `shipments (id, tenant_id, order_id, carrier, tracking, status, last_event_at, ...)`
   - `inventory (id, tenant_id, sku, available_qty, lead_time_days, ...)`
2) Add RLS:
   - customer can select orders where `orders.customer_id` belongs to them
3) Add tool endpoints:
   - `/api/tools/order-status`
   - `/api/tools/shipping-status`
   - `/api/tools/inventory`
4) In your chat/voice agent, route intents:
   - "Where is my order?" -> call tool -> answer with result and next steps

This keeps multi-tenancy as a first-class concept, and avoids mixing sensitive DB reads into KB retrieval.

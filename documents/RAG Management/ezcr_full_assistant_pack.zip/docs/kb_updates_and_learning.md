# How the KB keeps updating + "learning" (and how to handle prices/rules safely)

## 1) Treat the KB as "published docs" — updated by ingestion
Your KB updates by re-running ingestion:
- Crawl sitemap / CMS / docs sources
- Extract text
- Chunk + embed
- Upsert, skipping unchanged sources via `source_hash`

### Recommended schedules
- Nightly crawl (e.g., 3 AM)
- On-demand crawl when you publish new pages/products/policies
- Event-driven: when your CMS changes (webhook), enqueue a targeted crawl of that URL

You can run ingestion via:
- n8n (cron trigger)
- GitHub Actions (cron)
- a small VPS cron job

## 2) Do NOT “RAG” volatile truth (prices, inventory, order status)
For anything that changes often, RAG is the wrong source of truth.

Use structured tables + tool endpoints:
- `products.price_current`, `inventory.available_qty`
- `orders.status`, `shipments.tracking_number`

Your assistant answers pricing/inventory/status by calling tools, not by quoting KB text.
The KB is for:
- how-it-works explanations
- policies and manuals
- fitment rules (if relatively stable, and versioned)

## 3) “Keep learning” loop (human-in-the-loop, not model training)
Add a feedback pipeline:
- log any question with low confidence or “no sources matched”
- review weekly
- add/update a KB page or a rules doc
- re-run ingestion

This is the practical “learning” mechanism for RAG systems.

## 4) Rule changes: version + effective dates
Store fitment rules/policies as:
- a canonical doc page (KB)
- plus (optional) a structured `rules` table:
  - `rule_key`, `value_json`, `effective_from`, `effective_to`, `version`

Your assistant uses:
- `rules` table for exact logic
- KB doc for explanation/citations

## 5) New products: add structured record + docs
When you add a new product:
1) Insert/update `products` row (SKU, price_current, etc)
2) Publish/refresh product page (docs)
3) Run targeted ingestion for that URL

# EZ Cycle Ramp — QuickBooks Online Full-Coverage Sync Pack (2025-12-18)

This pack is designed to pull the QBO data required to make your current deployment succeed, with:
- Full rebuild for any environment (dev/staging/prod)
- Incremental sync using CDC where possible (last 30 days) + safe fallbacks
- Storage of raw QBO payloads + a website-friendly normalized transaction view

Note: QBO does NOT have an `OrderItem` entity. "Order items" are represented as transaction lines on entities like Invoice, SalesReceipt, etc.
Fees/Taxes/Shipping are captured as line types and/or TxnTaxDetail inside those transactions.

## Recommended default sync scope

### Transactions
Invoice, SalesReceipt, Payment, RefundReceipt, CreditMemo, Bill, Purchase, BillPayment, VendorCredit, Deposit, JournalEntry, Transfer, PurchaseOrder

### Lists / reference data
Customer, Vendor, Item, Account, TaxCode, TaxRate, Department, Class, PaymentMethod, Term, CompanyInfo, Preferences

## Quick start (Windows 11 + PowerShell)

```powershell
npm i
npm run build
```

Run `sql/001_qbo_schema.sql` in your target Postgres/Supabase DB.

```powershell
copy .env.example .env
notepad .env
```

OAuth:
```powershell
npm run auth:url
npm run auth:exchange -- --code="PASTE_CODE" --realmId="PASTE_REALMID"
```

Sync:
```powershell
npm run sync:full
npm run sync:cdc
```

## Limits
- CDC only tracks changes within the last 30 days and responses max out around 1000 objects. This tool chunks time windows.

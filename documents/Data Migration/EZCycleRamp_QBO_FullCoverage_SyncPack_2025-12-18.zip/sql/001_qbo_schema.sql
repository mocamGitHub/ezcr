
create table if not exists qbo_sync_state (
  realm_id text primary key,
  last_cdc_timestamp timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists qbo_entity_raw (
  realm_id text not null,
  entity text not null,
  qbo_id text not null,
  sync_token text,
  last_updated_time timestamptz,
  is_deleted boolean not null default false,
  payload jsonb not null,
  fetched_at timestamptz not null default now(),
  primary key (realm_id, entity, qbo_id)
);

create index if not exists qbo_entity_raw_entity_idx on qbo_entity_raw (realm_id, entity);
create index if not exists qbo_entity_raw_updated_idx on qbo_entity_raw (realm_id, entity, last_updated_time);

create table if not exists web_transactions (
  realm_id text not null,
  txn_type text not null,
  txn_id text not null,
  doc_number text,
  txn_date date,
  private_note text,
  customer_ref text,
  vendor_ref text,
  currency_ref text,
  status text,
  total_amt numeric,
  balance numeric,
  total_tax numeric,
  metadata_last_updated timestamptz,
  payload jsonb not null,
  primary key (realm_id, txn_type, txn_id)
);

create index if not exists web_transactions_date_idx on web_transactions (realm_id, txn_date);

create table if not exists web_transaction_lines (
  realm_id text not null,
  txn_type text not null,
  txn_id text not null,
  line_id text,
  line_num integer,
  detail_type text,
  description text,
  amount numeric,
  item_ref text,
  qty numeric,
  unit_price numeric,
  tax_code_ref text,
  class_ref text,
  department_ref text,
  account_ref text,
  payload jsonb not null,
  primary key (realm_id, txn_type, txn_id, coalesce(line_id,'_'), coalesce(line_num,0))
);

create table if not exists web_transaction_tax_lines (
  realm_id text not null,
  txn_type text not null,
  txn_id text not null,
  tax_line_num integer,
  tax_rate_ref text,
  tax_percent numeric,
  tax_amount numeric,
  net_amount_taxable numeric,
  payload jsonb not null,
  primary key (realm_id, txn_type, txn_id, tax_line_num)
);

import { env } from "../util/env.js";
import { refreshAccessToken, TokenResponse } from "./oauth.js";

export class QboClient {
  private accessToken: string | null = null;
  private refreshToken: string;
  private tokenFetchedAt = 0;
  private expiresInSec = 0;

  constructor(refreshToken: string) {
    this.refreshToken = refreshToken;
  }

  private async ensureToken(): Promise<void> {
    const now = Date.now();
    const ageSec = (now - this.tokenFetchedAt) / 1000;
    if (this.accessToken && ageSec < (this.expiresInSec - 60)) return;

    const t: TokenResponse = await refreshAccessToken(this.refreshToken);
    this.accessToken = t.access_token;
    this.expiresInSec = t.expires_in;
    this.tokenFetchedAt = now;

    if (t.refresh_token) {
      this.refreshToken = t.refresh_token;
      console.log("[QBO] Updated refresh_token (store securely):", t.refresh_token);
    }
  }

  private headers(): Record<string,string> {
    if (!this.accessToken) throw new Error("No access token");
    return {
      "Authorization": `Bearer ${this.accessToken}`,
      "Accept": "application/json",
    };
  }

  private url(path: string, params?: Record<string,string>): string {
    const base = `${env.QBO_BASE_URL}/${env.QBO_REALM_ID}${path}`;
    const p = new URLSearchParams(params || {});
    p.set("minorversion", env.QBO_MINORVERSION);
    return `${base}?${p.toString()}`;
  }

  async query(entity: string, startPosition: number, maxResults: number): Promise<any[]> {
    await this.ensureToken();
    const q = `select * from ${entity} startposition ${startPosition} maxresults ${maxResults}`;
    const u = this.url("/query", { query: q });
    const res = await fetch(u, { method: "GET", headers: this.headers() });
    if (!res.ok) throw new Error(`QBO query failed: ${entity} ${res.status} ${await res.text()}`);
    const js = await res.json();
    const qr = js?.QueryResponse || {};
    return qr[entity] || [];
  }

  async cdc(entities: string[], changedSinceIso: string): Promise<Record<string, any[]>> {
    await this.ensureToken();
    const u = this.url("/cdc", { entities: entities.join(","), changedSince: changedSinceIso });
    const res = await fetch(u, { method: "GET", headers: { ...this.headers(), "Content-Type": "text/plain" } });
    if (!res.ok) throw new Error(`QBO cdc failed: ${res.status} ${await res.text()}`);
    const js = await res.json();
    const cr = js?.CDCResponse || {};
    const out: Record<string, any[]> = {};
    for (const ent of entities) out[ent] = cr[ent] || [];
    return out;
  }

  static extractMeta(payload: any): { qbo_id: string; sync_token?: string; last_updated_time?: string } {
    const id = payload?.Id || payload?.id || "";
    const sync = payload?.SyncToken;
    const lut = payload?.MetaData?.LastUpdatedTime;
    return {
      qbo_id: String(id),
      sync_token: sync ? String(sync) : undefined,
      last_updated_time: lut ? String(lut) : undefined
    };
  }
}

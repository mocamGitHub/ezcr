import { withClient } from "./db.js";

export async function upsertRaw(realmId: string, entity: string, qboId: string, payload: any, syncToken?: string, lastUpdated?: string, isDeleted: boolean = false): Promise<void> {
  await withClient(async (c) => {
    await c.query(
      `insert into qbo_entity_raw (realm_id, entity, qbo_id, sync_token, last_updated_time, is_deleted, payload)
       values ($1,$2,$3,$4,$5,$6,$7)
       on conflict (realm_id, entity, qbo_id) do update
       set sync_token=excluded.sync_token,
           last_updated_time=excluded.last_updated_time,
           is_deleted=excluded.is_deleted,
           payload=excluded.payload,
           fetched_at=now()`,
      [realmId, entity, qboId, syncToken || null, lastUpdated || null, isDeleted, payload]
    );
  });
}

export async function getSyncState(realmId: string): Promise<{ last_cdc_timestamp: string | null }> {
  return await withClient(async (c) => {
    const r = await c.query(`select last_cdc_timestamp from qbo_sync_state where realm_id=$1`, [realmId]);
    return { last_cdc_timestamp: r.rows[0]?.last_cdc_timestamp ?? null };
  });
}

export async function setSyncState(realmId: string, lastCdcTimestamp: string): Promise<void> {
  await withClient(async (c) => {
    await c.query(
      `insert into qbo_sync_state (realm_id, last_cdc_timestamp)
       values ($1,$2)
       on conflict (realm_id) do update
       set last_cdc_timestamp=excluded.last_cdc_timestamp,
           updated_at=now()`,
      [realmId, lastCdcTimestamp]
    );
  });
}

import { env } from "../util/env.js";
import { QboClient } from "../qbo/client.js";
import { upsertRaw } from "../db/upsert.js";
import { normalizeTransaction, upsertNormalized } from "../transform/normalize.js";

const TXN_TYPES = new Set([
  "Invoice","SalesReceipt","Payment","RefundReceipt","CreditMemo","Bill","Purchase","BillPayment","VendorCredit","Deposit","JournalEntry","Transfer","PurchaseOrder"
]);

export async function runFullSync(): Promise<void> {
  if (!env.QBO_REFRESH_TOKEN) throw new Error("QBO_REFRESH_TOKEN missing");
  const qbo = new QboClient(env.QBO_REFRESH_TOKEN);

  const entities = env.QBO_FULL_ENTITIES;
  if (!entities.length) throw new Error("QBO_FULL_ENTITIES is empty");

  console.log(`[FULL] Syncing ${entities.length} entities...`);

  for (const entity of entities) {
    console.log(`[FULL] Entity: ${entity}`);
    let start = 1;
    const max = 1000;

    while (true) {
      const rows = await qbo.query(entity, start, max);
      if (!rows.length) break;

      for (const row of rows) {
        const meta = QboClient.extractMeta(row);
        if (!meta.qbo_id) continue;

        await upsertRaw(env.QBO_REALM_ID, entity, meta.qbo_id, row, meta.sync_token, meta.last_updated_time, false);

        if (env.QBO_NORMALIZE && TXN_TYPES.has(entity)) {
          await upsertNormalized(normalizeTransaction(env.QBO_REALM_ID, entity, row));
        }
      }

      if (rows.length < max) break;
      start += max;
    }
  }

  console.log("[FULL] Done.");
}

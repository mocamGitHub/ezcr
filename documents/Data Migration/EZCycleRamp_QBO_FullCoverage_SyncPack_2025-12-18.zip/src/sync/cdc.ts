import { env } from "../util/env.js";
import { QboClient } from "../qbo/client.js";
import { upsertRaw, getSyncState, setSyncState } from "../db/upsert.js";
import { normalizeTransaction, upsertNormalized } from "../transform/normalize.js";

const TXN_TYPES = new Set([
  "Invoice","SalesReceipt","Payment","RefundReceipt","CreditMemo","Bill","Purchase","BillPayment","VendorCredit","Deposit","JournalEntry","Transfer","PurchaseOrder"
]);

export async function runCdcSync(): Promise<void> {
  if (!env.QBO_REFRESH_TOKEN) throw new Error("QBO_REFRESH_TOKEN missing");
  const qbo = new QboClient(env.QBO_REFRESH_TOKEN);

  const entities = env.QBO_CDC_ENTITIES;
  if (!entities.length) throw new Error("QBO_CDC_ENTITIES is empty");

  const state = await getSyncState(env.QBO_REALM_ID);

  const now = new Date();
  const lookbackMs = env.QBO_CDC_LOOKBACK_MINUTES * 60 * 1000;
  const baseStart = state.last_cdc_timestamp ? new Date(state.last_cdc_timestamp) : new Date(now.getTime() - lookbackMs);

  // buffer to avoid missing updates around the watermark
  const start = new Date(baseStart.getTime() - Math.min(lookbackMs, 10 * 60 * 1000));

  console.log(`[CDC] Start: ${start.toISOString()}  End: ${now.toISOString()}`);

  const chunkMs = env.QBO_CDC_CHUNK_MINUTES * 60 * 1000;
  let cursor = start;

  while (cursor < now) {
    const changedSince = cursor.toISOString();
    console.log(`[CDC] Window changedSince=${changedSince}`);

    const changed = await qbo.cdc(entities, changedSince);

    for (const entity of entities) {
      for (const row of (changed[entity] || [])) {
        const meta = QboClient.extractMeta(row);
        if (!meta.qbo_id) continue;

        const status = row?.status || row?.Status;
        const isDeleted = String(status || "").toLowerCase() === "deleted";

        await upsertRaw(env.QBO_REALM_ID, entity, meta.qbo_id, row, meta.sync_token, meta.last_updated_time, isDeleted);

        if (env.QBO_NORMALIZE && TXN_TYPES.has(entity) && !isDeleted) {
          await upsertNormalized(normalizeTransaction(env.QBO_REALM_ID, entity, row));
        }
      }
    }

    cursor = new Date(Math.min(now.getTime(), cursor.getTime() + chunkMs));
  }

  await setSyncState(env.QBO_REALM_ID, now.toISOString());
  console.log("[CDC] Done.");
}

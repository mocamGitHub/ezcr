import { runFullSync } from "../sync/full.js";
runFullSync().catch((e)=>{console.error(e);process.exit(1);});

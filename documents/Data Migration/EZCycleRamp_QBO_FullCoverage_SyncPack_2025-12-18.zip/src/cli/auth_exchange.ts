import yargs from "yargs";
import { hideBin } from "yargs/helpers";
import { exchangeCodeForTokens } from "../qbo/oauth.js";

const argv = await yargs(hideBin(process.argv))
  .option("code", { type: "string", demandOption: true })
  .option("realmId", { type: "string", demandOption: true })
  .parse();

const t = await exchangeCodeForTokens(argv.code);
console.log(JSON.stringify({ realmId: argv.realmId, ...t }, null, 2));

import { runCdcSync } from "../sync/cdc.js";
runCdcSync().catch((e)=>{console.error(e);process.exit(1);});

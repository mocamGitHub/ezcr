import { buildAuthUrl } from "../qbo/oauth.js";
console.log(buildAuthUrl("ezcr"));

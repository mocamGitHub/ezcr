import { withClient } from "../db/db.js";

function num(x: any): number | null {
  if (x === null || x === undefined || x === "") return null;
  const n = Number(x);
  return Number.isFinite(n) ? n : null;
}

function refId(ref: any): string | null {
  if (!ref) return null;
  return String(ref.value ?? ref.Value ?? ref.id ?? "");
}

export type Normalized = { header: any; lines: any[]; taxLines: any[]; };

export function normalizeTransaction(realmId: string, txnType: string, txn: any): Normalized {
  const meta = txn?.MetaData || {};
  const header = {
    realm_id: realmId,
    txn_type: txnType,
    txn_id: String(txn?.Id),
    doc_number: txn?.DocNumber ? String(txn.DocNumber) : null,
    txn_date: txn?.TxnDate ? String(txn.TxnDate) : null,
    private_note: txn?.PrivateNote ? String(txn.PrivateNote) : null,
    customer_ref: refId(txn?.CustomerRef),
    vendor_ref: refId(txn?.VendorRef),
    currency_ref: refId(txn?.CurrencyRef),
    status: txn?.status ? String(txn.status) : (txn?.EmailStatus ? String(txn.EmailStatus) : null),
    total_amt: num(txn?.TotalAmt),
    balance: num(txn?.Balance),
    total_tax: num(txn?.TxnTaxDetail?.TotalTax),
    metadata_last_updated: meta?.LastUpdatedTime ? String(meta.LastUpdatedTime) : null,
    payload: txn
  };

  const lines: any[] = [];
  for (const line of (txn?.Line || [])) {
    const dt = line?.DetailType ? String(line.DetailType) : null;
    const sales = line?.SalesItemLineDetail || {};
    const purch = line?.PurchaseItemLineDetail || {};
    const disc = line?.DiscountLineDetail || {};
    const ship = line?.ShippingLineDetail || {};
    const tax = line?.TaxLineDetail || {};

    const qty = num(sales?.Qty ?? purch?.Qty);
    const unitPrice = num(sales?.UnitPrice ?? purch?.UnitPrice);
    const itemRef = refId(sales?.ItemRef ?? purch?.ItemRef ?? ship?.ItemRef);
    const taxCodeRef = refId(sales?.TaxCodeRef ?? purch?.TaxCodeRef);
    const accountRef = refId(sales?.AccountRef ?? purch?.AccountRef ?? disc?.DiscountAccountRef ?? tax?.TaxRateRef);

    lines.push({
      realm_id: realmId,
      txn_type: txnType,
      txn_id: String(txn?.Id),
      line_id: line?.Id ? String(line.Id) : null,
      line_num: num(line?.LineNum),
      detail_type: dt,
      description: line?.Description ? String(line.Description) : null,
      amount: num(line?.Amount),
      item_ref: itemRef,
      qty,
      unit_price: unitPrice,
      tax_code_ref: taxCodeRef,
      class_ref: refId(sales?.ClassRef ?? purch?.ClassRef),
      department_ref: refId(sales?.DepartmentRef ?? purch?.DepartmentRef),
      account_ref: accountRef,
      payload: line
    });
  }

  const taxLines: any[] = [];
  let i = 0;
  for (const tl of (txn?.TxnTaxDetail?.TaxLine || [])) {
    const tld = tl?.TaxLineDetail || {};
    taxLines.push({
      realm_id: realmId,
      txn_type: txnType,
      txn_id: String(txn?.Id),
      tax_line_num: i++,
      tax_rate_ref: refId(tld?.TaxRateRef),
      tax_percent: num(tld?.TaxPercent),
      tax_amount: num(tl?.Amount),
      net_amount_taxable: num(tld?.NetAmountTaxable),
      payload: tl
    });
  }

  return { header, lines, taxLines };
}

export async function upsertNormalized(n: Normalized): Promise<void> {
  await withClient(async (c) => {
    const h = n.header;
    await c.query(
      `insert into web_transactions (realm_id, txn_type, txn_id, doc_number, txn_date, private_note, customer_ref, vendor_ref, currency_ref, status, total_amt, balance, total_tax, metadata_last_updated, payload)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       on conflict (realm_id, txn_type, txn_id) do update
       set doc_number=excluded.doc_number,
           txn_date=excluded.txn_date,
           private_note=excluded.private_note,
           customer_ref=excluded.customer_ref,
           vendor_ref=excluded.vendor_ref,
           currency_ref=excluded.currency_ref,
           status=excluded.status,
           total_amt=excluded.total_amt,
           balance=excluded.balance,
           total_tax=excluded.total_tax,
           metadata_last_updated=excluded.metadata_last_updated,
           payload=excluded.payload`,
      [h.realm_id, h.txn_type, h.txn_id, h.doc_number, h.txn_date, h.private_note, h.customer_ref, h.vendor_ref, h.currency_ref, h.status, h.total_amt, h.balance, h.total_tax, h.metadata_last_updated, h.payload]
    );

    await c.query(`delete from web_transaction_lines where realm_id=$1 and txn_type=$2 and txn_id=$3`, [h.realm_id, h.txn_type, h.txn_id]);
    for (const ln of n.lines) {
      await c.query(
        `insert into web_transaction_lines (realm_id, txn_type, txn_id, line_id, line_num, detail_type, description, amount, item_ref, qty, unit_price, tax_code_ref, class_ref, department_ref, account_ref, payload)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
        [ln.realm_id, ln.txn_type, ln.txn_id, ln.line_id, ln.line_num, ln.detail_type, ln.description, ln.amount, ln.item_ref, ln.qty, ln.unit_price, ln.tax_code_ref, ln.class_ref, ln.department_ref, ln.account_ref, ln.payload]
      );
    }

    await c.query(`delete from web_transaction_tax_lines where realm_id=$1 and txn_type=$2 and txn_id=$3`, [h.realm_id, h.txn_type, h.txn_id]);
    for (const tl of n.taxLines) {
      await c.query(
        `insert into web_transaction_tax_lines (realm_id, txn_type, txn_id, tax_line_num, tax_rate_ref, tax_percent, tax_amount, net_amount_taxable, payload)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [tl.realm_id, tl.txn_type, tl.txn_id, tl.tax_line_num, tl.tax_rate_ref, tl.tax_percent, tl.tax_amount, tl.net_amount_taxable, tl.payload]
      );
    }
  });
}

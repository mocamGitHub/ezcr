import dotenv from "dotenv";
dotenv.config();

function req(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

export const env = {
  QBO_CLIENT_ID: req("QBO_CLIENT_ID"),
  QBO_CLIENT_SECRET: req("QBO_CLIENT_SECRET"),
  QBO_REDIRECT_URI: req("QBO_REDIRECT_URI"),
  QBO_REALM_ID: req("QBO_REALM_ID"),
  QBO_REFRESH_TOKEN: process.env.QBO_REFRESH_TOKEN || "",
  QBO_BASE_URL: process.env.QBO_BASE_URL || "https://quickbooks.api.intuit.com/v3/company",
  QBO_MINORVERSION: process.env.QBO_MINORVERSION || "75",
  DATABASE_URL: req("DATABASE_URL"),

  QBO_FULL_ENTITIES: (process.env.QBO_FULL_ENTITIES || "").split(",").map(s => s.trim()).filter(Boolean),
  QBO_CDC_ENTITIES: (process.env.QBO_CDC_ENTITIES || "").split(",").map(s => s.trim()).filter(Boolean),
  QBO_CDC_LOOKBACK_MINUTES: parseInt(process.env.QBO_CDC_LOOKBACK_MINUTES || "120", 10),
  QBO_CDC_CHUNK_MINUTES: parseInt(process.env.QBO_CDC_CHUNK_MINUTES || "60", 10),
  QBO_NORMALIZE: (process.env.QBO_NORMALIZE || "true").toLowerCase() === "true",
};

# NexCyte Books (Standalone-only) v0.1 — Claude Code Execution Pack

This pack is designed so you can hand it to Claude Code and have it implement the DB + workflows + minimal API routes with minimal manual copy/paste.

## What’s included

- `sql/001_books_standalone_v0_1.sql`
  - Enums, tables, indexes, triggers
  - Helper functions: `set_updated_at()`, `books_norm_text()`, `books_txn_hash()`
  - RPCs: `books_apply_match_decision()`, `books_confirm_match()`, `books_reject_match()`
  - Views:
    - `books_receipt_review_queue_with_suggestions_v1` (single-query queue + top-3 suggestions)
    - KPI + exceptions + supporting views
  - RLS policies using `public.nexcyte_tenant_id()` (adjust JWT claim key if needed)

- `n8n/Books_ReceiptUpload_Process.workflow.json`
- `n8n/Books_BankImport_CSV.workflow.json`

- Minimal Next.js routes:
  - `next/app/api/books/receipts/upload/route.ts`
  - `next/app/api/books/bank/import/route.ts`
  - `next/app/books/actions.ts` (server actions for confirm/reject match)

- `.env` template: `env/.env.example`

## Execution steps (Claude Code should do these)

### A) Apply SQL migration

1. Apply `sql/001_books_standalone_v0_1.sql` to Supabase Postgres (via Supabase SQL editor or migrations).
2. Ensure Storage bucket exists:
   - bucket: `books` (or match `BOOKS_STORAGE_BUCKET`)
3. Create a `books_settings` row per tenant (at minimum for EZ Cycle Ramp):
   - `enabled=true`
   - thresholds as desired

### B) Import n8n workflows

Import the two JSON files in `n8n/` into your n8n instance:
- `Books_ReceiptUpload_Process.workflow.json`
- `Books_BankImport_CSV.workflow.json`

Then set these n8n environment variables:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `N8N_WEBHOOK_SECRET`
- `GCP_PROJECT_ID`
- `DOC_AI_LOCATION`
- `DOC_AI_EXPENSE_PROCESSOR_ID`

### C) Wire Next.js

Copy the `next/` directory contents into your NexCyte Next.js repo, preserving paths.

Add environment variables from `env/.env.example` to your deployment environment.

### D) Smoke tests

1. Receipt upload:
   - POST multipart to `/api/books/receipts/upload` with `tenant_id` and `file`
   - Confirm `books_documents` row exists + storage object exists
   - n8n workflow should update extraction fields and create matches

2. Bank CSV import:
   - POST multipart to `/api/books/bank/import` with `tenant_id` and `file`
   - Confirm rows upserted in `books_bank_transactions` with unique `txn_hash`

3. Review queue:
   - Query `books_receipt_review_queue_with_suggestions_v1` and confirm `top_suggestions` is a JSON array (max 3)

## Notes

### Signature verification (important)
This pack uses a stable HMAC base string to avoid JSON canonicalization issues:

- Receipt workflow: `base = "${tenant_id}|${doc_id}"`
- Bank import workflow: `base = "${tenant_id}|${import_id}"`

The Next.js routes send `x-nexcyte-signature = HMAC_SHA256(base)`.

The n8n workflows verify that header.

### Tenant claim extraction
RLS depends on `public.nexcyte_tenant_id()`:
```sql
select nullif(auth.jwt() ->> 'tenant_id','')::uuid;
```
If your JWT uses a different key, update that function.


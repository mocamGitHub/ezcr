# NexCyte Books v0.1 — Execution Checklist

## DB
- [ ] Apply `sql/001_books_standalone_v0_1.sql`
- [ ] Verify enums exist: books_document_type, books_match_status, books_sync_status, books_bank_source
- [ ] Verify tables exist: books_settings, books_documents, books_bank_transactions, books_matches, books_reconciliations
- [ ] Verify RPCs exist: books_apply_match_decision, books_confirm_match, books_reject_match
- [ ] Verify view exists: books_receipt_review_queue_with_suggestions_v1
- [ ] Insert tenant settings row for EZ Cycle Ramp tenant_id
  - enabled=true
  - auto_link_threshold=0.90
  - amount_tolerance=1.00
  - date_window_days=7

## Storage
- [ ] Create bucket `books` (or set BOOKS_STORAGE_BUCKET)
- [ ] Confirm service role key can sign URLs

## n8n
- [ ] Import both workflows in `n8n/`
- [ ] Set env vars in n8n: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, N8N_WEBHOOK_SECRET, GCP_PROJECT_ID, DOC_AI_LOCATION, DOC_AI_EXPENSE_PROCESSOR_ID
- [ ] Configure Google OAuth2 credentials node used by Document AI request (replace credential id in workflow if needed)
- [ ] Activate workflows

## Next.js
- [ ] Add env vars from `env/.env.example`
- [ ] Add route handlers:
  - /api/books/receipts/upload
  - /api/books/bank/import
- [ ] Confirm server actions compile: app/books/actions.ts

## Smoke Tests
- [ ] Upload receipt -> doc row + storage object created -> n8n processes -> extracted_fields populated
- [ ] Import CSV -> transactions upserted (no duplicates on re-import)
- [ ] Review queue view returns documents with `top_suggestions` JSON array
- [ ] Confirm match RPC marks txn cleared and rejects other suggestions
